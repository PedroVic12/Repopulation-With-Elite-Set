// Export all configure functions and make them globally available

import { qCapabilityCurve15MwOffshoreWtgJson } from './staticGeneratorDialog.js';
import { defaultStorageQCapabilityJson } from './utils/storageQCapability.js';
import {
    defaultWindPowerCurveJson,
    DEFAULT_WIND_SPEED_MS,
    WIND_POWER_CURVE_DEFAULT_RATED_MW,
    computeWindTurbinePMw
} from './windTurbineDialog.js';
import {
    defaultQCap2dState,
    serializeQCap2d,
    flattenQCap2dToPqPoints
} from './utils/qCapabilityVoltageDependent.js';

/** Default scaling for load/gen/sgen etc.: use "1" when value is "0", null, undefined, or empty */
function defaultScaling(value) {
    if (value == null || value === "" || value === "0") return "1";
    return String(value);
}

export function configureExternalGridAttributes(grafka, vertex, options = {}) {
    
    // Create XML document
    var g = mxUtils.createXmlDocument().createElement("object");
    
        g.setAttribute("name", options.name || "External Grid");
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("vm_pu", options.vm_pu || "1");
    g.setAttribute("va_degree", options.va_degree || "0");
    //g.setAttribute("in_service", true);

    //Short-circuit 
    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("s_sc_max_mva", options.s_sc_max_mva != null ? String(options.s_sc_max_mva) : "1000000.0");    
    g.setAttribute("s_sc_min_mva", options.s_sc_min_mva != null ? String(options.s_sc_min_mva) : "0");
    g.setAttribute("rx_max", options.rx_max != null ? String(options.rx_max) : "0");
    g.setAttribute("rx_min", options.rx_min != null ? String(options.rx_min) : "0");
    g.setAttribute("r0x0_max", options.r0x0_max != null ? String(options.r0x0_max) : "0");
    g.setAttribute("x0x_max", options.x0x_max != null ? String(options.x0x_max) : "0");
    g.setAttribute("r0x0_min", options.r0x0_min != null ? String(options.r0x0_min) : (options.r0x0_max != null ? String(options.r0x0_max) : "0"));
    g.setAttribute("x0x_min", options.x0x_min != null ? String(options.x0x_min) : (options.x0x_max != null ? String(options.x0x_max) : "0"));

    // Harmonic analysis parameters (OpenDSS Vsource)
    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "defaultvsource");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");

    // OPF coupling economics / bounds (optional; OPF dialog can override per run)
    g.setAttribute("OPF_coupling_parameters", "");
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? 0));
    g.setAttribute("min_p_mw", String(options.min_p_mw ?? 0));
    g.setAttribute("max_q_mvar", String(options.max_q_mvar ?? 0));
    g.setAttribute("min_q_mvar", String(options.min_q_mvar ?? 0));
    g.setAttribute("controllable", String(options.controllable ?? false));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    // Set the new value for the vertex
    grafka.getModel().setValue(vertex, g);
    
    
    //podpisz external grid
    grafka.insertVertex(vertex, null, 'External Grid', 0.5, -0.25, 0, 0, null, true);
            
}

export function configureGeneratorAttributes(grafka, vertex, options = {}) {

    // Create XML document
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Generator");                
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw || "0");
    g.setAttribute("vm_pu", options.vm_pu || "1");
    g.setAttribute("sn_mva", options.sn_mva || "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("slack", (options.slack === true || options.slack === 'true') ? "true" : "false");
    // g.setAttribute("in_service", true);                

    //short-circuit
    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("vn_kv", options.vn_kv || "0");
    g.setAttribute("xdss_pu", options.xdss_pu || "0");
    g.setAttribute("rdss_ohm", options.rdss_ohm || "0");
    g.setAttribute("cos_phi", options.cos_phi || "0");
    g.setAttribute("pg_percent", options.pg_percent || "0");
    g.setAttribute("power_station_trafo", options.power_station_trafo || "0");
    g.setAttribute("ansi_machine_type", options.ansi_machine_type || "turbo");
    

    //Optimal Power Flow
    /*
    g.setAttribute("controllable", true);
    g.setAttribute("max_p_mw", "0");
    g.setAttribute("min_p_mw", "0");
    g.setAttribute("max_q_mvar", "0");
    g.setAttribute("min_q_mvar", "0");
    g.setAttribute("min_vm_pu", "0");
    g.setAttribute("max_vm_pu", "0");*/

    //distributed power flow
    //g.setAttribute("slack_weight", "0"); 

    // Harmonic analysis parameters (OpenDSS)
    // Reference: https://opendss.epri.com/Properties9.html
    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "defaultgen");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");
    g.setAttribute("Xdpp", options.Xdpp || "0.20");
    g.setAttribute("XRdp", options.XRdp || "20");

    // ANDES dynamics (transient / eigenvalue). Empty strings → backend defaults.
    g.setAttribute("Dynamics_parameters", "");
    g.setAttribute("dyn_machine_model", options.dyn_machine_model || "GENROU");
    g.setAttribute("dyn_M", options.dyn_M != null ? String(options.dyn_M) : "");
    g.setAttribute("dyn_H", options.dyn_H != null ? String(options.dyn_H) : "");
    g.setAttribute("dyn_D", options.dyn_D != null ? String(options.dyn_D) : "");
    g.setAttribute("dyn_ra", options.dyn_ra != null ? String(options.dyn_ra) : "");
    g.setAttribute("dyn_xl", options.dyn_xl != null ? String(options.dyn_xl) : "");
    g.setAttribute("dyn_xd", options.dyn_xd != null ? String(options.dyn_xd) : "");
    g.setAttribute("dyn_xq", options.dyn_xq != null ? String(options.dyn_xq) : "");
    g.setAttribute("dyn_xd1", options.dyn_xd1 != null ? String(options.dyn_xd1) : "");
    g.setAttribute("dyn_xq1", options.dyn_xq1 != null ? String(options.dyn_xq1) : "");
    g.setAttribute("dyn_xd2", options.dyn_xd2 != null ? String(options.dyn_xd2) : "");
    g.setAttribute("dyn_xq2", options.dyn_xq2 != null ? String(options.dyn_xq2) : "");
    g.setAttribute("dyn_Td10", options.dyn_Td10 != null ? String(options.dyn_Td10) : "");
    g.setAttribute("dyn_Td20", options.dyn_Td20 != null ? String(options.dyn_Td20) : "");
    g.setAttribute("dyn_Tq10", options.dyn_Tq10 != null ? String(options.dyn_Tq10) : "");
    g.setAttribute("dyn_Tq20", options.dyn_Tq20 != null ? String(options.dyn_Tq20) : "");
    g.setAttribute("dyn_exciter_model", options.dyn_exciter_model || "EXDC2");
    g.setAttribute("dyn_exc_KA", options.dyn_exc_KA != null ? String(options.dyn_exc_KA) : "");
    g.setAttribute("dyn_exc_TR", options.dyn_exc_TR != null ? String(options.dyn_exc_TR) : "");
    g.setAttribute("dyn_exc_TA", options.dyn_exc_TA != null ? String(options.dyn_exc_TA) : "");
    g.setAttribute("dyn_exc_TE", options.dyn_exc_TE != null ? String(options.dyn_exc_TE) : "");
    g.setAttribute("dyn_exc_K", options.dyn_exc_K != null ? String(options.dyn_exc_K) : "");
    g.setAttribute("dyn_governor_model", options.dyn_governor_model || "TGOV1");
    g.setAttribute("dyn_gov_R", options.dyn_gov_R != null ? String(options.dyn_gov_R) : "");
    g.setAttribute("dyn_gov_T1", options.dyn_gov_T1 != null ? String(options.dyn_gov_T1) : "");
    g.setAttribute("dyn_gov_T2", options.dyn_gov_T2 != null ? String(options.dyn_gov_T2) : "");
    g.setAttribute("dyn_gov_T3", options.dyn_gov_T3 != null ? String(options.dyn_gov_T3) : "");
    g.setAttribute("dyn_pss_model", options.dyn_pss_model || "NONE");
    g.setAttribute("dyn_pss_A1", options.dyn_pss_A1 != null ? String(options.dyn_pss_A1) : "");
    g.setAttribute("dyn_pss_A2", options.dyn_pss_A2 != null ? String(options.dyn_pss_A2) : "");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", options.opf_cost_currency != null ? String(options.opf_cost_currency) : "EUR");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'Generator', 0.5, 1.1, 0, 0, null, true);
}

export function configureStaticGeneratorAttributes(grafka, vertex, options = {}) {


    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Static Generator");
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw || "0");
    g.setAttribute("q_mvar", options.q_mvar ||  "0");
    g.setAttribute("sn_mva", options.sn_mva ||  "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type",  options.type || "Wye");
    //g.setAttribute("in_service", true);

    //short-circuit
    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("k", options.k ||  "0");
    g.setAttribute("rx", options.rx ||  "0");
    g.setAttribute("generator_type", options.generator_type ||  "async");
    g.setAttribute("lrc_pu", options.lrc_pu ||  "0.0");
    g.setAttribute("max_ik_ka", options.max_ik_ka ||  "0.0");
    g.setAttribute("kappa", options.kappa ||  "0.0");
    g.setAttribute("current_source", options.current_source || true);

    // OPF (pandapower — https://pandapower.readthedocs.io/en/latest/opf/pypower_run.html)
    g.setAttribute("OPF_parameters", "");
    g.setAttribute("controllable", String(options.controllable ?? false));
    g.setAttribute("min_p_mw", String(options.min_p_mw ?? "0"));
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? "1"));
    g.setAttribute("min_q_mvar", String(options.min_q_mvar ?? "-1"));
    g.setAttribute("max_q_mvar", String(options.max_q_mvar ?? "1"));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    // Harmonic analysis parameters (OpenDSS)
    // Reference: https://opendss.epri.com/Properties9.html
    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "defaultgen");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");
    g.setAttribute("Xdpp", options.Xdpp || "0.20");
    g.setAttribute("XRdp", options.XRdp || "20");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    // pandapower Q capability curve (net.q_capability_curve_table)
    const qcapOn = options.reactive_capability_curve === true || options.reactive_capability_curve === 'true';
    g.setAttribute("reactive_capability_curve", qcapOn ? "true" : "false");
    g.setAttribute("curve_style", options.curve_style || "straightLineYValues");
    g.setAttribute("q_capability_curve_json", options.q_capability_curve_json || qCapabilityCurve15MwOffshoreWtgJson);
    g.setAttribute("q_setpoint_mode", options.q_setpoint_mode || "manual");

    // ANDES renewable / inverter dynamics. Empty key parameters defer to ANDES defaults.
    g.setAttribute("Dynamics_parameters", "");
    g.setAttribute("dyn_plant_kind", options.dyn_plant_kind || "NONE");
    g.setAttribute("dyn_Sn", options.dyn_Sn != null ? String(options.dyn_Sn) : "");
    g.setAttribute("dyn_reg_Tg", options.dyn_reg_Tg != null ? String(options.dyn_reg_Tg) : "");
    g.setAttribute("dyn_ree_Vref0", options.dyn_ree_Vref0 != null ? String(options.dyn_ree_Vref0) : "");
    g.setAttribute("dyn_repca_Kp", options.dyn_repca_Kp != null ? String(options.dyn_repca_Kp) : "");
    g.setAttribute("dyn_wt_H", options.dyn_wt_H != null ? String(options.dyn_wt_H) : "");
    g.setAttribute("dyn_wt_DAMP", options.dyn_wt_DAMP != null ? String(options.dyn_wt_DAMP) : "");
    g.setAttribute("dyn_dg_Tg", options.dyn_dg_Tg != null ? String(options.dyn_dg_Tg) : "");

    grafka.getModel().setValue(vertex, g)

    //podpisz 
    grafka.insertVertex(vertex, null, 'Static Generator', 0.5, 1.1, 0, 0, null, true);
    
}

export function configureWindTurbineAttributes(grafka, vertex, options = {}) {
    const windSpeed = options.wind_speed_ms != null ? String(options.wind_speed_ms) : String(DEFAULT_WIND_SPEED_MS);
    const curveJson = options.wind_power_curve_json || defaultWindPowerCurveJson;
    const approx = options.wind_curve_approx || 'linear';
    const computedP = options.p_mw != null
        ? String(options.p_mw)
        : String(computeWindTurbinePMw(parseFloat(windSpeed), curveJson, approx));

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Wind Turbine");
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("wind_speed_ms", windSpeed);
    g.setAttribute("wind_power_curve_json", curveJson);
    g.setAttribute("wind_curve_approx", approx);
    g.setAttribute("p_mw", computedP);
    g.setAttribute("q_mvar", options.q_mvar || "0");
    g.setAttribute("sn_mva", options.sn_mva || String(WIND_POWER_CURVE_DEFAULT_RATED_MW));
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type", options.type || "Wye");

    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("k", options.k || "0");
    g.setAttribute("rx", options.rx || "0");
    g.setAttribute("generator_type", options.generator_type || "current_source");
    g.setAttribute("lrc_pu", options.lrc_pu || "0.0");
    g.setAttribute("max_ik_ka", options.max_ik_ka || "0.0");
    g.setAttribute("kappa", options.kappa || "0.0");
    g.setAttribute("current_source", options.current_source != null ? options.current_source : true);
    g.setAttribute("ikss_3ph_ka", options.ikss_3ph_ka != null && options.ikss_3ph_ka !== "" ? String(options.ikss_3ph_ka) : "0.0866");
    g.setAttribute("ikss_2ph_ka", options.ikss_2ph_ka != null && options.ikss_2ph_ka !== "" ? String(options.ikss_2ph_ka) : "0.0433");
    g.setAttribute("ikss_1ph_ka", options.ikss_1ph_ka != null && options.ikss_1ph_ka !== "" ? String(options.ikss_1ph_ka) : "0.0433");
    g.setAttribute("sc_ref_vn_kv", options.sc_ref_vn_kv != null && options.sc_ref_vn_kv !== "" ? String(options.sc_ref_vn_kv) : "30");
    g.setAttribute("r2_pu", options.r2_pu != null && options.r2_pu !== "" ? String(options.r2_pu) : "0");
    g.setAttribute("x2_pu", options.x2_pu != null && options.x2_pu !== "" ? String(options.x2_pu) : "1");

    g.setAttribute("OPF_parameters", "");
    g.setAttribute("controllable", String(options.controllable ?? false));
    g.setAttribute("min_p_mw", String(options.min_p_mw ?? "0"));
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? WIND_POWER_CURVE_DEFAULT_RATED_MW));
    g.setAttribute("min_q_mvar", String(options.min_q_mvar ?? "-1"));
    g.setAttribute("max_q_mvar", String(options.max_q_mvar ?? "1"));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "defaultgen");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");
    g.setAttribute("Xdpp", options.Xdpp || "0.20");
    g.setAttribute("XRdp", options.XRdp || "20");

    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    const qcapOn = options.reactive_capability_curve === true || options.reactive_capability_curve === 'true';
    g.setAttribute("reactive_capability_curve", qcapOn ? "true" : "false");
    g.setAttribute("curve_style", options.curve_style || "straightLineYValues");
    const q2d = serializeQCap2d(defaultQCap2dState());
    const q1dDefault = JSON.stringify(
        flattenQCap2dToPqPoints(defaultQCap2dState(), WIND_POWER_CURVE_DEFAULT_RATED_MW)
    );
    g.setAttribute("q_capability_curve_json", options.q_capability_curve_json || q1dDefault);
    g.setAttribute("q_setpoint_mode", options.q_setpoint_mode || "manual");
    g.setAttribute(
        "q_cap_voltage_dependent",
        String(options.q_cap_voltage_dependent !== false && options.q_cap_voltage_dependent !== 'false')
    );
    g.setAttribute("q_cap_input_model", options.q_cap_input_model || q2d.q_cap_input_model);
    g.setAttribute("q_cap_scale_min_percent", String(options.q_cap_scale_min_percent ?? q2d.q_cap_scale_min_percent));
    g.setAttribute("q_cap_scale_max_percent", String(options.q_cap_scale_max_percent ?? q2d.q_cap_scale_max_percent));
    g.setAttribute("q_cap_u_json", options.q_cap_u_json || q2d.q_cap_u_json);
    g.setAttribute("q_cap_p_json", options.q_cap_p_json || q2d.q_cap_p_json);
    g.setAttribute("q_cap_qmax_json", options.q_cap_qmax_json || q2d.q_cap_qmax_json);
    g.setAttribute("q_cap_qmin_json", options.q_cap_qmin_json || q2d.q_cap_qmin_json);

    g.setAttribute("Dynamics_parameters", "");
    g.setAttribute("dyn_plant_kind", options.dyn_plant_kind || "WIND");
    g.setAttribute("dyn_Sn", options.dyn_Sn != null ? String(options.dyn_Sn) : "");
    g.setAttribute("dyn_reg_Tg", options.dyn_reg_Tg != null ? String(options.dyn_reg_Tg) : "");
    g.setAttribute("dyn_ree_Vref0", options.dyn_ree_Vref0 != null ? String(options.dyn_ree_Vref0) : "");
    g.setAttribute("dyn_repca_Kp", options.dyn_repca_Kp != null ? String(options.dyn_repca_Kp) : "");
    g.setAttribute("dyn_wt_H", options.dyn_wt_H != null ? String(options.dyn_wt_H) : "");
    g.setAttribute("dyn_wt_DAMP", options.dyn_wt_DAMP != null ? String(options.dyn_wt_DAMP) : "");
    g.setAttribute("dyn_dg_Tg", options.dyn_dg_Tg != null ? String(options.dyn_dg_Tg) : "");

    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'Wind Turbine', 0.5, 1.1, 0, 0, null, true);
}

export function configureAsymmetricStaticGeneratorAttributes(grafka, vertex, options = {}) {
    
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Asymmetric Static Generator");
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_a_mw", options.p_a_mw || "0");
    g.setAttribute("p_b_mw", options.p_b_mw || "0");
    g.setAttribute("p_c_mw", options.p_c_mw || "0");
    g.setAttribute("q_a_mvar", options.q_a_mvar || "0");
    g.setAttribute("q_b_mvar", options.q_b_mvar || "0");
    g.setAttribute("q_c_mvar", options.q_c_mvar || "0");
    g.setAttribute("sn_mva", options.sn_mva || "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type", options.type || "Wye");
    // g.setAttribute("in_service", true); //in_service nie działa

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    //podpisz 
    grafka.insertVertex(vertex, null, 'Asymmetric Static Generator', 0.5, 1.1, 0, 0, null, true);

}

export function configureBusAttributes(grafka, vertex, options = {}) {
    // Create XML document
    var g = mxUtils.createXmlDocument().createElement("object");

    // Set label (use existing parametry or empty string)
    
    g.setAttribute("name", options.name ||"Bus"); 
 
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("vn_kv", options.vn_kv || "0");
     
    //g.setAttribute("type", "b");
    //g.setAttribute("in_service", true); //in_service nie działa

    g.setAttribute("OPF_parameters", "");
    g.setAttribute(
        "min_vm_pu",
        options.min_vm_pu != null && options.min_vm_pu !== "" ? String(options.min_vm_pu) : "0.9",
    );
    g.setAttribute(
        "max_vm_pu",
        options.max_vm_pu != null && options.max_vm_pu !== "" ? String(options.max_vm_pu) : "1.1",
    );

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    // Set the new value for the vertex
    grafka.getModel().setValue(vertex, g);
    //set label (labelY: -0.5 = above, 1.1 = below; default above). Label on left (x=0, align=left)
    var ly = options.labelY != null ? options.labelY : -0.5;
    grafka.insertVertex(vertex, null, options.name || "Bus" , 0, ly, 0, 0, "align=left", true);   
}

export function configureTransformerAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");

    g.setAttribute("name", "Transformer");

    g.setAttribute("parameters", true);  //na potrzeby wyboru elementu z biblioteki
    g.setAttribute("name", options.name ||"-");
    g.setAttribute("term_label_0", options.term_label_0 != null ? options.term_label_0 : "HV");
    g.setAttribute("term_label_1", options.term_label_1 != null ? options.term_label_1 : "LV");
    g.setAttribute("Load_flow_parameters", "")
    g.setAttribute("sn_mva", options.sn_mva || "0");
    g.setAttribute("vn_hv_kv", options.vn_hv_kv || "0");
    g.setAttribute("vn_lv_kv", options.vn_lv_kv || "0");

    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("vkr_percent", options.vkr_percent || "0");
    g.setAttribute("vk_percent", options.vk_percent || "10");
    g.setAttribute("pfe_kw", options.pfe_kw || "0");
    g.setAttribute("i0_percent", options.i0_percent || "0");
    g.setAttribute("vector_group", options.vector_group || "Dyn");
    g.setAttribute("vk0_percent", options.vk0_percent || "0");
    g.setAttribute("vkr0_percent", options.vkr0_percent || "0");
    g.setAttribute("mag0_percent", options.mag0_percent || "0");
    g.setAttribute("si0_hv_partial", options.si0_hv_partial || "0");
    g.setAttribute("rn_ohm", options.rn_ohm !== undefined ? String(options.rn_ohm) : "0");
    g.setAttribute("xn_ohm", options.xn_ohm !== undefined ? String(options.xn_ohm) : "0");

    //Optional
    //g.setAttribute("in_service", true); //in_service nie działa
    g.setAttribute("Optional_parameters", "");
    g.setAttribute("parallel", options.parallel || "1");
    g.setAttribute("shift_degree", options.shift_degree || "0");
    g.setAttribute("tap_side", options.tap_side || "hv");
    g.setAttribute("tap_pos", options.tap_pos || "0");
    g.setAttribute("tap_neutral", options.tap_neutral || "0");
    g.setAttribute("tap_max", options.tap_max || "0");
    g.setAttribute("tap_min", options.tap_min ||"0");
    g.setAttribute("tap_step_percent", options.tap_step_percent || "0");
    g.setAttribute("tap_step_degree", options.tap_step_degree ||"0");
    g.setAttribute("tap_phase_shifter", false);
    g.setAttribute("tap_changer_type", options.tap_changer_type || "Ratio"); // pandapower 3.0+: "Ratio", "Symmetrical", or "Ideal"
    if (options.discrete_tap_control !== undefined) {
        const dtc = options.discrete_tap_control === true || options.discrete_tap_control === 'true';
        g.setAttribute("discrete_tap_control", dtc ? "true" : "false");
    }
    if (options.vm_lower_pu != null && options.vm_lower_pu !== '') {
        g.setAttribute("vm_lower_pu", String(options.vm_lower_pu));
    }
    if (options.vm_upper_pu != null && options.vm_upper_pu !== '') {
        g.setAttribute("vm_upper_pu", String(options.vm_upper_pu));
    }
    if (options.control_side) {
        g.setAttribute("control_side", options.control_side);
    }

    g.setAttribute("OPF_parameters", "");
    g.setAttribute("max_loading_percent", options.max_loading_percent != null ? String(options.max_loading_percent) : "0");

    // Harmonic analysis parameters (OpenDSS Transformer)
    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("XRConst", options.XRConst || "No");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    // grafka.insertVertex(umieszczonaCell, null, 'Transformer', -0.25, 0, 0, 0, null, true);
}

export function configureThreeWindingTransformerAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Three winding transformer");

    g.setAttribute("parameters", true);  //na potrzeby wyboru elementu z biblioteki

    const s3 = (v, d = "0") => (v != null && v !== "") ? String(v) : d;
    g.setAttribute("name", options.name || "-");
    g.setAttribute("term_label_0", options.term_label_0 != null ? options.term_label_0 : "HV");
    g.setAttribute("term_label_1", options.term_label_1 != null ? options.term_label_1 : "MV");
    g.setAttribute("term_label_2", options.term_label_2 != null ? options.term_label_2 : "LV");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("sn_hv_mva", s3(options.sn_hv_mva));
    g.setAttribute("sn_mv_mva", s3(options.sn_mv_mva));
    g.setAttribute("sn_lv_mva", s3(options.sn_lv_mva));

    g.setAttribute("vn_hv_kv", s3(options.vn_hv_kv));
    g.setAttribute("vn_mv_kv", s3(options.vn_mv_kv));
    g.setAttribute("vn_lv_kv", s3(options.vn_lv_kv));

    g.setAttribute("vk_hv_percent", s3(options.vk_hv_percent, "8"));
    g.setAttribute("vk_mv_percent", s3(options.vk_mv_percent, "8"));
    g.setAttribute("vk_lv_percent", s3(options.vk_lv_percent, "8"));


    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("vkr_hv_percent", s3(options.vkr_hv_percent, "0.5"));
    g.setAttribute("vkr_mv_percent", s3(options.vkr_mv_percent, "0.5"));
    g.setAttribute("vkr_lv_percent", s3(options.vkr_lv_percent, "0.5"));

    g.setAttribute("pfe_kw", s3(options.pfe_kw, "12"));
    g.setAttribute("i0_percent", s3(options.i0_percent, "0.1"));

    g.setAttribute("vk0_hv_percent", s3(options.vk0_hv_percent));
    g.setAttribute("vk0_mv_percent", s3(options.vk0_mv_percent));
    g.setAttribute("vk0_lv_percent", s3(options.vk0_lv_percent));
    g.setAttribute("vkr0_hv_percent", s3(options.vkr0_hv_percent));
    g.setAttribute("vkr0_mv_percent", s3(options.vkr0_mv_percent));
    g.setAttribute("vkr0_lv_percent", s3(options.vkr0_lv_percent));
    g.setAttribute("vector_group", options.vector_group || "YNyn0yn0");


    //OPTIONAL
    g.setAttribute("Optional_parameters", "");
    g.setAttribute("shift_mv_degree", "0");
    g.setAttribute("shift_lv_degree", "0");
    g.setAttribute("tap_step_percent", "0");
    g.setAttribute("tap_side", "hv");
    g.setAttribute("tap_neutral", "0");
    g.setAttribute("tap_min", "0");
    g.setAttribute("tap_max", "0");
    g.setAttribute("tap_pos", "0");
    g.setAttribute("tap_at_star_point", true);
    g.setAttribute("tap_changer_type", "Ratio"); // pandapower 3.0+: "Ratio", "Symmetrical", or "Ideal"
    // g.setAttribute("in_service", true); //in_service nie działa

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    g.setAttribute("OPF_parameters", "");
    g.setAttribute("max_loading_percent", options.max_loading_percent != null ? String(options.max_loading_percent) : "0");

    grafka.getModel().setValue(vertex, g)
    //this.currentGraph.insertVertex(umieszczonaCell, null, 'Three Winding Transformer', -0.25, 0, 0, 0, null, true);             


}

export function configureShuntReactorAttributes(grafka, vertex, options = {}) {
  
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Shunt Reactor");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw || "0");
    g.setAttribute("q_mvar", options.q_mvar ||  "0");
    g.setAttribute("vn_kv", options.vn_kv || "0");

    //OPTIONAL
    g.setAttribute("Optional_parameters", "");
    
    g.setAttribute("step", options.step || "1");
    g.setAttribute("max_step", options.max_step || "1");
    g.setAttribute("step_dependency_table", options.step_dependency_table != null ? String(options.step_dependency_table) : "false");
    g.setAttribute("shunt_characteristic_table_json", options.shunt_characteristic_table_json || "[]");
    g.setAttribute("line_flow_step_control", options.line_flow_step_control != null ? String(options.line_flow_step_control) : "false");
    g.setAttribute("line_flow_reference_line_id", options.line_flow_reference_line_id != null ? String(options.line_flow_reference_line_id) : "");
    g.setAttribute("line_flow_step_table_json", options.line_flow_step_table_json || "[]");
    g.setAttribute("line_flow_p_use_abs", options.line_flow_p_use_abs != null ? String(options.line_flow_p_use_abs) : "true");
    g.setAttribute("line_flow_p_reference", options.line_flow_p_reference || "p_from_mw");
    // g.setAttribute("in_service", "True"); //in_service nie działa

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    // grafka.insertVertex(umieszczonaCell, null, 'Shunt Reactor', -0.25, 0, 0, 0, null, true);
}

export function configureCapacitorAttributes(grafka, vertex, options = {}) {            

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Capacitor");

    //INPUT     
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("q_mvar", options.q_mvar || "0");
    g.setAttribute("loss_factor", options.loss_factor || "0");
    g.setAttribute("vn_kv", options.vn_kv || "0");

    //OPTIONAL
    g.setAttribute("Optional_parameters", options.vm_pu || "");
    g.setAttribute("step", options.step || "1");
    g.setAttribute("max_step", options.max_step || "1");
    // g.setAttribute("in_service", "True"); //in_service nie działa

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    //this.currentGraph.insertVertex(umieszczonaCell, null, 'Capacitor', -0.25, 0, 0, 0, null, true);
}

export function configureLoadAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Load");

    //OPTIONAL
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw ||"0");
    g.setAttribute("q_mvar", options.q_mvar ||"0");
    g.setAttribute("const_z_percent", options.const_z_percent ||"0");
    g.setAttribute("const_i_percent", options.const_i_percent ||"0");
    g.setAttribute("sn_mva", options.sn_mva ||"0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type", options.type || "Wye");
    //g.setAttribute("in_service", "True"); //in_service nie działa

    // Harmonic analysis parameters (OpenDSS)
    // Reference: https://opendss.epri.com/HarmonicsLoadModeling.html
    g.setAttribute("Harmonic_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "defaultload");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");
    g.setAttribute("pctSeriesRL", options.pctSeriesRL ?? "100");
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("puXharm", options.puXharm || "0.0");
    g.setAttribute("XRharm", options.XRharm || "6.0");

    // OPF (controllable load — pandapower)
    g.setAttribute("OPF_parameters", "");
    g.setAttribute("controllable", String(options.controllable ?? false));
    g.setAttribute("min_p_mw", String(options.min_p_mw ?? "0"));
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? "1000"));
    g.setAttribute("min_q_mvar", String(options.min_q_mvar ?? "-1000"));
    g.setAttribute("max_q_mvar", String(options.max_q_mvar ?? "1000"));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    // Data-center computational load (ANDES ride-through; not CMLD/PERC1)
    g.setAttribute("Computational_load_parameters", "");
    g.setAttribute("dc_computational_enabled", String(options.dc_computational_enabled ?? false));
    g.setAttribute("dc_it_share_percent", String(options.dc_it_share_percent ?? "85"));
    g.setAttribute("dc_ups_hold_s", String(options.dc_ups_hold_s ?? "0"));
    g.setAttribute("dc_ride_through_csv", options.dc_ride_through_csv || "0,0.9\n10,0.9\n20,0.9");

    grafka.getModel().setValue(vertex, g)
    
    // Top-center pin; value must be empty — a visible label here is drawn at the port and would cover the tie line
    grafka.insertVertex(vertex, null, '', 0.5, 0, 0, 0, null, true);
    // Visible name below icon (aligned with Generator / Static Gen); synced on Apply via EditDataDialog.applyLoadValues
    grafka.insertVertex(vertex, null, options.name || 'Load', 0.5, 1.1, 0, 0, null, true);
}

export function configureAsymmetricLoadAttributes(grafka, vertex, options = {}) {
    var parametry = grafka.getModel().getValue(vertex);

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Asymmetric Load");

    //OPTIONAL
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_a_mw", options.p_a_mw || "0");
    g.setAttribute("p_b_mw", options.p_b_mw || "0");
    g.setAttribute("p_c_mw", options.p_c_mw || "0");

    g.setAttribute("q_a_mvar", options.q_a_mvar || "0");
    g.setAttribute("q_b_mvar", options.q_b_mvar || "0");
    g.setAttribute("q_c_mvar", options.q_c_mvar || "0");

    g.setAttribute("sn_mva", options.sn_mva || "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type", options.type || "Wye");
    // g.setAttribute("in_service", "True"); //in_service nie działa

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, '', 0.5, 0, 0, 0, null, true);
}

export function configureImpedanceAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Impedance");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("r_pu", options.r_pu ?? options.rft_pu ?? "0");
    g.setAttribute("x_pu", options.x_pu ?? options.xft_pu ?? "0");
    g.setAttribute("sn_mva", options.sn_mva || "0");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'Impedance', 0.5, 1.5, 0, 0, null, true);
}

export function configureWardAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Ward");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");  
    g.setAttribute("ps_mw", options.ps_mw || "0");
    g.setAttribute("qs_mvar", options.qs_mvar || "0");
    g.setAttribute("pz_mw", options.pz_mw ||"0");
    g.setAttribute("qz_mvar", options.qz_mvar || "0");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'Ward', 0.5, 1.5, 0, 0, null, true);
}

export function configureExtendedWardAttributes(grafka, vertex, options = {}) {
    
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Extended Ward");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("ps_mw", options.ps_mw || "0");
    g.setAttribute("qs_mvar", options.qs_mvar || "0");
    g.setAttribute("pz_mw", options.pz_mw || "0");
    g.setAttribute("qz_mvar", options.qz_mvar || "0");

    g.setAttribute("r_ohm", options.r_ohm || "0");
    g.setAttribute("x_ohm", options.x_ohm || "0");
    g.setAttribute("vm_pu", options.vm_pu || "0");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    //distributed slack power flow
    //g.setAttribute("slack_weight", "0");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'ExtendedWard', 0.5, 1.5, 0, 0, null, true);
}

export function configureMotorAttributes(grafka, vertex, options = {}) {
   
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Motor");

    //g.setAttribute("parameters", true);  //na potrzeby wyboru elementu z biblioteki

    //INPUT
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("pn_mech_mw", options.pn_mech_mw || "0");
    g.setAttribute("cos_phi", options.cos_phi ||"0");

    //Short-circuit
    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("cos_phi_n", options.cos_phi_n || "0");
    g.setAttribute("efficiency_n_percent", options.efficiency_n_percent || "0");
    g.setAttribute("lrc_pu", options.lrc_pu || "0");
    g.setAttribute("rx", options.rx ||"0");
    g.setAttribute("vn_kv", options.vn_kv || "0");

    // Dynamic / motor starting (ANDES)
    g.setAttribute("Dynamics_parameters", "");
    g.setAttribute("Hm", options.Hm != null ? String(options.Hm) : "0.5");
    g.setAttribute("tm_c1", options.tm_c1 != null ? String(options.tm_c1) : "0");
    g.setAttribute("tm_c2", options.tm_c2 != null ? String(options.tm_c2) : "0");
    g.setAttribute("tm_c3", options.tm_c3 != null ? String(options.tm_c3) : "1");

    //OPTIONAL
    g.setAttribute("Optional_parameters", "");
    g.setAttribute("efficiency_percent", options.efficiency_percent ||"0");
    g.setAttribute("loading_percent", options.loading_percent || "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    // g.setAttribute("in_service", "True");  //in_service nie działa                

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    // Top feed from busbar — slightly below SVG circle apex so the stroke meets the visible ring (image padding)
    grafka.insertVertex(vertex, null, '', 0.5, 0.3, 0, 0, null, true);
}

export function configureStorageAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Storage");

    // Load flow parameters (pandapower + OpenDSS shared)
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw || "0");
    g.setAttribute("q_mvar", options.q_mvar || "0");
    g.setAttribute("max_e_mwh", options.max_e_mwh || "0");
    g.setAttribute("min_e_mwh", options.min_e_mwh || "0");
    g.setAttribute("soc_percent", options.soc_percent || "0");
    g.setAttribute("sn_mva", options.sn_mva || "0");
    g.setAttribute("scaling", defaultScaling(options.scaling));
    g.setAttribute("type", options.type || "");
    g.setAttribute("conn", options.conn || "wye");
    g.setAttribute("phases", String(options.phases ?? 3));
    // g.setAttribute("in_service", "True");

    // Optimal Power Flow parameters (pandapower OPF)
    g.setAttribute("OPF_parameters", "");
    g.setAttribute("controllable", String(options.controllable ?? false));
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? 0));
    g.setAttribute("min_p_mw", String(options.min_p_mw ?? 0));
    g.setAttribute("max_q_mvar", String(options.max_q_mvar ?? 0));
    g.setAttribute("min_q_mvar", String(options.min_q_mvar ?? 0));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    // OpenDSS-specific parameters (https://opendss.epri.com/Properties5.html)
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("state", options.state || "IDLING");
    g.setAttribute("disp_mode", options.disp_mode || "DEFAULT");
    g.setAttribute("pct_charge", String(options.pct_charge ?? 100));
    g.setAttribute("pct_discharge", String(options.pct_discharge ?? 100));
    g.setAttribute("pct_eff_charge", String(options.pct_eff_charge ?? 90));
    g.setAttribute("pct_eff_discharge", String(options.pct_eff_discharge ?? 90));
    g.setAttribute("pct_idling_kw", String(options.pct_idling_kw ?? 1));
    g.setAttribute("pct_idling_kvar", String(options.pct_idling_kvar ?? 0));
    g.setAttribute("discharge_trigger", String(options.discharge_trigger ?? 0));
    g.setAttribute("charge_trigger", String(options.charge_trigger ?? 0));
    g.setAttribute("time_charge_trig", String(options.time_charge_trig ?? 2.0));
    g.setAttribute("spectrum", options.spectrum || "default");

    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("max_ik_ka", options.max_ik_ka !== undefined ? String(options.max_ik_ka) : "0");
    g.setAttribute("rx", options.rx !== undefined ? String(options.rx) : "0.1");
    g.setAttribute("current_source", options.current_source !== undefined ? String(options.current_source) : "false");

    // Inverter control (OpenDSS InvControl)
    g.setAttribute("Inverter_control_parameters", "");
    g.setAttribute("inv_control_mode", options.inv_control_mode || "NONE");
    g.setAttribute("pf", String(options.pf ?? 1.0));
    g.setAttribute("pf_q_mode", String(options.pf_q_mode || "lagging"));
    g.setAttribute("pf_charge", String(options.pf_charge ?? options.pf ?? 1.0));
    g.setAttribute("pf_charge_q_mode", String(options.pf_charge_q_mode || "leading"));
    g.setAttribute("watt_priority", String(options.watt_priority ?? false));
    g.setAttribute(
        "q_cap_voltage_dependent",
        String(options.q_cap_voltage_dependent === true || options.q_cap_voltage_dependent === 'true')
    );
    g.setAttribute("vv_curve_preset", options.vv_curve_preset || "IEEE_1547");
    g.setAttribute("vv_xarray", options.vv_xarray || "0.92 0.98 1.02 1.08");
    g.setAttribute("vv_yarray", options.vv_yarray || "0.44 0 -0.44 -0.44");
    g.setAttribute("vw_curve_preset", options.vw_curve_preset || "IEEE_1547");
    g.setAttribute("vw_xarray", options.vw_xarray || "1.06 1.1");
    g.setAttribute("vw_yarray", options.vw_yarray || "1 0");
    g.setAttribute("wattpf_xarray", options.wattpf_xarray || "0 0.5 1");
    g.setAttribute("wattpf_yarray", options.wattpf_yarray || "1 0.98 0.95");
    g.setAttribute("wattvar_xarray", options.wattvar_xarray || "0.2 0.5 1");
    g.setAttribute("wattvar_yarray", options.wattvar_yarray || "0.44 0.22 0");

    // P–Q capability (Qmin/Qmax vs |P|)
    const storageQcapOn = options.reactive_capability_curve === true || options.reactive_capability_curve === 'true';
    g.setAttribute("Q_capability_parameters", "");
    g.setAttribute("reactive_capability_curve", storageQcapOn ? "true" : "false");
    g.setAttribute("curve_style", options.curve_style || "straightLineYValues");
    g.setAttribute(
        "q_capability_curve_json",
        options.q_capability_curve_json || defaultStorageQCapabilityJson(
            options.sn_mva || options.p_mw || 50,
            options.max_p_mw || options.p_mw || options.sn_mva || 50
        )
    );
    g.setAttribute("q_capability_preset", options.q_capability_preset || "pcs_circle");
    g.setAttribute("q_setpoint_mode", options.q_setpoint_mode || "manual");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, options.name || 'Storage', 0.5, 1.5, 0, 0, null, true);
}

export function configureLoad1phAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Load 1ph");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("p_kw", options.p_kw ?? "0");
    g.setAttribute("q_kvar", options.q_kvar ?? "0");
    g.setAttribute("kv", options.kv ?? "");
    g.setAttribute("pf", options.pf ?? "1.0");
    g.setAttribute("phase", String(options.phase ?? 1));
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("spectrum", options.spectrum || "defaultload");
    g.setAttribute("pctSeriesRL", String(options.pctSeriesRL ?? 100));
    g.setAttribute("in_service", String(options.in_service !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, '', 0.5, 0, 0, 0, null, true);
    grafka.insertVertex(vertex, null, options.name || 'Load 1ph', 0.5, 1.1, 0, 0, null, true);
}

export function configureSource1phAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Source 1ph");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("vm_pu", options.vm_pu ?? "1.0");
    g.setAttribute("va_degree", options.va_degree ?? "0");
    g.setAttribute("s_sc_max_mva", options.s_sc_max_mva ?? "1000");
    g.setAttribute("phase", String(options.phase ?? 1));
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("in_service", String(options.in_service !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'Source 1ph', 0.5, 1.1, 0, 0, null, true);
}

export function configureGenerator1phAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Generator 1ph");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("p_kw", options.p_kw ?? "0");
    g.setAttribute("q_kvar", options.q_kvar ?? "0");
    g.setAttribute("kv", options.kv ?? "");
    g.setAttribute("sn_kva", options.sn_kva ?? "");
    g.setAttribute("model", String(options.model ?? 1));
    g.setAttribute("phase", String(options.phase ?? 1));
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("spectrum", options.spectrum || "defaultgen");
    g.setAttribute("in_service", String(options.in_service !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'Generator 1ph', 0.5, 1.1, 0, 0, null, true);
}

export function configureTransformer1phAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Transformer 1ph");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("sn_kva", String(options.sn_kva ?? 25));
    g.setAttribute("vk_percent", String(options.vk_percent ?? 2.0));
    g.setAttribute("vkr_percent", String(options.vkr_percent ?? 0.6));
    g.setAttribute("vn_hv_kv", String(options.vn_hv_kv ?? 7.2));
    g.setAttribute("vn_lv_kv", String(options.vn_lv_kv ?? 0.12));
    g.setAttribute("phase", String(options.phase ?? 1));
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("tap_pos", String(options.tap_pos ?? 0));
    g.setAttribute("in_service", String(options.in_service !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'Transformer 1ph', 0.5, 1.1, 0, 0, null, true);
}

export function configureLine1phAttributes(grafka, edge, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Line 1ph");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("length_km", String(options.length_km ?? 1));
    g.setAttribute("r_ohm_per_km", String(options.r_ohm_per_km ?? 0.122));
    g.setAttribute("x_ohm_per_km", String(options.x_ohm_per_km ?? 0.112));
    g.setAttribute("c_nf_per_km", String(options.c_nf_per_km ?? 0));
    g.setAttribute("phase", String(options.phase ?? 1));
    g.setAttribute("conn", (options.conn || "wye").toLowerCase());
    g.setAttribute("in_service", String(options.in_service !== false));
    grafka.getModel().setValue(edge, g);
}

export function configurePVSystemAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "PVSystem");

    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("irradiance", String(options.irradiance ?? 1.0));
    g.setAttribute("pmpp", String(options.pmpp ?? 100.0));
    g.setAttribute("temperature", String(options.temperature ?? 25.0));
    g.setAttribute("phases", String(options.phases ?? 3));
    g.setAttribute("kv", String(options.kv ?? 0.4));
    g.setAttribute("pf", String(options.pf ?? 1.0));
    g.setAttribute("kvar", String(options.kvar ?? 0.0));
    g.setAttribute("kva", String(options.kva ?? options.pmpp ?? 100.0));
    g.setAttribute("cutin", String(options.cutin ?? 0.1));
    g.setAttribute("cutout", String(options.cutout ?? 0.1));
    g.setAttribute("conn", options.conn || "wye");
    g.setAttribute("model", String(options.model ?? 1));
    g.setAttribute("vmaxpu", String(options.vmaxpu ?? 1.1));
    g.setAttribute("vminpu", String(options.vminpu ?? 0.9));
    g.setAttribute("pmpp_percent", String(options.pmpp_percent ?? 100.0));
    g.setAttribute("kvarmax", String(options.kvarmax ?? 120.0));
    g.setAttribute("kvarmaxabs", String(options.kvarmaxabs ?? 120.0));
    g.setAttribute("in_service", String(options.in_service !== undefined ? options.in_service : true));

    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("spectrum", options.spectrum || "default");
    g.setAttribute("spectrum_csv", options.spectrum_csv || "");
    g.setAttribute("basefreq", String(options.basefreq ?? 50.0));
    g.setAttribute("balanced", String(options.balanced ?? false));

    g.setAttribute("Inverter_control_parameters", "");
    g.setAttribute("inv_control_mode", options.inv_control_mode || "NONE");
    g.setAttribute("vv_curve_preset", options.vv_curve_preset || "IEEE_1547");
    g.setAttribute("vv_xarray", options.vv_xarray || "0.92 0.98 1.02 1.08");
    g.setAttribute("vv_yarray", options.vv_yarray || "0.44 0 -0.44 -0.44");
    g.setAttribute("vw_curve_preset", options.vw_curve_preset || "IEEE_1547");
    g.setAttribute("vw_xarray", options.vw_xarray || "1.06 1.1");
    g.setAttribute("vw_yarray", options.vw_yarray || "1 0");
    g.setAttribute("wattpf_xarray", options.wattpf_xarray || "0 0.5 1");
    g.setAttribute("wattpf_yarray", options.wattpf_yarray || "1 0.98 0.95");
    g.setAttribute("wattvar_xarray", options.wattvar_xarray || "0.2 0.5 1");
    g.setAttribute("wattvar_yarray", options.wattvar_yarray || "0.44 0.22 0");

    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "0");

    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'PVSystem', 0.5, 1.1, 0, 0, null, true);
}

export function configureRegControlAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "RegControl");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("transformer", options.transformer || options.element || "");
    g.setAttribute("winding", String(options.winding ?? 2));
    g.setAttribute("vreg", String(options.vreg ?? 120));
    g.setAttribute("band", String(options.band ?? 3));
    g.setAttribute("ptratio", String(options.ptratio ?? 60));
    g.setAttribute("ctprim", String(options.ctprim ?? 300));
    g.setAttribute("delaying", String(options.delaying ?? options.delay ?? 15));
    g.setAttribute("enabled", String(options.enabled !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'RegControl', 0.5, 1.1, 0, 0, null, true);
}

export function configureCapControlAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "CapControl");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("capacitor", options.capacitor || options.element || "");
    g.setAttribute("type", options.type || "Voltage");
    g.setAttribute("on_setting", String(options.on_setting ?? 115));
    g.setAttribute("off_setting", String(options.off_setting ?? 125));
    g.setAttribute("ctratio", String(options.ctratio ?? 1));
    g.setAttribute("ptratio", String(options.ptratio ?? 1));
    g.setAttribute("delay", String(options.delay ?? 15));
    g.setAttribute("enabled", String(options.enabled !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'CapControl', 0.5, 1.1, 0, 0, null, true);
}

export function configureStorageControllerAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "StorageController");
    g.setAttribute("OpenDSS_parameters", "");
    g.setAttribute("element", Array.isArray(options.element) ? options.element.join(',') : (options.element || options.storage || ""));
    g.setAttribute("mode", options.mode || "PeakShave");
    g.setAttribute("kwtarget", String(options.kwtarget ?? options.kWTarget ?? 0));
    g.setAttribute("pct_reserve", String(options.pct_reserve ?? options.reserve ?? 20));
    g.setAttribute("enabled", String(options.enabled !== false));
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'StorageController', 0.5, 1.1, 0, 0, null, true);
}

export function configureWindTurbineControllerAttributes(grafka, vertex, options = {}) {
    var name = options.name || "WindTurbineController (steady-state)";
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("label", name);
    g.setAttribute("name", name);
    g.setAttribute("Controller_parameters", "");
    g.setAttribute("wind_turbine", options.wind_turbine || options.element || "");
    g.setAttribute("enabled", String(options.enabled !== false));
    g.setAttribute("power_curve_type", options.power_curve_type || "Turbine Power Curve");
    g.setAttribute("wind_speed_ms", String(options.wind_speed_ms ?? "10"));
    g.setAttribute("use_turbine_wind_speed", String(options.use_turbine_wind_speed !== false));
    g.setAttribute("wind_power_curve_json", options.wind_power_curve_json || defaultWindPowerCurveJson);
    g.setAttribute("wind_curve_approx", options.wind_curve_approx || "linear");
    // Label is drawn inside the rounded box via the object "label" attribute
    grafka.getModel().setValue(vertex, g);
}

export function configureWindTurbineDynamicControllerAttributes(grafka, vertex, options = {}) {
    var name = options.name || "WindTurbineController (dynamic)";
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("label", name);
    g.setAttribute("name", name);
    g.setAttribute("Controller_parameters", "");
    g.setAttribute("wind_turbine", options.wind_turbine || options.element || "");
    g.setAttribute("enabled", String(options.enabled !== false));
    g.setAttribute("wind_avg_T", String(options.wind_avg_T ?? "1"));
    g.setAttribute("wind_avg_Tavg", String(options.wind_avg_Tavg ?? "10"));
    g.setAttribute("power_avg_T", String(options.power_avg_T ?? "1"));
    g.setAttribute("power_avg_Tavg", String(options.power_avg_Tavg ?? "10"));
    g.setAttribute("gradient_T", String(options.gradient_T ?? "1"));
    g.setAttribute("gradient_max", String(options.gradient_max ?? "0.5"));
    grafka.getModel().setValue(vertex, g);
}

export function configureParkControllerAttributes(grafka, vertex, options = {}) {
    var name = options.name || "ParkController (steady-state)";
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("label", name);
    g.setAttribute("name", name);
    g.setAttribute("Controller_parameters", "");
    g.setAttribute("enabled", String(options.enabled !== false));
    g.setAttribute("machines_json", options.machines_json || "[]");
    g.setAttribute("control_mode", options.control_mode || "Voltage Control");
    g.setAttribute("node_selection", options.node_selection || "User Selection");
    g.setAttribute("uset_mode", options.uset_mode || "bus target voltage");
    g.setAttribute("controlled_bus", options.controlled_bus || "");
    g.setAttribute("target_bus", options.target_bus || "");
    g.setAttribute("vm_set_pu", String(options.vm_set_pu ?? "1.0"));
    g.setAttribute("enable_droop", String(options.enable_droop === true || options.enable_droop === "true"));
    g.setAttribute("q_rated_mvar", String(options.q_rated_mvar ?? "0"));
    g.setAttribute("droop_percent", String(options.droop_percent ?? "4"));
    g.setAttribute("q_measured_at", options.q_measured_at || "");
    g.setAttribute("q_control_type", options.q_control_type || "Const. Q");
    g.setAttribute("q_set_mvar", String(options.q_set_mvar ?? "0"));
    g.setAttribute("control_q_at", options.control_q_at || "");
    g.setAttribute("qv_characteristic_json", options.qv_characteristic_json || "[]");
    g.setAttribute("qp_characteristic_json", options.qp_characteristic_json || "[]");
    g.setAttribute("pf_control_type", options.pf_control_type || "Const. cosphi");
    g.setAttribute("cos_phi", String(options.cos_phi ?? "1.0"));
    g.setAttribute("cosphi_p_excitation", options.cosphi_p_excitation || "Overexcited");
    var cosphiPOe =
        options.cosphi_p_oe_characteristic_json ||
        options.cosphi_p_characteristic_json ||
        '[{"p_mw":7.5,"cos_phi":1}]';
    var cosphiPUe =
        options.cosphi_p_ue_characteristic_json ||
        '[{"p_mw":15,"cos_phi":0.95}]';
    g.setAttribute("cosphi_p_oe_characteristic_json", cosphiPOe);
    g.setAttribute("cosphi_p_ue_characteristic_json", cosphiPUe);
    g.setAttribute("cosphi_p_characteristic_json", cosphiPOe);
    g.setAttribute("cosphi_v_characteristic_json", options.cosphi_v_characteristic_json || "[]");
    g.setAttribute("tan_phi", String(options.tan_phi ?? "0"));
    g.setAttribute("distribution_method", options.distribution_method || "According to Rated Power");
    g.setAttribute("consider_q_dispatch", String(options.consider_q_dispatch !== false));
    g.setAttribute(
        "use_q_capability",
        String(options.use_q_capability !== false && options.use_q_capability !== 'false')
    );
    g.setAttribute("q_change_response", options.q_change_response || "same");
    grafka.getModel().setValue(vertex, g);
}

export function configureSVCAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "SVC");

    //INPUT                
    g.setAttribute("x_l_ohm", options.x_l_ohm || "0");
    g.setAttribute("x_cvar_ohm", options.x_cvar_ohm || "0");
    g.setAttribute("set_vm_pu", options.set_vm_pu || "0");
    g.setAttribute("thyristor_firing_angle_degree",  options.thyristor_firing_angle_degree ||"0");

    //OPTIONAL                
    g.setAttribute("controllable", options.controllable || "True");
    g.setAttribute("min_angle_degree", options.min_angle_degree || "90");
    g.setAttribute("max_angle_degree", options.max_angle_degree || "180");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'SVC', 0.5, 1.5, 0, 0, null, true);
}

export function configureTCSCAttributes(grafka, vertex, options = {}) {

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "TCSC");

    //INPUT                
    g.setAttribute("x_l_ohm", options.x_l_ohm ||"0");
    g.setAttribute("x_cvar_ohm", options.x_cvar_ohm || "0");
    g.setAttribute("set_p_to_mw", options.set_p_to_mw || "0");
    g.setAttribute("thyristor_firing_angle_degree", options.thyristor_firing_angle_degree || "0");

    //OPTIONAL                
    g.setAttribute("controllable", options.controllable || "True");
    g.setAttribute("min_angle_degree", options.min_angle_degree || "90");
    g.setAttribute("max_angle_degree", options.max_angle_degree || "180");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'TCSC', 0.5, 1.5, 0, 0, null, true);
}

export function configureSSCAttributes(grafka, vertex, options = {}) {
    var parametry = grafka.getModel().getValue(vertex);

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "SSC");

    //INPUT                
    g.setAttribute("r_ohm", options.r_ohm || "0");
    g.setAttribute("x_ohm", options.x_ohm || "0");
    g.setAttribute("set_vm_pu", options.set_vm_pu || "0");
    g.setAttribute("vm_internal_pu", options.vm_internal_pu || "0");
    g.setAttribute("va_internal_degree", options.va_internal_degree || "0");

    //OPTIONAL                
    g.setAttribute("controllable", options.controllable || "True");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    grafka.getModel().setValue(vertex, g)

    grafka.insertVertex(vertex, null, 'SSC', 0.5, 1.5, 0, 0, null, true);
}

export function configureDCLineAttributes(grafka, vertex, options = {}) {
    var parametry = grafka.getModel().getValue(vertex);

    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "DC Line");
    //INPUT
    g.setAttribute("Load_flow_parameters", "");  
    g.setAttribute("p_mw", options.p_mw || "0");
    g.setAttribute("loss_percent", options.loss_percent || "0");
    g.setAttribute("loss_mw", options.loss_mw || "0");
    g.setAttribute("vm_from_pu", options.vm_from_pu || "0");
    g.setAttribute("vm_to_pu", options.vm_to_pu || "0");

    // OPF (pandapower dcline — https://pandapower.readthedocs.io/en/latest/opf/pypower_run.html)
    g.setAttribute("OPF_parameters", "");
    g.setAttribute("max_p_mw", String(options.max_p_mw ?? "10"));
    g.setAttribute("min_q_from_mvar", String(options.min_q_from_mvar ?? ""));
    g.setAttribute("max_q_from_mvar", String(options.max_q_from_mvar ?? ""));
    g.setAttribute("min_q_to_mvar", String(options.min_q_to_mvar ?? ""));
    g.setAttribute("max_q_to_mvar", String(options.max_q_to_mvar ?? ""));
    g.setAttribute("opf_marginal_cost_eur_per_mwh", String(options.opf_marginal_cost_eur_per_mwh ?? ""));
    g.setAttribute("opf_cp2_eur_per_mw2", String(options.opf_cp2_eur_per_mw2 ?? ""));
    g.setAttribute("opf_cost_currency", String(options.opf_cost_currency ?? "EUR"));

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    //OPTIONAL
    //g.setAttribute("in_service", "True"); //in_service nie działa                               

    grafka.getModel().setValue(vertex, g) 

    grafka.insertVertex(vertex, null, '', 0.5, 0.5, 0, 0, null, true);
}


export function configureLineAttributes(grafka, vertex, options = {}) {
    var parametry = grafka.getModel().getValue(vertex);

    var g = mxUtils.createXmlDocument().createElement("object");


    g.setAttribute("from_bus", options.from_bus || "");
    g.setAttribute("to_bus", options.to_bus || "");
    g.setAttribute("length_km", options.length_km || "0");
    g.setAttribute("parallel", options.parallel || "1");
    g.setAttribute("df", options.df || "1");
    //możliwość wyboru z biblioteki
    g.setAttribute("parameters", true);
    g.setAttribute("name", options.name || "Line");

    //INPUT
    g.setAttribute("Load_flow_parameters", "");  
    g.setAttribute("r_ohm_per_km", options.r_ohm_per_km || "0");
    g.setAttribute("x_ohm_per_km", options.x_ohm_per_km || "0");
    g.setAttribute("c_nf_per_km", options.c_nf_per_km || "0");
    g.setAttribute("g_us_per_km", options.g_us_per_km || "0");
    g.setAttribute("max_i_ka", options.max_i_ka || "1");
    g.setAttribute("type", options.type || "cs");

    //Short circuit parameters
    g.setAttribute("r0_ohm_per_km", options.r0_ohm_per_km || "0.1");
    g.setAttribute("x0_ohm_per_km", options.x0_ohm_per_km || "0.1");
    g.setAttribute("c0_nf_per_km", options.c0_nf_per_km || "0.1");
    g.setAttribute("endtemp_degree", "0");  

    g.setAttribute("OPF_parameters", "");
    g.setAttribute("max_loading_percent", options.max_loading_percent != null ? String(options.max_loading_percent) : "0");

    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "0");

    grafka.getModel().setValue(vertex, g) 
}

export function configureDcBusAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    
    g.setAttribute("name", options.name || "DC Bus");
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("vn_kv", options.vn_kv || "0");
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");
    
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || "DC Bus", 0, -0.5, 0, 0, null, true);
}

export function configureLoadDcAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", "Load DC");
    
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("p_mw", options.p_mw || "0");
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");
    
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, '', 0.5, 0, 0, 0, null, true);
}

export function configureSourceDcAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Source DC");
    
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("vm_pu", options.vm_pu || "1.0");
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");
    
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'Source DC', 0.5, -0.25, 0, 0, null, true);
}

/** Update Switch cell style to show closed or open symbol based on closed attribute */
export function updateSwitchCellStyle(grafka, vertex, closed) {
    if (!grafka || !vertex) return;
    var style = grafka.getModel().getStyle(vertex) || "";
    if (typeof style !== "string" || style.indexOf("shapeELXXX=Switch") < 0) return;
    var imgClosed = "images/electrical/sym-switch-closed.svg";
    var imgOpen = "images/electrical/sym-switch.svg";
    var newImg = (closed === true || closed === "true") ? imgClosed : imgOpen;
    var newStyle = style.replace(/image=images\/electrical\/sym-switch(-closed)?\.svg/g, "image=" + newImg);
    if (newStyle !== style) grafka.setCellStyle(newStyle, [vertex]);
}

export function configureSwitchAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "Switch");
    
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("et", options.et || "l"); // element type: 'b'=bus-bus, 'l'=line, 't'=trafo, 't3'=trafo3w
    g.setAttribute("type", options.type || "CB"); // CB, LS, LBS, DS (pandapower)
    var closed = options.closed !== undefined ? options.closed : true;
    g.setAttribute("closed", closed);
    g.setAttribute("z_ohm", options.z_ohm || "0.0");
    g.setAttribute("in_ka", options.in_ka !== undefined ? String(options.in_ka) : "0");

    g.setAttribute("Short_circuit_parameters", "");
    g.setAttribute("ikss_ka", options.ikss_ka !== undefined ? String(options.ikss_ka) : "0");
    g.setAttribute("ansi_device_class", options.ansi_device_class || "auto");
    g.setAttribute("interrupting_rating_ka", options.interrupting_rating_ka !== undefined ? String(options.interrupting_rating_ka) : "0");
    g.setAttribute("momentary_rating_ka", options.momentary_rating_ka !== undefined ? String(options.momentary_rating_ka) : "0");
    g.setAttribute("rated_voltage_kv", options.rated_voltage_kv !== undefined ? String(options.rated_voltage_kv) : "0");
    g.setAttribute("contact_parting_cycles", options.contact_parting_cycles !== undefined ? String(options.contact_parting_cycles) : "3");
    g.setAttribute("generator_cb", options.generator_cb === true || options.generator_cb === "true" ? "true" : "false");
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");

    // Protection coordination defaults. The Switch dialog Protection tab populates
    // these for users who want OC relays / fuses; backend reads them from the JSON
    // payload and instantiates pandapower.protection devices on the matching switch.
    g.setAttribute("Protection_parameters", "");
    g.setAttribute("protection_type", options.protection_type || "none");
    g.setAttribute("oc_relay_type", options.oc_relay_type || "DTOC");
    g.setAttribute("curve_type", options.curve_type || "standard_inverse");
    g.setAttribute("tms", options.tms !== undefined ? String(options.tms) : "1.0");
    g.setAttribute("t_grade", options.t_grade !== undefined ? String(options.t_grade) : "0.5");
    g.setAttribute("t_gg", options.t_gg !== undefined ? String(options.t_gg) : "0.07");
    g.setAttribute("t_g", options.t_g !== undefined ? String(options.t_g) : "0.5");
    g.setAttribute("t_diff", options.t_diff !== undefined ? String(options.t_diff) : "0.3");
    g.setAttribute("pickup_mode", options.pickup_mode || "auto");
    g.setAttribute("I_s_a", options.I_s_a !== undefined ? String(options.I_s_a) : "0");
    g.setAttribute("I_g_a", options.I_g_a !== undefined ? String(options.I_g_a) : "0");
    g.setAttribute("I_gg_a", options.I_gg_a !== undefined ? String(options.I_gg_a) : "0");
    g.setAttribute("fuse_type", options.fuse_type || "");
    g.setAttribute("fuse_mode", options.fuse_mode || "library");
    g.setAttribute("fuse_custom_std_json", options.fuse_custom_std_json != null ? String(options.fuse_custom_std_json) : "");
    g.setAttribute("rated_i_a", options.rated_i_a !== undefined ? String(options.rated_i_a) : "0");
    g.setAttribute("overload_factor", options.overload_factor !== undefined ? String(options.overload_factor) : "1.25");
    g.setAttribute("ct_current_factor", options.ct_current_factor !== undefined ? String(options.ct_current_factor) : "1.2");
    g.setAttribute("safety_factor", options.safety_factor !== undefined ? String(options.safety_factor) : "1.0");
    g.setAttribute("I_e_a", options.I_e_a !== undefined ? String(options.I_e_a) : "100");
    g.setAttribute("t_e", options.t_e !== undefined ? String(options.t_e) : "0.2");
    g.setAttribute("directional_mode", options.directional_mode || "forward");
    g.setAttribute("I_diff_a", options.I_diff_a !== undefined ? String(options.I_diff_a) : "100");
    g.setAttribute("diff_slope", options.diff_slope !== undefined ? String(options.diff_slope) : "0.3");
    g.setAttribute("z1_r_ohm", options.z1_r_ohm !== undefined ? String(options.z1_r_ohm) : "1");
    g.setAttribute("z1_x_ohm", options.z1_x_ohm !== undefined ? String(options.z1_x_ohm) : "1");
    g.setAttribute("z2_r_ohm", options.z2_r_ohm !== undefined ? String(options.z2_r_ohm) : "2");
    g.setAttribute("z2_x_ohm", options.z2_x_ohm !== undefined ? String(options.z2_x_ohm) : "2");
    g.setAttribute("z3_r_ohm", options.z3_r_ohm !== undefined ? String(options.z3_r_ohm) : "3");
    g.setAttribute("z3_x_ohm", options.z3_x_ohm !== undefined ? String(options.z3_x_ohm) : "3");
    g.setAttribute("t_z1", options.t_z1 !== undefined ? String(options.t_z1) : "0");
    g.setAttribute("t_z2", options.t_z2 !== undefined ? String(options.t_z2) : "0.3");
    g.setAttribute("t_z3", options.t_z3 !== undefined ? String(options.t_z3) : "0.6");

    // Pandapower JSON import: branch refs when only one graph edge is drawn (Switch ↔ Bus).
    if (options.pp_import_bus) {
        g.setAttribute("pp_import_bus", String(options.pp_import_bus));
    }
    if (options.pp_import_element) {
        g.setAttribute("pp_import_element", String(options.pp_import_element));
    }

    grafka.getModel().setValue(vertex, g);
    updateSwitchCellStyle(grafka, vertex, closed);
}

export function configureVscAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "VSC");
    
    // VSC connects AC bus to DC bus - connections detected from diagram edges
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("r_ohm", options.r_ohm || "0.01");         // Coupling transformer resistance
    g.setAttribute("x_ohm", options.x_ohm || "0.1");          // Coupling transformer reactance
    g.setAttribute("r_dc_ohm", options.r_dc_ohm || "0.01");   // Internal DC resistance
    g.setAttribute("control_mode_ac", options.control_mode_ac || "vm_pu");  // 'vm_pu' or 'q_mvar'
    g.setAttribute("control_value_ac", options.control_value_ac || "1.0");  // AC control setpoint
    g.setAttribute("control_mode_dc", options.control_mode_dc || "p_mw");   // 'vm_pu' or 'p_mw'
    g.setAttribute("control_value_dc", options.control_value_dc || "0.0");  // DC control setpoint
    g.setAttribute("in_service", options.in_service !== undefined ? options.in_service : true);
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");
    
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'VSC', 0.5, 1.5, 0, 0, null, true);
}

export function configureB2bVscAttributes(grafka, vertex, options = {}) {
    var g = mxUtils.createXmlDocument().createElement("object");
    g.setAttribute("name", options.name || "B2B VSC");
    
    // B2B VSC connects AC bus to DC bus - connections detected from diagram edges
    g.setAttribute("Load_flow_parameters", "");
    g.setAttribute("r_ohm", options.r_ohm || "0.01");         // Coupling transformer resistance
    g.setAttribute("x_ohm", options.x_ohm || "0.1");          // Coupling transformer reactance
    g.setAttribute("r_dc_ohm", options.r_dc_ohm || "0.01");   // Internal DC resistance
    g.setAttribute("control_mode_ac", options.control_mode_ac || "vm_pu");  // 'vm_pu' or 'q_mvar'
    g.setAttribute("control_value_ac", options.control_value_ac || "1.0");  // AC control setpoint
    g.setAttribute("control_mode_dc", options.control_mode_dc || "p_mw");   // 'vm_pu' or 'p_mw'
    g.setAttribute("control_value_dc", options.control_value_dc || "0.0");  // DC control setpoint
    g.setAttribute("in_service", options.in_service !== undefined ? options.in_service : true);
    
    // Economic parameters
    g.setAttribute("Economic_parameters", "");
    g.setAttribute("cost_per_unit_by_currency", options.cost_per_unit_by_currency || "{}");
    
    grafka.getModel().setValue(vertex, g);
    grafka.insertVertex(vertex, null, options.name || 'B2B VSC', 0.5, 1.5, 0, 0, null, true);
}

// Make all configure functions globally available for app.min.js
if (typeof window !== 'undefined') {
    window.configureExternalGridAttributes = configureExternalGridAttributes;
    window.configureGeneratorAttributes = configureGeneratorAttributes;
    window.configureStaticGeneratorAttributes = configureStaticGeneratorAttributes;
    window.configureWindTurbineAttributes = configureWindTurbineAttributes;
    window.configureAsymmetricStaticGeneratorAttributes = configureAsymmetricStaticGeneratorAttributes;
    window.configureBusAttributes = configureBusAttributes;
    window.configureTransformerAttributes = configureTransformerAttributes;
    window.configureThreeWindingTransformerAttributes = configureThreeWindingTransformerAttributes;
    window.configureShuntReactorAttributes = configureShuntReactorAttributes;
    window.configureCapacitorAttributes = configureCapacitorAttributes;
    window.configureLoadAttributes = configureLoadAttributes;
    window.configureAsymmetricLoadAttributes = configureAsymmetricLoadAttributes;
    window.configureImpedanceAttributes = configureImpedanceAttributes;
    window.configureWardAttributes = configureWardAttributes;
    window.configureExtendedWardAttributes = configureExtendedWardAttributes;
    window.configureMotorAttributes = configureMotorAttributes;
    window.configureStorageAttributes = configureStorageAttributes;
    window.configurePVSystemAttributes = configurePVSystemAttributes;
    window.configureRegControlAttributes = configureRegControlAttributes;
    window.configureCapControlAttributes = configureCapControlAttributes;
    window.configureStorageControllerAttributes = configureStorageControllerAttributes;
    window.configureWindTurbineControllerAttributes = configureWindTurbineControllerAttributes;
    window.configureWindTurbineDynamicControllerAttributes = configureWindTurbineDynamicControllerAttributes;
    window.configureParkControllerAttributes = configureParkControllerAttributes;
    window.configureLoad1phAttributes = configureLoad1phAttributes;
    window.configureSource1phAttributes = configureSource1phAttributes;
    window.configureGenerator1phAttributes = configureGenerator1phAttributes;
    window.configureTransformer1phAttributes = configureTransformer1phAttributes;
    window.configureLine1phAttributes = configureLine1phAttributes;
    window.configureSVCAttributes = configureSVCAttributes;
    window.configureTCSCAttributes = configureTCSCAttributes;
    window.configureSSCAttributes = configureSSCAttributes;
    window.configureDCLineAttributes = configureDCLineAttributes;
    window.configureLineAttributes = configureLineAttributes;
    window.configureDcBusAttributes = configureDcBusAttributes;
    window.configureLoadDcAttributes = configureLoadDcAttributes;
    window.configureSourceDcAttributes = configureSourceDcAttributes;
    window.configureSwitchAttributes = configureSwitchAttributes;
    window.updateSwitchCellStyle = updateSwitchCellStyle;
    window.configureVscAttributes = configureVscAttributes;
    window.configureB2bVscAttributes = configureB2bVscAttributes;
}



