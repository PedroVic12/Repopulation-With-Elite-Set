/**
 * Converts map editor data to mxGraph electrical model
 * Creates buses, components from palette, and lines with length_km from map coordinates
 */

import { NODE_TYPES } from './MapEditor.js';
import { OFFSHORE_66KV_AL_CABLES } from '../lineLibraryDialog.js';
import { ELECTRICAL_SYMBOLS, vertexStyleImportedBusbar } from '../electricalSymbols.js';

function symWh(symbolKey) {
    const o = ELECTRICAL_SYMBOLS[symbolKey];
    return [o.w, o.h];
}
import {
    configureBusAttributes,
    configureExternalGridAttributes,
    configureGeneratorAttributes,
    configureStaticGeneratorAttributes,
    configureTransformerAttributes,
    configureThreeWindingTransformerAttributes,
    configureShuntReactorAttributes,
    configureCapacitorAttributes,
    configureLoadAttributes,
    configureAsymmetricLoadAttributes,
    configureImpedanceAttributes,
    configureWardAttributes,
    configureExtendedWardAttributes,
    configureMotorAttributes,
    configureStorageAttributes,
    configureSVCAttributes,
    configureSSCAttributes,
    configureDcBusAttributes,
    configureLoadDcAttributes,
    configureSourceDcAttributes,
    configureVscAttributes,
    configureB2bVscAttributes,
    configureLineAttributes
} from '../configureAttributes.js';

// ── Styles using electrical_symbols.svg from website ────────────────────────

const IMG_BASE = 'pointerEvents=1;verticalLabelPosition=bottom;shadow=0;dashed=0;align=center;html=1;verticalAlign=top;aspect=fixed;imageAspect=1;fillColor=none;strokeColor=none;';

const BUS_STYLE    = vertexStyleImportedBusbar('Bus');
const DC_BUS_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-dc-bus'].url + ';shapeELXXX=DC Bus';

const EXTERNAL_GRID_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-ext-grid'].url + ';shapeELXXX=External Grid';
const GENERATOR_STYLE     = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-generator'].url + ';shapeELXXX=Generator';
const STATIC_GEN_STYLE    = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-static-gen'].url + ';shapeELXXX=Static Generator';
const SOURCE_DC_STYLE     = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-source-dc'].url + ';shapeELXXX=Source DC';

const TRANSFORMER_STYLE    = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-transformer'].url + ';shapeELXXX=Transformer';
/** Vertical windings (HV top / LV bottom) for stacked bus compounds (offshore WT / substation). */
const TRANSFORMER_V_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-transformer-v'].url + ';shapeELXXX=Transformer';
const TRANSFORMER_3W_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-3w-transformer'].url + ';shapeELXXX=Three Winding Transformer';

const SHUNT_REACTOR_STYLE = 'pointerEvents=1;verticalLabelPosition=bottom;shadow=0;dashed=0;align=center;html=1;verticalAlign=top;shape=mxgraph.electrical.inductors.choke;shapeELXXX=Shunt Reactor';
const CAPACITOR_STYLE     = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-capacitor'].url + ';shapeELXXX=Capacitor';
const GROUND_STYLE        = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-load'].url + ';shapeELXXX=Ground';

const LOAD_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-load'].url + ';shapeELXXX=Load';
const ALOAD_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-asym-load'].url + ';shapeELXXX=Asymmetric Load';
const IMPEDANCE_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-impedance'].url + ';shapeELXXX=Impedance';
const WARD_STYLE   = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-ward'].url + ';shapeELXXX=Ward';
const EXWARD_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-ext-ward'].url + ';shapeELXXX=Extended Ward';

const MOTOR_STYLE   = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-motor'].url + ';shapeELXXX=Motor';
const STORAGE_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-storage'].url + ';shapeELXXX=Storage';

const SVC_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-svc'].url + ';shapeELXXX=SVC';
const TCSC_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-tcsc'].url + ';shapeELXXX=TCSC';
const SSC_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-ssc'].url + ';shapeELXXX=SSC';

const LOAD_DC_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-load-dc'].url + ';shapeELXXX=Load DC';
const SWITCH_STYLE   = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-switch'].url + ';shapeELXXX=Switch';
const VSC_STYLE      = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-vsc'].url + ';shapeELXXX=VSC';
const B2B_VSC_STYLE  = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-b2b-vsc'].url + ';shapeELXXX=B2B VSC';
const PVSYSTEM_STYLE = IMG_BASE + 'shape=image;image=' + ELECTRICAL_SYMBOLS['sym-pv'].url + ';shapeELXXX=PVSystem';

const LINE_STYLE_BASE = 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=0;html=1;shapeELXXX=Line';
const NOT_EDITABLE_LINE  = 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;entryX=0.5;entryY=0.5;shapeELXXX=NotEditableLine';
/** Straight vertical edges for wind turbine compound: fully specified with Dx/Dy/Perimeter=0 */
const WT_EDGE_DOWN = 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=1;exitDx=0;exitDy=0;exitPerimeter=0;entryX=0.5;entryY=0.5;entryDx=0;entryDy=0;entryPerimeter=0;shapeELXXX=NotEditableLine';
const WT_EDGE_UP   = 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;exitX=0.5;exitY=0;exitDx=0;exitDy=0;exitPerimeter=0;entryX=0.5;entryY=0.5;entryDx=0;entryDy=0;entryPerimeter=0;shapeELXXX=NotEditableLine';

// ── Layout constants ───────────────────────────────────────────────────────

const BUS_W = 260;
const BUS_H = 12;
const COL_SPACING = 480;
const ROW_SPACING = 420;
const MAX_COLS = 4;
const COMP_GAP = 45;
const CABLE_DROP = 60;
const CABLE_LANE_SPACING = 35;
const SUBSTATION_BLOCK_GAP = 120;

const ABOVE_BUS_TYPES = new Set([
    NODE_TYPES.ONSHORE_GRID, NODE_TYPES.WIND_TURBINE,
    NODE_TYPES.STATIC_GENERATOR, NODE_TYPES.SOURCE_DC
]);

/** Offshore wind turbine: LV (0.69 kV) and HV (66 kV) voltage levels */
const WIND_TURBINE_VN_LV_KV = '0.69';
const WIND_TURBINE_VN_HV_KV = '66';

/** Offshore substation: 66 kV (wind farm side) and 275 kV (export side) */
const OFFSHORE_SUBSTATION_VN_LV_KV = '66';
const OFFSHORE_SUBSTATION_VN_HV_KV = '275';

const TURBINE_COL_SPACING = 480;
const STRING_ROW_SPACING = 420;
const SUBSTATION_OFFSET_RIGHT = 300;

/** Default turbine power (MW) for load-based cable sizing */
const DEFAULT_TURBINE_P_MW = 15;
/** 66 kV, 3-phase, ~0.95 pf: I (kA) ≈ P_MW / (√3 × 66 × 0.95) */
const I_KA_PER_MW_66KV = 1 / (Math.sqrt(3) * 66 * 0.95);

/**
 * Compute number of turbines feeding through each cable (for offshore 66 kV sizing).
 * Removes cable, gets component without substation; count = turbines in that component.
 */
function computeTurbineCountPerCable(nodes, cables) {
    const nodeById = new Map(nodes.map(n => [n.id, n]));
    const isTurbine = (id) => nodeById.get(id)?.type === NODE_TYPES.OFFSHORE_WIND_TURBINE;
    const isSubstation = (id) => nodeById.get(id)?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
    const adj = (excludeFrom, excludeTo) => {
        const m = new Map();
        for (const c of cables) {
            if ((c.from === excludeFrom && c.to === excludeTo) || (c.from === excludeTo && c.to === excludeFrom)) continue;
            if (!m.has(c.from)) m.set(c.from, []);
            m.get(c.from).push(c.to);
            if (!m.has(c.to)) m.set(c.to, []);
            m.get(c.to).push(c.from);
        }
        return m;
    };
    const bfsCount = (start, excludeFrom, excludeTo, countTurbines) => {
        const a = adj(excludeFrom, excludeTo);
        const visited = new Set();
        const q = [start];
        visited.add(start);
        let count = 0;
        while (q.length > 0) {
            const cur = q.shift();
            if (countTurbines && isTurbine(cur)) count++;
            for (const nb of (a.get(cur) || [])) {
                if (!visited.has(nb)) { visited.add(nb); q.push(nb); }
            }
        }
        return count;
    };
    const hasSubstation = (start, excludeFrom, excludeTo) => {
        const a = adj(excludeFrom, excludeTo);
        const visited = new Set();
        const q = [start];
        visited.add(start);
        while (q.length > 0) {
            const cur = q.shift();
            if (isSubstation(cur)) return true;
            for (const nb of (a.get(cur) || [])) {
                if (!visited.has(nb)) { visited.add(nb); q.push(nb); }
            }
        }
        return false;
    };
    const map = new Map();
    for (const c of cables) {
        const fromHasSub = hasSubstation(c.from, c.from, c.to);
        const toHasSub = hasSubstation(c.to, c.from, c.to);
        const sourceStart = fromHasSub ? c.to : c.from;
        const turbineCount = bfsCount(sourceStart, c.from, c.to, true);
        map.set(`${c.from}-${c.to}`, turbineCount);
        map.set(`${c.to}-${c.from}`, turbineCount);
    }
    return map;
}

/**
 * Select Offshore 66kV Al cable by estimated load current. Returns cable def or null.
 */
function selectOffshore66kVAlCable(turbineCount, pMwPerTurbine = DEFAULT_TURBINE_P_MW) {
    const pMw = turbineCount * pMwPerTurbine;
    const iKa = pMw * I_KA_PER_MW_66KV;
    const chosen = OFFSHORE_66KV_AL_CABLES.find(c => (c.max_i_ka || 0) >= iKa);
    return chosen || OFFSHORE_66KV_AL_CABLES[OFFSHORE_66KV_AL_CABLES.length - 1];
}

/**
 * Topology-aware layout for offshore wind farm: turbines in horizontal strings
 * (left-to-right within each string), strings stacked vertically, substation on the right.
 */
function computeOffshoreWindFarmLayout(nodes, cables) {
    const idToIdx = new Map();
    nodes.forEach((nd, i) => idToIdx.set(nd.id, i));

    const turbines = nodes.filter(n => n.type === NODE_TYPES.OFFSHORE_WIND_TURBINE);
    const substations = nodes.filter(n => n.type === NODE_TYPES.OFFSHORE_SUBSTATION);
    if (turbines.length === 0 || substations.length === 0) return null;

    const adj = new Map();
    cables.forEach(c => {
        const a = c.from, b = c.to;
        if (!adj.has(a)) adj.set(a, new Set());
        if (!adj.has(b)) adj.set(b, new Set());
        adj.get(a).add(b);
        adj.get(b).add(a);
    });

    const substationIds = new Set(substations.map(s => s.id));
    const turbineIds = new Set(turbines.map(t => t.id));

    const getTurbineNeighbors = (id) => [...(adj.get(id) || [])].filter(n => turbineIds.has(n));

    const visited = new Set();
    const strings = [];

    for (const t of turbines) {
        if (visited.has(t.id)) continue;
        const queue = [t.id];
        visited.add(t.id);
        const component = [t.id];
        while (queue.length > 0) {
            const cur = queue.shift();
            for (const nb of getTurbineNeighbors(cur)) {
                if (!visited.has(nb)) {
                    visited.add(nb);
                    queue.push(nb);
                    component.push(nb);
                }
            }
        }
        if (component.length > 0) {
            const deg = (id) => getTurbineNeighbors(id).length;
            const endpoint = component.find(id => deg(id) === 1) || component[0];
            const ordered = [endpoint];
            const remaining = new Set(component);
            remaining.delete(endpoint);
            let current = endpoint;
            while (remaining.size > 0) {
                const neighbors = getTurbineNeighbors(current).filter(n => remaining.has(n));
                if (neighbors.length === 0) break;
                current = neighbors[0];
                ordered.push(current);
                remaining.delete(current);
            }
            if (remaining.size > 0) ordered.push(...remaining);
            strings.push(ordered);
        }
    }

    const nodeById = new Map();
    nodes.forEach(n => nodeById.set(n.id, n));
    const geoDist = (a, b) => {
        const dx = (a.lat || 0) - (b.lat || 0);
        const dy = (a.lng || 0) - (b.lng || 0);
        return Math.sqrt(dx * dx + dy * dy);
    };
    const sub0 = substations[0];

    strings.forEach(ordered => {
        const closestIdx = ordered.reduce((best, id, i) => {
            const d = geoDist(nodeById.get(id), sub0);
            return d < best.d ? { d, i } : best;
        }, { d: Infinity, i: 0 }).i;
        if (closestIdx < ordered.length / 2) ordered.reverse();
    });

    strings.sort((a, b) => {
        const minDistA = Math.min(...a.map(id => geoDist(nodeById.get(id), sub0)));
        const minDistB = Math.min(...b.map(id => geoDist(nodeById.get(id), sub0)));
        return minDistA - minDistB;
    });

    const reordered = new Array(strings.length);
    const mid = Math.floor(strings.length / 2);
    for (let i = 0; i < strings.length; i++) {
        reordered[mid + (i % 2 === 0 ? Math.floor(i / 2) : -Math.ceil(i / 2))] = strings[i];
    }
    const validReordered = reordered.filter(Boolean);
    while (validReordered.length < strings.length) validReordered.push(strings[validReordered.length]);
    for (let i = 0; i < strings.length; i++) strings[i] = validReordered[i];

    const positions = new Array(nodes.length);
    const maxTurbinesInString = Math.max(1, ...strings.map(s => s.length));
    const substationX = maxTurbinesInString * TURBINE_COL_SPACING + SUBSTATION_OFFSET_RIGHT;
    const centerY = strings.length > 0 ? (strings.length - 1) * STRING_ROW_SPACING / 2 : 0;

    strings.forEach((string, rowIndex) => {
        string.forEach((nodeId, colIndex) => {
            const idx = idToIdx.get(nodeId);
            if (idx !== undefined) {
                positions[idx] = {
                    x: colIndex * TURBINE_COL_SPACING,
                    y: rowIndex * STRING_ROW_SPACING
                };
            }
        });
    });

    substations.forEach((sub, i) => {
        const idx = idToIdx.get(sub.id);
        if (idx !== undefined) {
            positions[idx] = {
                x: substationX + (i - (substations.length - 1) / 2) * TURBINE_COL_SPACING * 0.5,
                y: centerY
            };
        }
    });

    const others = nodes.filter(n => n.type !== NODE_TYPES.OFFSHORE_WIND_TURBINE && n.type !== NODE_TYPES.OFFSHORE_SUBSTATION);
    others.forEach((nd, i) => {
        const idx = idToIdx.get(nd.id);
        if (idx !== undefined && positions[idx] === undefined) {
            positions[idx] = {
                x: substationX + (strings.length + i) * TURBINE_COL_SPACING,
                y: 0
            };
        }
    });

    return positions;
}

/**
 * Order nodes by map position (left-to-right = increasing lng) then lay them out in a grid.
 * Offshore substations are placed last to avoid overlap with wind turbine compounds.
 * Returns [{ x, y }] indexed by node index.
 */
function computeGridPositions(nodes, cables) {
    const n = nodes.length;
    if (n === 0) return [];

    const offshoreLayout = computeOffshoreWindFarmLayout(nodes, cables);
    if (offshoreLayout) return offshoreLayout;

    const idToIdx = new Map();
    nodes.forEach((nd, i) => idToIdx.set(nd.id, i));

    const hasMapCoords = nodes.some(nd => typeof nd.lng === 'number' && typeof nd.lat === 'number');
    const sortByMap = (indices) => indices.sort((i, j) => {
        const a = nodes[i], b = nodes[j];
        const lngA = typeof a.lng === 'number' ? a.lng : 0;
        const lngB = typeof b.lng === 'number' ? b.lng : 0;
        if (lngA !== lngB) return lngA - lngB;
        const latA = typeof a.lat === 'number' ? a.lat : 0;
        const latB = typeof b.lat === 'number' ? b.lat : 0;
        return latB - latA;
    });

    const turbinesAndOthers = [...Array(n).keys()].filter(i => nodes[i].type !== NODE_TYPES.OFFSHORE_SUBSTATION);
    const substations = [...Array(n).keys()].filter(i => nodes[i].type === NODE_TYPES.OFFSHORE_SUBSTATION);
    const order = hasMapCoords
        ? [...sortByMap(turbinesAndOthers), ...sortByMap(substations)]
        : [...turbinesAndOthers, ...substations];

    const numTurbines = turbinesAndOthers.length;
    const numSubstations = substations.length;
    const positions = new Array(n);
    const substationStartRow = Math.floor(numTurbines / MAX_COLS);
    order.forEach((idx, seqPos) => {
        const col = seqPos % MAX_COLS;
        const row = Math.floor(seqPos / MAX_COLS);
        const isInSubstationBlock = row >= substationStartRow && numSubstations > 0;
        positions[idx] = {
            x: col * COL_SPACING,
            y: row * ROW_SPACING + (isInSubstationBlock ? SUBSTATION_BLOCK_GAP : 0)
        };
    });
    return positions;
}

/**
 * Convert map data to mxGraph diagram
 */
export function mapToElectricalModel(graph, mapData, point = { x: 100, y: 100 }) {
    if (!graph || !mapData || !mapData.nodes || mapData.nodes.length === 0) {
        throw new Error('Invalid map data: need at least one node');
    }

    const parent = graph.getDefaultParent();
    const scale = graph.view.scale;
    const tr = graph.view.translate;
    const baseX = (point.x || 100) / scale - tr.x;
    const baseY = (point.y || 100) / scale - tr.y;

    const nodes = mapData.nodes;
    const cables = mapData.cables || [];
    const positions = computeGridPositions(nodes, cables);

    const nodeToVertex = new Map();
    const busesForResultBoxes = [];

    graph.getModel().beginUpdate();
    try {
        // 1. Create buses
        nodes.forEach((node, i) => {
            const bx = baseX + positions[i].x;
            const by = baseY + positions[i].y;
            const isDc = node.type === NODE_TYPES.DC_BUS;
            const isOffshoreWT = node.type === NODE_TYPES.OFFSHORE_WIND_TURBINE;
            const isOffshoreSub = node.type === NODE_TYPES.OFFSHORE_SUBSTATION;
            const vnKv = isOffshoreWT ? WIND_TURBINE_VN_HV_KV
                : isOffshoreSub ? OFFSHORE_SUBSTATION_VN_HV_KV
                : String(node.vn_kv || 110);
            const busVertex = graph.insertVertex(
                parent, null, '',
                bx, by, BUS_W, BUS_H,
                isDc ? DC_BUS_STYLE : BUS_STYLE
            );
            const cfgFn = isDc ? configureDcBusAttributes : configureBusAttributes;
            const busName = isOffshoreSub ? (node.name || node.id) + '_275' : (node.name || node.id);
            cfgFn(graph, busVertex, {
                name: busName,
                vn_kv: vnKv
            });
            const entry = { bus: busVertex, node };
            if (isOffshoreSub) entry.bus275 = busVertex;
            nodeToVertex.set(node.id, entry);
            busesForResultBoxes.push(busVertex);
        });

        // 2. Create components and connect to buses
        nodes.forEach((node) => {
            const { bus } = nodeToVertex.get(node.id);
            if (!bus) return;

            const geo = graph.getCellGeometry(bus);
            const bx = geo.x;
            const by = geo.y;
            const bw = geo.width;
            const vn = String(node.vn_kv || 110);
            const above = ABOVE_BUS_TYPES.has(node.type);

            const insertComp = (style, w, h, cfgFn, opts = {}) => {
                const cx = bx + bw / 2 - w / 2;
                const cy = above ? by - h - COMP_GAP : by + BUS_H + COMP_GAP;
                const v = graph.insertVertex(parent, null, '', cx, cy, w, h, style);
                if (cfgFn) cfgFn(graph, v, opts);
                graph.insertEdge(parent, null, '', v, bus, NOT_EDITABLE_LINE);
            };

            switch (node.type) {
                // ── Offshore Wind Turbine: Static Gen + LV Bus (0.69 kV) + Transformer (0.69/66 kV) + HV Bus (66 kV) ──
                case NODE_TYPES.OFFSHORE_WIND_TURBINE: {
                    const hvBus = bus;
                    const centerX = bx + bw / 2;

                    // LV bus (0.69 kV) above HV bus (66 kV)
                    const lvBusY = by - 170;
                    const lvBus = graph.insertVertex(parent, null, '', bx, lvBusY, BUS_W, BUS_H, BUS_STYLE);
                    configureBusAttributes(graph, lvBus, {
                        name: (node.name || node.id) + '_LV',
                        vn_kv: WIND_TURBINE_VN_LV_KV
                    });
                    busesForResultBoxes.push(lvBus);

                    // Static gen above LV bus, rotated 180° so output faces down
                    const pMw = String(node.p_mw || 15);
                    const [sgenW, sgenH] = symWh('sym-static-gen');
                    const sgenX = centerX - sgenW / 2;
                    const sgenY = lvBusY - 70 - sgenH;
                    const sgenStyle = STATIC_GEN_STYLE + ';rotation=180';
                    const staticGen = graph.insertVertex(parent, null, '', sgenX, sgenY, sgenW, sgenH, sgenStyle);
                    configureStaticGeneratorAttributes(graph, staticGen, { p_mw: pMw, q_mvar: '0', sn_mva: String(Number(pMw) * 1.2) });
                    graph.insertEdge(parent, null, '', staticGen, lvBus, WT_EDGE_UP);

                    // Vertical trafo: LV bus above, HV bus below → rotate 180° so LV winding faces up.
                    const [trafoW, trafoH] = symWh('sym-transformer-v');
                    const trafoX = centerX - trafoW / 2;
                    const trafoY = lvBusY + BUS_H + (by - lvBusY - BUS_H - trafoH) / 2;
                    const trafoStyleRotated = TRANSFORMER_V_STYLE + 'rotation=180;';
                    const trafo = graph.insertVertex(parent, null, '', trafoX, trafoY, trafoW, trafoH, trafoStyleRotated);
                    configureTransformerAttributes(graph, trafo, {
                        name: (node.name || node.id) + '_trafo',
                        vn_hv_kv: WIND_TURBINE_VN_HV_KV,
                        vn_lv_kv: WIND_TURBINE_VN_LV_KV,
                        sn_mva: String(Number(pMw) * 1.2)
                    });
                    // Local bottom (LV in SVG) faces up after 180° → LV bus; local top (HV) faces down → HV bus.
                    graph.insertEdge(parent, null, '', trafo, lvBus, WT_EDGE_DOWN);
                    graph.insertEdge(parent, null, '', trafo, hvBus, WT_EDGE_UP);
                    break;
                }

                // ── Sources (above bus) ──
                case NODE_TYPES.ONSHORE_GRID:
                    insertComp(EXTERNAL_GRID_STYLE, ...symWh('sym-ext-grid'), configureExternalGridAttributes, { vm_pu: '1', va_degree: '0' });
                    break;
                case NODE_TYPES.WIND_TURBINE:
                    insertComp(GENERATOR_STYLE, ...symWh('sym-generator'), configureGeneratorAttributes, {
                        p_mw: String(node.p_mw || 15), vm_pu: '1', sn_mva: String((node.p_mw || 15) * 1.2)
                    });
                    break;
                case NODE_TYPES.STATIC_GENERATOR:
                    insertComp(STATIC_GEN_STYLE, ...symWh('sym-static-gen'), configureStaticGeneratorAttributes, {
                        p_mw: String(node.p_mw || 0), q_mvar: '0', sn_mva: '0'
                    });
                    break;
                case NODE_TYPES.SOURCE_DC:
                    insertComp(SOURCE_DC_STYLE, ...symWh('sym-source-dc'), configureSourceDcAttributes, { vm_pu: '1.0' });
                    break;

                // ── Offshore Substation: 275 kV bus (top) + Transformer (66/275 kV) + 66 kV bus (bottom) ──
                case NODE_TYPES.OFFSHORE_SUBSTATION: {
                    const bus275 = bus;
                    const centerX = bx + bw / 2;

                    // Vertical trafo between 275 kV (above) and 66 kV (below) — HV top / LV bottom.
                    const [trafoW, trafoH] = symWh('sym-transformer-v');
                    const trafoX = centerX - trafoW / 2;
                    const trafoY = by + BUS_H + COMP_GAP;
                    const trafo = graph.insertVertex(parent, null, '', trafoX, trafoY, trafoW, trafoH, TRANSFORMER_V_STYLE);
                    configureTransformerAttributes(graph, trafo, {
                        name: (node.name || node.id) + '_trafo',
                        vn_hv_kv: OFFSHORE_SUBSTATION_VN_HV_KV,
                        vn_lv_kv: OFFSHORE_SUBSTATION_VN_LV_KV,
                        sn_mva: String(node.sn_mva || 100)
                    });
                    graph.insertEdge(parent, null, '', trafo, bus275, WT_EDGE_UP);

                    // 66 kV bus below transformer
                    const bus66Y = trafoY + trafoH + COMP_GAP;
                    const bus66 = graph.insertVertex(parent, null, '', bx, bus66Y, BUS_W, BUS_H, BUS_STYLE);
                    configureBusAttributes(graph, bus66, {
                        name: (node.name || node.id) + '_66',
                        vn_kv: OFFSHORE_SUBSTATION_VN_LV_KV
                    });
                    busesForResultBoxes.push(bus66);
                    graph.insertEdge(parent, null, '', trafo, bus66, WT_EDGE_DOWN);

                    const entry = nodeToVertex.get(node.id);
                    if (entry) entry.bus66 = bus66;
                    break;
                }

                // ── Transformers (below bus) ──
                case NODE_TYPES.TRANSFORMER_3W:
                    insertComp(TRANSFORMER_3W_STYLE, ...symWh('sym-3w-transformer'), configureThreeWindingTransformerAttributes);
                    break;

                // ── Compensation (below bus) ──
                case NODE_TYPES.SHUNT_REACTOR:
                    insertComp(SHUNT_REACTOR_STYLE, 28, 56, configureShuntReactorAttributes, { q_mvar: String(node.q_mvar || 0), vn_kv: vn });
                    break;
                case NODE_TYPES.CAPACITOR:
                    insertComp(CAPACITOR_STYLE, ...symWh('sym-capacitor'), configureCapacitorAttributes, { q_mvar: String(node.q_mvar || 0), vn_kv: vn });
                    break;
                case NODE_TYPES.GROUND:
                    insertComp(GROUND_STYLE, ...symWh('sym-load'), null);
                    break;

                // ── Load / Impedance / Ward (below bus) ──
                case NODE_TYPES.LOAD:
                    insertComp(LOAD_STYLE, ...symWh('sym-load'), configureLoadAttributes, { p_mw: String(node.p_mw || 0), q_mvar: '0', sn_mva: '0' });
                    break;
                case NODE_TYPES.LOAD_ASYMMETRIC:
                    insertComp(ALOAD_STYLE, ...symWh('sym-asym-load'), configureAsymmetricLoadAttributes);
                    break;
                case NODE_TYPES.IMPEDANCE:
                    insertComp(IMPEDANCE_STYLE, ...symWh('sym-impedance'), configureImpedanceAttributes);
                    break;
                case NODE_TYPES.WARD:
                    insertComp(WARD_STYLE, ...symWh('sym-ward'), configureWardAttributes);
                    break;
                case NODE_TYPES.EXTENDED_WARD:
                    insertComp(EXWARD_STYLE, ...symWh('sym-ext-ward'), configureExtendedWardAttributes);
                    break;

                // ── Rotating (below bus) ──
                case NODE_TYPES.MOTOR:
                    insertComp(MOTOR_STYLE, ...symWh('sym-motor'), configureMotorAttributes, { pn_mech_mw: String(node.p_mw || 0), vn_kv: vn });
                    break;

                // ── Storage (below bus) ──
                case NODE_TYPES.STORAGE:
                    insertComp(STORAGE_STYLE, ...symWh('sym-storage'), configureStorageAttributes, { p_mw: String(node.p_mw || 0) });
                    break;

                // ── Pandapower-only (below bus) ──
                case NODE_TYPES.SVC:
                    insertComp(SVC_STYLE, ...symWh('sym-svc'), configureSVCAttributes);
                    break;
                case NODE_TYPES.SSC:
                    insertComp(SSC_STYLE, ...symWh('sym-ssc'), configureSSCAttributes);
                    break;
                case NODE_TYPES.TCSC:
                    insertComp(TCSC_STYLE, ...symWh('sym-tcsc'), null);
                    break;
                case NODE_TYPES.SWITCH:
                    insertComp(SWITCH_STYLE, ...symWh('sym-switch'), null);
                    break;
                case NODE_TYPES.DC_LINE:
                    break;
                case NODE_TYPES.LOAD_DC:
                    insertComp(LOAD_DC_STYLE, ...symWh('sym-load-dc'), configureLoadDcAttributes, { p_mw: String(node.p_mw || 0) });
                    break;
                case NODE_TYPES.VSC:
                    insertComp(VSC_STYLE, ...symWh('sym-vsc'), configureVscAttributes);
                    break;
                case NODE_TYPES.B2B_VSC:
                    insertComp(B2B_VSC_STYLE, ...symWh('sym-b2b-vsc'), configureB2bVscAttributes);
                    break;

                // ── OpenDSS (below bus) ──
                case NODE_TYPES.PVSYSTEM:
                    insertComp(PVSYSTEM_STYLE, ...symWh('sym-pv'), null);
                    break;

                // ── Bus-only types ──
                case NODE_TYPES.BUS:
                case NODE_TYPES.DC_BUS:
                default:
                    break;
            }
        });

        // 3. Create lines between buses
        const getBusForCable = (entry, otherEntry) => {
            if (!entry.bus275) return entry.bus;
            const otherType = otherEntry?.node?.type;
            const use275 = otherType === NODE_TYPES.ONSHORE_GRID || otherType === NODE_TYPES.BUS;
            return use275 ? entry.bus275 : entry.bus66 || entry.bus;
        };

        let globalMinBusY = Infinity;
        cables.forEach((cable) => {
            const fromEntry = nodeToVertex.get(cable.from);
            const toEntry = nodeToVertex.get(cable.to);
            if (!fromEntry || !toEntry) return;
            const fromBus = getBusForCable(fromEntry, toEntry);
            const toBus = getBusForCable(toEntry, fromEntry);
            const fromGeo = graph.getCellGeometry(fromBus);
            const toGeo = graph.getCellGeometry(toBus);
            globalMinBusY = Math.min(globalMinBusY, fromGeo.y, toGeo.y);
        });
        const globalBaseAboveY = (globalMinBusY === Infinity ? 0 : globalMinBusY) - CABLE_DROP;

        const isSubCable = (c) => {
            const fe = nodeToVertex.get(c.from), te = nodeToVertex.get(c.to);
            return fe?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION || te?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
        };
        const substationCables = cables.filter(c => isSubCable(c));
        const nonSubstationCables = cables.filter(c => !isSubCable(c));

        const isOffshore66kVCable = (c) => {
            const fe = nodeToVertex.get(c.from), te = nodeToVertex.get(c.to);
            const fromT = fe?.node?.type === NODE_TYPES.OFFSHORE_WIND_TURBINE;
            const toT = te?.node?.type === NODE_TYPES.OFFSHORE_WIND_TURBINE;
            const fromS = fe?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
            const toS = te?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
            return (fromT && toT) || (fromT && toS) || (fromS && toT);
        };
        const turbineCountMap = computeTurbineCountPerCable(nodes, cables);

        substationCables.sort((a, b) => {
            const getTurbineY = (c) => {
                const fe = nodeToVertex.get(c.from), te = nodeToVertex.get(c.to);
                const turbineEntry = fe?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION ? te : fe;
                if (!turbineEntry) return 0;
                const bus = turbineEntry.bus;
                return graph.getCellGeometry(bus)?.y || 0;
            };
            return getTurbineY(a) - getTurbineY(b);
        });
        const sortedCables = [...nonSubstationCables, ...substationCables];

        sortedCables.forEach((cable, cableIndex) => {
            const fromEntry = nodeToVertex.get(cable.from);
            const toEntry = nodeToVertex.get(cable.to);
            if (!fromEntry || !toEntry) return;

            const fromBus = getBusForCable(fromEntry, toEntry);
            const toBus = getBusForCable(toEntry, fromEntry);

            const fromGeo = graph.getCellGeometry(fromBus);
            const toGeo = graph.getCellGeometry(toBus);
            const fromCenterX = fromGeo.x + fromGeo.width / 2;
            const toCenterX = toGeo.x + toGeo.width / 2;
            const sameColumn = Math.abs(fromCenterX - toCenterX) < 50;
            const sameRow = Math.abs(fromGeo.y - toGeo.y) < 50;
            const fromIsSubstation = fromEntry?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
            const toIsSubstation = toEntry?.node?.type === NODE_TYPES.OFFSHORE_SUBSTATION;
            const hasSubstation = fromIsSubstation || toIsSubstation;
            let points;
            let lineStyle;
            if (sameColumn) {
                const midY = (fromGeo.y + toGeo.y) / 2;
                points = [new mxPoint(fromCenterX, midY)];
                const sourceAbove = fromGeo.y < toGeo.y;
                const exitY = sourceAbove ? '1' : '0';
                const entryY = sourceAbove ? '0' : '1';
                lineStyle = LINE_STYLE_BASE + `;exitX=0.5;exitY=${exitY};entryX=0.5;entryY=${entryY};exitDx=0;exitDy=0;entryDx=0;entryDy=0;exitPerimeter=0;entryPerimeter=0`;
            } else if (sameRow && !hasSubstation) {
                const midX = (fromCenterX + toCenterX) / 2;
                points = [new mxPoint(midX, fromGeo.y)];
                const sourceLeft = fromGeo.x < toGeo.x;
                const exitX = sourceLeft ? '1' : '0';
                const entryX = sourceLeft ? '0' : '1';
                lineStyle = LINE_STYLE_BASE + `;exitX=${exitX};exitY=0.5;entryX=${entryX};entryY=0.5;exitDx=0;exitDy=0;entryDx=0;entryDy=0;exitPerimeter=0;entryPerimeter=0`;
            } else if (hasSubstation) {
                const turbineGeo = fromIsSubstation ? toGeo : fromGeo;
                const subGeo = fromIsSubstation ? fromGeo : toGeo;
                const turnX = subGeo.x - 20 - cableIndex * CABLE_LANE_SPACING;
                const turbineY = turbineGeo.y + turbineGeo.height / 2;
                const subY = subGeo.y + subGeo.height / 2;
                points = [
                    new mxPoint(turnX, turbineY),
                    new mxPoint(turnX, subY)
                ];
                lineStyle = LINE_STYLE_BASE + `;exitX=1;exitY=0.5;exitDx=0;exitDy=0;exitPerimeter=0;entryX=0;entryY=0.5;entryDx=0;entryDy=0;entryPerimeter=0`;
            } else {
                const sourceLeftOfTarget = fromGeo.x < toGeo.x;
                const exitX = sourceLeftOfTarget ? '1' : '0';
                const entryX = sourceLeftOfTarget ? '0' : '1';
                const fromAbsX = sourceLeftOfTarget ? fromGeo.x + fromGeo.width : fromGeo.x;
                const toAbsX = sourceLeftOfTarget ? toGeo.x : toGeo.x + toGeo.width;
                const aboveY = globalBaseAboveY - cableIndex * CABLE_LANE_SPACING;
                points = [new mxPoint(fromAbsX, aboveY), new mxPoint(toAbsX, aboveY)];
                lineStyle = LINE_STYLE_BASE + `;exitX=${exitX};exitY=0.5;exitDx=0;exitDy=0;exitPerimeter=0;entryX=${entryX};entryY=0.5;entryDx=0;entryDy=0;entryPerimeter=0`;
            }

            const edge = graph.insertEdge(parent, null, cable.id || cable.name, fromBus, toBus, lineStyle);

            let edgeGeo = graph.getCellGeometry(edge);
            if (edgeGeo && points.length > 0) {
                edgeGeo = edgeGeo.clone();
                edgeGeo.points = points;
                graph.getModel().setGeometry(edge, edgeGeo);
            }
            const busLabel = (entry, bus) => {
                if (!entry) return '';
                if (entry.bus275 && bus === entry.bus275) return (entry.node.name || entry.node.id) + '_275';
                if (entry.bus66 && bus === entry.bus66) return (entry.node.name || entry.node.id) + '_66';
                return (entry.node.name || entry.node.id);
            };
            const fromBusName = busLabel(fromEntry, fromBus);
            const toBusName = busLabel(toEntry, toBus);

            let lineAttrs = {
                name: cable.id || cable.name,
                from_bus: fromBusName,
                to_bus: toBusName,
                length_km: String(cable.length_km || 1),
                r_ohm_per_km: String(cable.r_ohm_per_km || 0.122),
                x_ohm_per_km: String(cable.x_ohm_per_km || 0.112)
            };
            if (isOffshore66kVCable(cable) && OFFSHORE_66KV_AL_CABLES.length > 0) {
                const turbineCount = turbineCountMap.get(`${cable.from}-${cable.to}`) ?? turbineCountMap.get(`${cable.to}-${cable.from}`) ?? 1;
                const selected = selectOffshore66kVAlCable(turbineCount);
                lineAttrs = {
                    ...lineAttrs,
                    name: (cable.id || cable.name) + ' (' + selected.name + ')',
                    r_ohm_per_km: String(selected.r_ohm_per_km ?? 0.122),
                    x_ohm_per_km: String(selected.x_ohm_per_km ?? 0.112),
                    max_i_ka: String(selected.max_i_ka ?? 0),
                    type: selected.type ?? 'cs'
                };
            }
            configureLineAttributes(graph, edge, lineAttrs);
        });

        // 4. Add result placeholders to all generated buses (resultBoxes.js)
        if (typeof window.createBusResultPlaceholder === 'function') {
            busesForResultBoxes.forEach((busCell) => {
                try {
                    window.createBusResultPlaceholder(graph, busCell);
                } catch (e) {
                    console.warn('mapToElectricalModel: createBusResultPlaceholder failed for bus', e);
                }
            });
        }

        return { nodeToVertex, nodeCount: nodes.length, cableCount: cables.length };
    } finally {
        graph.getModel().endUpdate();
    }
}
