// DiagnosticReportDialog.js - Dialog for displaying diagnostic reports
(function() {
    class DiagnosticReportDialog {
        constructor(diagnosticData, errorInfo = null) {
            this.diagnosticData = diagnosticData;
            this.errorInfo = errorInfo; // { message, exception }
            // Set title based on whether this is a short-circuit or power-flow diagnostic
            this.title = this.detectShortCircuitDiagnostic(diagnosticData, errorInfo)
                ? 'Short Circuit Diagnostic Report'
                : 'Power Flow Diagnostic Report';
        }

        detectShortCircuitDiagnostic(data, errorInfo) {
            // Heuristic: if data is a string and contains 'PANDAPOWER DIAGNOSTIC TOOL', treat as short circuit diagnostic
            if (typeof data === 'string' && data.includes('PANDAPOWER DIAGNOSTIC TOOL')) {
                return true;
            }
            // If error message mentions short circuit, treat as short-circuit diagnostic
            if (errorInfo && errorInfo.message && String(errorInfo.message).toLowerCase().includes('short circuit')) {
                return true;
            }
            if (errorInfo && errorInfo.exception && String(errorInfo.exception).toLowerCase().includes('short circuit')) {
                return true;
            }
            return false;
        }

        getGraph() {
            const app = (window.App && (window.App.main || window.App._instance)) || null;
            return app && app.editor && app.editor.graph ? app.editor.graph : null;
        }

        /**
         * Normalize backend element entries: number | string | {index,id,name}
         */
        normalizeElementRef(item) {
            if (item == null) return null;
            if (typeof item === 'object') {
                const id = item.id != null ? String(item.id) : '';
                const name = item.name != null ? String(item.name) : '';
                const index = item.index != null ? item.index : null;
                const label = name || id || (index != null ? String(index) : '');
                if (!label) return null;
                return { id: id || label, name: name || label, index, label };
            }
            const label = String(item);
            return { id: label, name: label, index: null, label };
        }

        formatElementLabel(item) {
            const ref = this.normalizeElementRef(item);
            return ref ? ref.label : String(item);
        }

        collectHighlightIdentifiers(diagnosticData) {
            if (typeof window.collectDiagnosticHighlightIds === 'function') {
                return window.collectDiagnosticHighlightIds(diagnosticData);
            }
            const ids = [];
            const data = diagnosticData || {};
            const pushList = (list) => {
                if (!Array.isArray(list)) return;
                list.forEach((item) => {
                    const ref = this.normalizeElementRef(item);
                    if (!ref) return;
                    // Skip bare integers — they collide with mxGraph cell ids
                    if (ref.id && !/^\d+$/.test(ref.id)) ids.push(ref.id);
                    if (ref.name && ref.name !== ref.id && !/^\d+$/.test(ref.name)) ids.push(ref.name);
                });
            };

            if (data.disconnected_elements && typeof data.disconnected_elements === 'object') {
                Object.keys(data.disconnected_elements).forEach((key) => {
                    pushList(data.disconnected_elements[key]);
                });
            }
            pushList(data.isolated_buses);
            return ids;
        }

        highlightOnCanvas(identifiers) {
            const graph = this.getGraph();
            if (!graph || !identifiers || !identifiers.length) return [];
            if (typeof window.highlightGraphElementsByIdentifiers === 'function') {
                return window.highlightGraphElementsByIdentifiers(graph, identifiers);
            }
            if (typeof window.highlightCalculationErrorElements === 'function') {
                // Fallback: wrap ids as quoted names so the text extractor can find them
                return window.highlightCalculationErrorElements(
                    graph,
                    identifiers.map((id) => `Bus '${id}'`).join(' ')
                );
            }
            return [];
        }

        focusElementOnCanvas(item) {
            const ref = this.normalizeElementRef(item);
            if (!ref) return;
            this.highlightOnCanvas([ref.id, ref.name].filter(Boolean));
        }

        removeRestoreButton() {
            if (this._restoreBtn && this._restoreBtn.parentNode) {
                this._restoreBtn.parentNode.removeChild(this._restoreBtn);
            }
            this._restoreBtn = null;
        }

        dismissFully() {
            this.removeRestoreButton();
            if (this._overlay && this._overlay.parentNode) {
                this._overlay.parentNode.removeChild(this._overlay);
            }
            if (this._escapeHandler) {
                document.removeEventListener('keydown', this._escapeHandler);
                this._escapeHandler = null;
            }
            this._overlay = null;
            this._parked = false;
        }

        restoreDialog() {
            if (!this._overlay) return;
            this.removeRestoreButton();
            this._overlay.style.display = 'flex';
            this._parked = false;
        }

        parkDialogForCanvas(focusedLabel) {
            if (!this._overlay) return;
            this._overlay.style.display = 'none';
            this._parked = true;
            this.removeRestoreButton();

            const btn = document.createElement('button');
            btn.type = 'button';
            const label = focusedLabel ? String(focusedLabel) : '';
            btn.textContent = label
                ? `Back to diagnostic report (${label})`
                : 'Back to diagnostic report';
            btn.title = 'Return to the Power Flow Diagnostic Report';
            btn.style.cssText = `
                position: fixed; right: 20px; bottom: 20px; z-index: 10001;
                padding: 10px 16px; background: #d32f2f; color: #fff; border: none;
                border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600;
                box-shadow: 0 4px 14px rgba(0,0,0,0.35); font-family: Arial, sans-serif;
            `;
            btn.onmouseenter = () => { btn.style.background = '#b71c1c'; };
            btn.onmouseleave = () => { btn.style.background = '#d32f2f'; };
            btn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.restoreDialog();
            };
            document.body.appendChild(btn);
            this._restoreBtn = btn;
        }

        showElementAndHideDialog(item) {
            const ref = this.normalizeElementRef(item);
            this.focusElementOnCanvas(item);
            this.parkDialogForCanvas(ref ? ref.label : '');
        }

        createClickableElementChip(item) {
            const ref = this.normalizeElementRef(item);
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.textContent = ref ? ref.label : String(item);
            chip.title = ref && ref.id && ref.id !== ref.label
                ? `Show on diagram and hide report (${ref.id})`
                : 'Show on diagram and hide report';
            chip.style.cssText = `
                display: inline-block; margin: 2px 4px 2px 0; padding: 2px 8px;
                border: 1px solid #c62828; border-radius: 12px; background: #fff;
                color: #b71c1c; font-size: 12px; cursor: pointer; line-height: 1.4;
            `;
            chip.onmouseenter = () => { chip.style.background = '#ffebee'; };
            chip.onmouseleave = () => { chip.style.background = '#fff'; };
            chip.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.showElementAndHideDialog(item);
            };
            return chip;
        }

        show() {
            // Overlay
            const overlay = document.createElement('div');
            this._overlay = overlay;
            this._parked = false;
            overlay.style.cssText = `
                position: fixed; top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.5); z-index: 10000;
                display: flex; align-items: center; justify-content: center;
            `;

            // Dialog
            const dialog = document.createElement('div');
            dialog.style.cssText = `
                background: white; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                max-width: 800px; max-height: 90vh; overflow-y: auto; padding: 24px; margin: 20px;
                font-family: Arial, sans-serif;
            `;

            // Title
            const title = document.createElement('h2');
            title.textContent = this.title;
            title.style.cssText = 'margin: 0 0 20px 0; color: #d32f2f; font-size: 20px;';
            dialog.appendChild(title);

            // Error summary
            const errorSummary = document.createElement('div');
            errorSummary.style.cssText = `
                background: #ffebee; border: 1px solid #ffcdd2; border-radius: 4px;
                padding: 16px; margin-bottom: 20px;
            `;
            
            let errorHtml = `
                <h3 style="margin: 0 0 8px 0; color: #d32f2f;">⚠️ ${this.title.replace(' Report','')} Failed</h3>
            `;
            
            // Add the specific error message if available
            if (this.errorInfo && this.errorInfo.message) {
                errorHtml += `
                    <p style="margin: 8px 0; padding: 12px; background: #fff; border-left: 4px solid #d32f2f; color: #000; font-weight: bold;">
                        ${this.errorInfo.message}
                    </p>
                `;
            }
            
            // Add the exception details if available and different from message
            if (this.errorInfo && this.errorInfo.exception && this.errorInfo.exception !== this.errorInfo.message) {
                errorHtml += `
                    <p style="margin: 8px 0 0 0; padding: 8px; background: #fff; border-left: 4px solid #ff9800; color: #333; font-size: 13px;">
                        <strong>Details:</strong> ${this.errorInfo.exception}
                    </p>
                `;
            }
            
            if (!this.errorInfo || !this.errorInfo.message) {
                errorHtml += `
                    <p style="margin: 0; color: #c62828;">The calculation could not complete. Please review the diagnostic information below and fix the issues in your network.</p>
                `;
            }
            
            // Add guidance from backend analysis (invalid_parameters) or generic tip for Ybus/NaN
            const msg = (this.errorInfo && this.errorInfo.message) ? String(this.errorInfo.message) : '';
            const exc = (this.errorInfo && this.errorInfo.exception) ? String(this.errorInfo.exception) : '';
            const combined = (msg + ' ' + exc).toLowerCase();
            const invalidParams = this.diagnosticData && Array.isArray(this.diagnosticData.invalid_parameters) ? this.diagnosticData.invalid_parameters : [];
            if (invalidParams.length > 0) {
                errorHtml += `
                    <div style="margin-top: 12px; padding: 12px; background: #e3f2fd; border-left: 4px solid #1976d2; color: #0d47a1;">
                        <strong>What to change:</strong> The following parameters need to be corrected:
                        <ul style="margin: 8px 0 0 0; padding-left: 20px;">
                            ${invalidParams.map(r => `<li><strong>${r.element_type}</strong> "${r.name}": parameter <strong>${r.param}</strong> — ${r.message}</li>`).join('')}
                        </ul>
                    </div>
                `;
            } else if (combined.includes('nan') && (combined.includes('ybus') || combined.includes('calculation parameters'))) {
                errorHtml += `
                    <div style="margin-top: 12px; padding: 12px; background: #e3f2fd; border-left: 4px solid #1976d2; color: #0d47a1;">
                        <strong>What to do:</strong> Invalid short-circuit parameters may cause this error. Check External Grid (s_sc_max_mva) and Static Generators (sn_mva or generator_type). Right-click each element → Edit data.
                    </div>
                `;
            }
            
            errorSummary.innerHTML = errorHtml;
            dialog.appendChild(errorSummary);

            // Content container
            const content = document.createElement('div');
            content.style.cssText = 'display: flex; flex-direction: column; gap: 16px;';

            // Process diagnostic data
            this.processDiagnosticData(content);

            // Highlight disconnected / isolated elements on the canvas
            const highlightIds = this.collectHighlightIdentifiers(
                typeof this.diagnosticData === 'object' ? this.diagnosticData : null
            );
            const highlighted = this.highlightOnCanvas(highlightIds);
            if (highlighted && highlighted.length > 0) {
                const tip = document.createElement('div');
                tip.style.cssText = 'margin-top: 4px; padding: 10px 12px; background: #fff8e1; border: 1px solid #ffe082; border-radius: 4px; color: #e65100; font-size: 13px;';
                tip.textContent = highlighted.length > 1
                    ? `${highlighted.length} elements are highlighted in red on the diagram. Click a name below to hide this report and focus it — use “Back to diagnostic report” to return.`
                    : 'The element is highlighted in red on the diagram. Click its name below to hide this report and focus it.';
                content.insertBefore(tip, content.firstChild);
            }

            dialog.appendChild(content);

            // Close button
            const buttonContainer = document.createElement('div');
            buttonContainer.style.cssText = 'display: flex; justify-content: flex-end; margin-top: 24px;';

            const closeButton = document.createElement('button');
            closeButton.textContent = 'Close';
            closeButton.style.cssText = `
                padding: 8px 16px; background: #d32f2f; color: white; 
                border: none; border-radius: 4px; cursor: pointer; font-size: 14px;
            `;
            closeButton.onclick = () => this.dismissFully();
            buttonContainer.appendChild(closeButton);

            dialog.appendChild(buttonContainer);
            overlay.appendChild(dialog);
            document.body.appendChild(overlay);

            import('../utils/dialogStyles.js').then(({ attachBackdropCloseHandler }) => {
                attachBackdropCloseHandler(overlay, dialog, () => this.dismissFully());
            });

            // Escape: restore parked dialog first, otherwise close fully
            const handleEscape = (e) => {
                if (e.key !== 'Escape') return;
                if (this._parked) {
                    this.restoreDialog();
                    return;
                }
                this.dismissFully();
            };
            this._escapeHandler = handleEscape;
            document.addEventListener('keydown', handleEscape);
        }

        processDiagnosticData(content) {
            const data = this.diagnosticData;
            console.log('DiagnosticReportDialog.processDiagnosticData - data type:', typeof data);
            console.log('DiagnosticReportDialog.processDiagnosticData - data:', data);
            console.log('DiagnosticReportDialog.processDiagnosticData - has diagnostic_output:', data && data.diagnostic_output ? 'YES (' + data.diagnostic_output.length + ' chars)' : 'NO');
            
            // If it's a string and looks like a Pandapower diagnostic, render as preformatted
            if (typeof data === 'string' && data.includes('PANDAPOWER DIAGNOSTIC TOOL')) {
                console.log('DiagnosticReportDialog: Rendering as string diagnostic');
                this.createPandapowerDiagnosticSection(content, data);
            } else if (Array.isArray(data)) {
                console.log('DiagnosticReportDialog: Rendering as array');
                this.createErrorSection(content, 'Error Messages', data);
            } else if (typeof data === 'object') {
                console.log('DiagnosticReportDialog: Rendering as object (calling createDetailedDiagnostic)');
                this.createDetailedDiagnostic(content, data);
            } else {
                console.log('DiagnosticReportDialog: Rendering as generic error');
                this.createErrorSection(content, 'Error', [String(data)]);
            }
        }

        createPandapowerDiagnosticSection(content, diagnosticText) {
            console.log('DiagnosticReportDialog.createPandapowerDiagnosticSection - creating section with', diagnosticText.length, 'characters');
            
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #1976d2; border-radius: 4px; padding: 0; background: #f5f5f5; margin-bottom: 16px;';

            // Add a header
            const header = document.createElement('div');
            header.style.cssText = 'background: #1976d2; color: white; padding: 10px 16px; font-weight: bold; border-radius: 4px 4px 0 0;';
            header.textContent = '🔍 Pandapower Diagnostic Output';
            section.appendChild(header);

            const pre = document.createElement('pre');
            pre.style.cssText = 'margin: 0; padding: 16px; font-family: monospace; font-size: 13px; max-height: 400px; overflow-x: auto; overflow-y: auto; background: #f5f5f5; border-radius: 0 0 4px 4px;';

            // Optionally, highlight summary and error lines
            const lines = diagnosticText.split('\n');
            pre.innerHTML = lines.map(line => {
                if (/SUMMARY:/i.test(line)) {
                    return `<span style="color:#d32f2f;font-weight:bold;">${line}</span>`;
                } else if (/invalid value/i.test(line)) {
                    return `<span style="color:#c62828;">${line}</span>`;
                } else if (/failed/i.test(line)) {
                    return `<span style="color:#e65100;">${line}</span>`;
                } else {
                    return line;
                }
            }).join('\n');

            section.appendChild(pre);
            content.appendChild(section);
        }

        createErrorSection(content, title, errors) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #ddd; border-radius: 4px; padding: 16px;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = title;
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #333; font-size: 16px;';
            section.appendChild(sectionTitle);

            const errorList = document.createElement('ul');
            errorList.style.cssText = 'margin: 0; padding-left: 20px; color: #d32f2f;';

            errors.forEach(error => {
                const listItem = document.createElement('li');
                listItem.textContent = String(error);
                listItem.style.cssText = 'margin-bottom: 4px;';
                errorList.appendChild(listItem);
            });

            section.appendChild(errorList);
            content.appendChild(section);
        }

        appendSolverVerboseLog(content, text) {
            const raw = text != null ? String(text).trim() : '';
            if (!raw) return;

            const section = document.createElement('div');
            section.style.cssText =
                'border: 1px solid #455a64; border-radius: 4px; margin-bottom: 16px; overflow: hidden;';

            const header = document.createElement('div');
            header.style.cssText =
                'background: #455a64; color: white; padding: 10px 16px; font-weight: bold; font-size: 14px;';
            header.textContent = 'PyPower / OPF verbose output';
            section.appendChild(header);

            const sub = document.createElement('div');
            sub.style.cssText = 'padding: 8px 12px; font-size: 12px; color: #546e7a; background: #eceff1;';
            sub.textContent =
                'Captured because "Suppress warnings" was disabled in the OPF dialog. PyPower notes that some summaries refer to internal matrices, not pandapower DataFrames.';
            section.appendChild(sub);

            const pre = document.createElement('pre');
            pre.style.cssText =
                'margin: 0; padding: 12px 16px; font-family: ui-monospace, Consolas, monospace; font-size: 11px; line-height: 1.35; max-height: 420px; overflow: auto; white-space: pre; background: #fafafa;';
            pre.textContent = raw;
            section.appendChild(pre);

            content.appendChild(section);
        }

        createDetailedDiagnostic(content, diagnosticData) {
            console.log('DiagnosticReportDialog: Processing diagnostic data:', diagnosticData);

            if (diagnosticData.solver_verbose_log && String(diagnosticData.solver_verbose_log).trim()) {
                this.appendSolverVerboseLog(content, diagnosticData.solver_verbose_log);
            }
            
            // Handle pandapower diagnostic text output (from stdout capture)
            if (diagnosticData.diagnostic_output) {
                console.log('DiagnosticReportDialog: Found diagnostic_output, length:', diagnosticData.diagnostic_output.length);
                this.createPandapowerDiagnosticSection(content, diagnosticData.diagnostic_output);
            } else if (diagnosticData.diagnostic_note) {
                // Show note if diagnostic output wasn't captured
                const noteSection = document.createElement('div');
                noteSection.style.cssText = 'border: 1px solid #2196f3; border-radius: 4px; padding: 16px; background: #e3f2fd; margin-bottom: 16px;';
                noteSection.innerHTML = `<p style="margin: 0; color: #1565c0;">ℹ️ ${diagnosticData.diagnostic_note}</p>`;
                content.appendChild(noteSection);
            }
            
            // Handle diagnostic errors
            if (diagnosticData.diagnostic_error) {
                const errorSection = document.createElement('div');
                errorSection.style.cssText = 'border: 1px solid #ff9800; border-radius: 4px; padding: 16px; background: #fff3e0; margin-bottom: 16px;';
                errorSection.innerHTML = `<p style="margin: 0; color: #e65100;">⚠️ Diagnostic Error: ${diagnosticData.diagnostic_error}</p>`;
                content.appendChild(errorSection);
            }
            
            // Handle disconnected elements
            if (diagnosticData.disconnected_elements) {
                this.createDisconnectedElementsSection(content, diagnosticData.disconnected_elements);
            }
            
            // Handle overload issues
            if (diagnosticData.overload) {
                this.createOverloadSection(content, diagnosticData.overload);
            }

            // Handle invalid values
            if (diagnosticData.invalid_values) {
                this.createInvalidValuesSection(content, diagnosticData.invalid_values);
            }

            // Handle nominal voltage mismatches
            if (diagnosticData.nominal_voltages_dont_match) {
                this.createVoltageMismatchSection(content, diagnosticData.nominal_voltages_dont_match);
            }

            // Handle isolated buses
            if (diagnosticData.isolated_buses) {
                this.createIsolatedBusesSection(content, diagnosticData.isolated_buses);
            }

            // Handle convergence issues
            if (diagnosticData.convergence) {
                this.createConvergenceSection(content, diagnosticData.convergence);
            }
            
            // Handle general errors
            if (diagnosticData.general_error) {
                this.createErrorSection(content, 'Error Details', [diagnosticData.general_error]);
            }
        }
        
        createDisconnectedElementsSection(content, disconnectedData) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #ff5722; border-radius: 4px; padding: 16px; background: #fbe9e7;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '🔌 Disconnected Elements';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #d84315; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'The following elements are not connected to the external grid (click a name to hide this report and locate it on the diagram):';
            description.style.cssText = 'margin: 0 0 12px 0; color: #bf360c;';
            section.appendChild(description);

            const typeLabels = {
                buses: 'Buses',
                lines: 'Lines',
                loads: 'Loads',
                generators: 'Generators',
                trafos: 'Transformers',
                sgens: 'Static Generators'
            };
            const elementTypes = ['buses', 'lines', 'loads', 'generators', 'trafos', 'sgens'];
            elementTypes.forEach(elementType => {
                if (disconnectedData[elementType] && disconnectedData[elementType].length > 0) {
                    const elementSection = document.createElement('div');
                    elementSection.style.cssText = 'margin-bottom: 10px;';

                    const elementTitle = document.createElement('div');
                    elementTitle.textContent = `${typeLabels[elementType] || elementType}:`;
                    elementTitle.style.cssText = 'font-weight: bold; color: #d84315; margin-bottom: 4px;';
                    elementSection.appendChild(elementTitle);

                    const chips = document.createElement('div');
                    disconnectedData[elementType].forEach((item) => {
                        chips.appendChild(this.createClickableElementChip(item));
                    });
                    elementSection.appendChild(chips);

                    section.appendChild(elementSection);
                }
            });

            content.appendChild(section);
        }

        createOverloadSection(content, overloadData) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #ff9800; border-radius: 4px; padding: 16px; background: #fff3e0;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '🚨 Overload Issues';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #e65100; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'The following elements are overloaded and may cause power flow convergence issues:';
            description.style.cssText = 'margin: 0 0 12px 0; color: #bf360c;';
            section.appendChild(description);

            Object.keys(overloadData).forEach(elementType => {
                const elementSection = document.createElement('div');
                elementSection.style.cssText = 'margin-bottom: 12px;';

                const elementTitle = document.createElement('h4');
                elementTitle.textContent = `${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Elements`;
                elementTitle.style.cssText = 'margin: 0 0 8px 0; color: #e65100; font-size: 14px;';
                elementSection.appendChild(elementTitle);

                const elementList = document.createElement('ul');
                elementList.style.cssText = 'margin: 0; padding-left: 20px; color: #bf360c;';

                if (Array.isArray(overloadData[elementType])) {
                    overloadData[elementType].forEach(item => {
                        const listItem = document.createElement('li');
                        listItem.textContent = String(item);
                        elementList.appendChild(listItem);
                    });
                } else {
                    const listItem = document.createElement('li');
                    listItem.textContent = String(overloadData[elementType]);
                    elementList.appendChild(listItem);
                }

                elementSection.appendChild(elementList);
                section.appendChild(elementSection);
            });

            content.appendChild(section);
        }

        createInvalidValuesSection(content, invalidData) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #f44336; border-radius: 4px; padding: 16px; background: #ffebee;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '❌ Invalid Values';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #d32f2f; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'The following elements have invalid parameter values:';
            description.style.cssText = 'margin: 0 0 12px 0; color: #c62828;';
            section.appendChild(description);

            Object.keys(invalidData).forEach(elementType => {
                const elementSection = document.createElement('div');
                elementSection.style.cssText = 'margin-bottom: 12px;';

                const elementTitle = document.createElement('h4');
                elementTitle.textContent = `${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Elements`;
                elementTitle.style.cssText = 'margin: 0 0 8px 0; color: #d32f2f; font-size: 14px;';
                elementSection.appendChild(elementTitle);

                const elementList = document.createElement('ul');
                elementList.style.cssText = 'margin: 0; padding-left: 20px; color: #c62828;';

                if (Array.isArray(invalidData[elementType])) {
                    invalidData[elementType].forEach(item => {
                        const listItem = document.createElement('li');
                        listItem.textContent = String(item);
                        elementList.appendChild(listItem);
                    });
                } else {
                    const listItem = document.createElement('li');
                    listItem.textContent = String(invalidData[elementType]);
                    elementList.appendChild(listItem);
                }

                elementSection.appendChild(elementList);
                section.appendChild(elementSection);
            });

            content.appendChild(section);
        }

        createVoltageMismatchSection(content, voltageData) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #ff9800; border-radius: 4px; padding: 16px; background: #fff3e0;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '⚡ Voltage Mismatch Issues';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #e65100; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'Nominal voltages do not match between connected elements:';
            description.style.cssText = 'margin: 0 0 12px 0; color: #bf360c;';
            section.appendChild(description);

            Object.keys(voltageData).forEach(elementType => {
                const elementSection = document.createElement('div');
                elementSection.style.cssText = 'margin-bottom: 12px;';

                const elementTitle = document.createElement('h4');
                elementTitle.textContent = `${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Elements`;
                elementTitle.style.cssText = 'margin: 0 0 8px 0; color: #e65100; font-size: 14px;';
                elementSection.appendChild(elementTitle);

                const elementList = document.createElement('ul');
                elementList.style.cssText = 'margin: 0; padding-left: 20px; color: #bf360c;';

                if (Array.isArray(voltageData[elementType])) {
                    voltageData[elementType].forEach(item => {
                        const listItem = document.createElement('li');
                        listItem.textContent = String(item);
                        elementList.appendChild(listItem);
                    });
                } else {
                    const listItem = document.createElement('li');
                    listItem.textContent = String(voltageData[elementType]);
                    elementList.appendChild(listItem);
                }

                elementSection.appendChild(elementList);
                section.appendChild(elementSection);
            });

            content.appendChild(section);
        }

        createIsolatedBusesSection(content, isolatedBuses) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #f44336; border-radius: 4px; padding: 16px; background: #ffebee;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '🔌 Isolated Buses';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #d32f2f; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'The following buses are not connected to any power source (click a name to hide this report and locate it on the diagram):';
            description.style.cssText = 'margin: 0 0 12px 0; color: #c62828;';
            section.appendChild(description);

            const chips = document.createElement('div');
            (isolatedBuses || []).forEach((bus) => {
                chips.appendChild(this.createClickableElementChip(bus));
            });

            section.appendChild(chips);
            content.appendChild(section);
        }

        createConvergenceSection(content, convergenceData) {
            const section = document.createElement('div');
            section.style.cssText = 'border: 1px solid #ff9800; border-radius: 4px; padding: 16px; background: #fff3e0;';

            const sectionTitle = document.createElement('h3');
            sectionTitle.textContent = '🔄 Convergence Issues';
            sectionTitle.style.cssText = 'margin: 0 0 12px 0; color: #e65100; font-size: 16px;';
            section.appendChild(sectionTitle);

            const description = document.createElement('p');
            description.textContent = 'The power flow calculation failed to converge. This may be due to:';
            description.style.cssText = 'margin: 0 0 12px 0; color: #bf360c;';
            section.appendChild(description);

            const reasons = document.createElement('ul');
            reasons.style.cssText = 'margin: 0 0 12px 0; padding-left: 20px; color: #bf360c;';
            reasons.innerHTML = `
                <li>Insufficient generation capacity</li>
                <li>Network topology issues</li>
                <li>Invalid parameter values</li>
                <li>Overloaded elements</li>
                <li>Voltage violations</li>
            `;
            section.appendChild(reasons);

            if (convergenceData) {
                const details = document.createElement('div');
                details.style.cssText = 'font-family: monospace; font-size: 12px; background: white; padding: 8px; border-radius: 2px;';
                details.textContent = JSON.stringify(convergenceData, null, 2);
                section.appendChild(details);
            }

            content.appendChild(section);
        }
    }

    // Make available globally
    if (typeof globalThis !== 'undefined') {
        globalThis.DiagnosticReportDialog = DiagnosticReportDialog;
    } else if (typeof window !== 'undefined') {
        window.DiagnosticReportDialog = DiagnosticReportDialog;
    }
})(); 