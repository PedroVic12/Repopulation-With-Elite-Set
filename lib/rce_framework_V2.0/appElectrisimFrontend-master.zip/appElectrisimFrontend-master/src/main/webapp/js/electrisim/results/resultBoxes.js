//-----CREATION OF RESULT PLACEHOLDERS for ALL ELEMENTS, INCLUDING BUS AND LINE-----


//Hook into edge insertion to create placeholder result boxes for components
//connected to buses (External Grid, Generator, Load, Motor, SSC, etc.)

// Deferred: preserve original and apply override when mxGraph is available
var originalGraphAddEdge = null;
var upgradedGraphs = typeof WeakSet !== 'undefined' ? new WeakSet() : {};

function runUpgradeOnce(graph) {
    if (!graph || !upgradeResultPlaceholderStyles) return;
    if (upgradedGraphs instanceof WeakSet) {
        if (upgradedGraphs.has(graph)) return;
        upgradedGraphs.add(graph);
    } else if (upgradedGraphs[graph.id]) return;
    else if (graph.id) upgradedGraphs[graph.id] = true;
    upgradeResultPlaceholderStyles(graph);
}

// Helper to extract custom Electrisim shape
function getShapeElxxx(style) {
    if (!style) return null;
    var match = style.match(/shapeELXXX=([^;]+)/);
    return match ? match[1] : null;
}

// Helper to detect Bus style (including DC Bus)
function isBusStyle(style) {
    if (!style) return false;
    return style.includes('shapeELXXX=Bus') ||
        style.includes('shapeELXXX=DC Bus') ||
        style.includes('shape=mxgraph.electrical.transmission.busbar');
}

// Create a result placeholder for Bus element when it is dropped onto the graph
// This placeholder will be updated with load flow results (vm_pu, va_degree, p_mw, q_mvar, etc.)
function createBusResultPlaceholder(graph, busCell) {
    if (!graph || !busCell) {
        console.warn('ELXXX: Cannot create Bus result placeholder - missing graph or busCell');
        return;
    }
    if (graph._elxxxSkipPlaceholders) return;
    runUpgradeOnce(graph);
    // Check if placeholder already exists
    var existingId = null;
    if (busCell.value && busCell.value.attributes) {
        var placeholderAttr = busCell.value.attributes.getNamedItem('placeholderId');
        if (placeholderAttr) {
            existingId = placeholderAttr.nodeValue;
        }
    }
    
    if (existingId) {
        console.log('ELXXX: Bus already has a result placeholder:', existingId);
        return;
    }

    var baseStyle = [
        'shape=rounded',
        'rounded=1',
        'arcSize=6',
        'fillColor=#F8F9FA',
        'strokeColor=#6C757D',
        'strokeWidth=1.5',
        'dashed=1',
        'dashPattern=5 5',
        'opacity=70',
        'whiteSpace=wrap',
        'html=1',
        'align=center',
        'verticalAlign=middle',
        'fontSize=7',
        'fontColor=#6C757D',
        'fontStyle=0',
        'spacing=3',
        'connectedTo=' + busCell.id
    ].join(';');

    var placeholderStyle = 'shapeELXXX=ResultBus;' + baseStyle;

    var boxWidth = 80;
    var boxHeight = 70;

    graph.model.beginUpdate();
    try {
        // Create placeholder as a child of the Bus cell with relative positioning
        // Positioned at left edge (x=0) to align with the "Bus" label
        var placeholder = graph.insertVertex(
            busCell,           // parent is the Bus cell
            null,              // id (auto-generated)
            'Click Simulate to generate results',
            0,                 // x position (relative, left-aligned with Bus label)
            1.0,               // y position (relative, below the bus - closer than before)
            boxWidth,
            boxHeight,
            placeholderStyle,
            true               // relative positioning
        );

        if (placeholder) {
            var geo = graph.model.getGeometry(placeholder);
            if (geo) {
                geo.relative = true;
                geo.x = 0;     // Left-aligned with Bus label
                geo.y = 1.0;   // Closer to the Bus line
                if (typeof mxPoint !== 'undefined') {
                    geo.offset = new mxPoint(0, 0);  // No horizontal offset, left-aligned
                }
                graph.model.setGeometry(placeholder, geo);
            }

            // Get the placeholder ID
            var placeholderId = placeholder.id;
            if (!placeholderId && placeholder.mxObjectId) {
                placeholderId = placeholder.mxObjectId.replace('#', '');
            }

            if (placeholderId) {
                // Add placeholderId to the style for traceability
                graph.model.setStyle(
                    placeholder,
                    placeholderStyle + ';placeholderId=' + placeholderId
                );

                // Store reference on the Bus cell so loadFlow.js can find it
                if (busCell.value && typeof busCell.value.setAttribute === 'function') {
                    busCell.value.setAttribute('placeholderId', placeholderId);
                    graph.model.setValue(busCell, busCell.value);
                } else {
                    busCell.placeholderId = placeholderId;
                }

                console.log('ELXXX: Created Bus result placeholder with ID:', placeholderId);
            }
        }
    } catch (err) {
        console.error('ELXXX: Error creating Bus result placeholder:', err);
    } finally {
        graph.model.endUpdate();
    }
}

// Make the function globally available for app.min.js
if (typeof window !== 'undefined') {
    window.createBusResultPlaceholder = createBusResultPlaceholder;
}

// Shared result box style for loadFlow.js, loadflowOpenDss.js, shortCircuit.js
// Light grey dashed border, semi-transparent background, readable text
var RESULT_BOX_STYLE = 'shapeELXXX=Result;shape=rounded;rounded=1;arcSize=6;fillColor=#F8F9FA;strokeColor=#6C757D;strokeWidth=1.5;dashed=1;dashPattern=5 5;opacity=70;whiteSpace=wrap;html=1;overflow=hidden;align=center;verticalAlign=middle;fontSize=7;fontColor=#6C757D;fontStyle=0;spacing=3';

/**
 * Insert a result box with proper geometry and styling.
 * Used by loadflowOpenDss.js, shortCircuit.js (loadFlow.js has its own inline version).
 * @param {mxGraph} graph - The mxGraph instance
 * @param {mxCell} parent - Parent cell (vertex or edge)
 * @param {string} resultString - Content to display
 * @param {object} opts - { width, height, positionX, positionY, offsetXDelta, offsetYDelta, isLine }
 */
function insertResultBox(graph, parent, resultString, opts) {
    if (!graph || !parent) return null;
    var w = (opts && opts.width) || 70;
    var h = (opts && opts.height) || 50;
    var px = (opts && typeof opts.positionX === 'number') ? opts.positionX : -0.3;
    var py = (opts && typeof opts.positionY === 'number') ? opts.positionY : 0;
    var offsetXDelta = (opts && typeof opts.offsetXDelta === 'number') ? opts.offsetXDelta : 0;
    var offsetYDelta = (opts && typeof opts.offsetYDelta === 'number') ? opts.offsetYDelta : 0;
    var isLine = (opts && opts.isLine) || (px === 0.5 || px === 0.2);
    var offsetY = isLine ? -h / 2 - 10 + offsetYDelta : -h / 2 - 5 + offsetYDelta;
    var offsetX = -w / 2 + offsetXDelta;
    var boxStyle = RESULT_BOX_STYLE;
    if (opts && opts.connectedToId != null && opts.connectedToId !== '') {
        boxStyle = typeof mxUtils !== 'undefined' && mxUtils.setStyle
            ? mxUtils.setStyle(boxStyle, 'connectedTo', String(opts.connectedToId))
            : boxStyle + ';connectedTo=' + String(opts.connectedToId);
    }
    var cell = graph.insertVertex(parent, null, resultString, px, py, w, h, boxStyle, true);
    if (cell && typeof mxPoint !== 'undefined') {
        var model = graph.getModel();
        var geo = model.getGeometry(cell);
        if (geo) {
            geo.relative = true;
            geo.x = px;
            geo.y = py;
            geo.offset = new mxPoint(offsetX, offsetY);
            model.setGeometry(cell, geo);
        }
    }
    return cell;
}

/**
 * Find existing result placeholder child of parentCell (from resultBoxes.js placeholders).
 * Used by loadFlow.js, loadflowOpenDss.js, shortCircuit.js - update in place instead of remove+insert.
 * @param {mxGraph} graph - The mxGraph instance
 * @param {mxCell} parentCell - Parent cell (vertex or edge) to search
 * @returns {mxCell|null} The placeholder cell or null
 */
function findResultPlaceholder(graph, parentCell) {
    if (!graph || !parentCell || !graph.getModel) return null;
    var model = graph.getModel();
    var childCount = model.getChildCount(parentCell);
    var isResultStyle = function(s) {
        return s && (s.indexOf('shapeELXXX=ResultBus') >= 0 || s.indexOf('shapeELXXX=Result') >= 0 || s.indexOf('shapeELXXX=ResultExternalGrid') >= 0);
    };
    for (var i = 0; i < childCount; i++) {
        var child = model.getChildAt(parentCell, i);
        if (child && isResultStyle(model.getStyle(child))) return child;
    }
    return null;
}

/**
 * Result boxes created via createResultPlaceholder carry connectedTo=&lt;component id&gt;.
 * If placeholderId on a cell was copied from another element, getCell(placeholderId) can point
 * at the wrong box — reject unless connectedTo matches this component.
 */
function resultPlaceholderBelongsToComponent(placeholder, componentCell, model) {
    if (!placeholder || !componentCell || !model) return false;
    var st = model.getStyle(placeholder) || '';
    var isResult = st.indexOf('shapeELXXX=ResultBus') >= 0 || st.indexOf('shapeELXXX=Result') >= 0 || st.indexOf('shapeELXXX=ResultExternalGrid') >= 0;
    if (!isResult) return false;
    var m = st.match(/connectedTo=([^;]+)/);
    if (!m) return true;
    return String(m[1]).trim() === String(componentCell.id);
}

/**
 * Find result placeholder for a component with multiple edges (e.g. Transformer, Three Winding Transformer).
 * Searches by placeholderId first (most reliable), then iterates all edges.
 * @param {mxGraph} graph - The mxGraph instance
 * @param {mxCell} componentCell - The component cell (transformer, external grid, etc.)
 * @returns {mxCell|null} The placeholder cell or null
 */
function findResultPlaceholderForComponent(graph, componentCell) {
    if (!graph || !componentCell || !graph.getModel) return null;
    var model = graph.getModel();
    var placeholderId = null;
    if (componentCell.value && componentCell.value.attributes) {
        var attr = componentCell.value.attributes.getNamedItem('placeholderId');
        if (attr) placeholderId = attr.nodeValue;
    }
    if (!placeholderId && componentCell.placeholderId) placeholderId = componentCell.placeholderId;
    if (placeholderId) {
        var ph = model.getCell(placeholderId);
        if (ph && resultPlaceholderBelongsToComponent(ph, componentCell, model)) return ph;
    }
    var edges = (graph.getEdges && graph.getEdges(componentCell)) || componentCell.edges || [];
    var legacy = null;
    for (var i = 0; i < edges.length; i++) {
        var found = findResultPlaceholder(graph, edges[i]);
        if (!found) continue;
        if (resultPlaceholderBelongsToComponent(found, componentCell, model)) return found;
        var fst = model.getStyle(found) || '';
        if (!/connectedTo=/.test(fst)) legacy = legacy || found;
    }
    return legacy;
}

/**
 * Collect every result placeholder tied to a component (direct child or on incident edges
 * via connectedTo=id). Line vertices often get one placeholder per stub edge from addEdge.
 */
function findAllResultPlaceholdersForComponent(graph, componentCell) {
    var found = [];
    if (!graph || !componentCell || !graph.getModel) return found;
    var model = graph.getModel();
    var compId = String(componentCell.id);
    var isResultStyle = function(s) {
        return s && (s.indexOf('shapeELXXX=ResultBus') >= 0 || s.indexOf('shapeELXXX=Result') >= 0 || s.indexOf('shapeELXXX=ResultExternalGrid') >= 0);
    };
    var matches = function(child, isDirectChild) {
        var st = model.getStyle(child) || '';
        if (!isResultStyle(st)) return false;
        if (isDirectChild) return true;
        var m = st.match(/connectedTo=([^;]+)/);
        return m ? String(m[1]).trim() === compId : false;
    };
    var scan = function(parent, isDirectScan) {
        if (!parent) return;
        var n = model.getChildCount(parent);
        for (var i = 0; i < n; i++) {
            var child = model.getChildAt(parent, i);
            if (child && matches(child, isDirectScan)) {
                found.push({ placeholder: child, parent: parent });
            }
        }
    };
    scan(componentCell, true);
    var edges = (graph.getEdges && graph.getEdges(componentCell)) || componentCell.edges || [];
    for (var ei = 0; ei < edges.length; ei++) {
        scan(edges[ei], false);
    }
    return found;
}

/**
 * Update one result box for a component and remove duplicate placeholders.
 */
function updateOrCreateSinglePlaceholder(graph, componentCell, resultString, fallbackParent, opts) {
    if (!graph || !componentCell || !graph.getModel) return null;
    var model = graph.getModel();
    var all = findAllResultPlaceholdersForComponent(graph, componentCell);
    if (all.length > 0) {
        var keep = all[0].placeholder;
        model.setValue(keep, resultString);
        for (var i = 1; i < all.length; i++) {
            try { model.remove(all[i].placeholder); } catch (err) { /* ignore */ }
        }
        return keep;
    }
    var parent = fallbackParent || componentCell;
    return insertResultBox(graph, parent, resultString, {
        width: (opts && opts.width) || 70,
        height: (opts && opts.height) || 50,
        positionX: (opts && typeof opts.positionX === 'number') ? opts.positionX : 0.5,
        positionY: (opts && typeof opts.positionY === 'number') ? opts.positionY : 0,
        offsetXDelta: (opts && opts.offsetXDelta) || 0,
        offsetYDelta: (opts && opts.offsetYDelta) || 0,
        isLine: opts && opts.isLine,
        connectedToId: componentCell.id
    });
}

function cellStyleOf(model, cell) {
    if (!cell) return '';
    if (model && model.getStyle) {
        var s = model.getStyle(cell);
        if (s) return s;
    }
    if (cell.getStyle) {
        try {
            var gs = cell.getStyle();
            if (gs) return gs;
        } catch (e) { /* ignore */ }
    }
    return cell.style || '';
}

function indexStudyResultRows(rows) {
    var byId = {};
    var byName = {};
    function put(map, key, row) {
        if (key == null || key === '') return;
        var s = String(key);
        map[s] = row;
        map[s.replace(/#/g, '_')] = row;
        map[s.replace(/_/g, '#')] = row;
        map[s.toLowerCase()] = row;
    }
    if (!Array.isArray(rows)) return { byId: byId, byName: byName };
    for (var i = 0; i < rows.length; i++) {
        var row = rows[i];
        if (!row) continue;
        put(byId, row.id, row);
        put(byName, row.name, row);
        put(byName, row.dialogName, row);
        put(byName, row.userFriendlyName, row);
    }
    return { byId: byId, byName: byName };
}

function matchStudyRowToBus(busCell, index) {
    if (!busCell || !index) return null;
    var id = busCell.id != null ? String(busCell.id) : '';
    var mx = busCell.mxObjectId ? String(busCell.mxObjectId) : '';
    var mxU = mx.replace(/#/g, '_');
    var dn = '';
    try {
        if (busCell.value && busCell.value.attributes && busCell.value.attributes.getNamedItem) {
            var n = busCell.value.attributes.getNamedItem('name');
            if (n && n.nodeValue) dn = String(n.nodeValue).trim();
        }
    } catch (e) { /* ignore */ }
    return index.byId[id]
        || index.byName[mx]
        || index.byName[mxU]
        || index.byName[mx.replace(/_/g, '#')]
        || (dn ? (index.byName[dn] || index.byName[dn.toLowerCase()]) : null)
        || null;
}

function busCellForPlaceholder(model, placeholder) {
    if (!model || !placeholder) return null;
    var parent = model.getParent(placeholder);
    var pst = cellStyleOf(model, parent);
    if (parent && isBusStyle(pst)) return parent;
    var st = cellStyleOf(model, placeholder);
    var m = st.match(/connectedTo=([^;]+)/);
    if (m) {
        var bid = String(m[1]).trim();
        var bus = model.getCell(bid);
        if (bus && isBusStyle(cellStyleOf(model, bus))) return bus;
        var cells = model.cells || {};
        for (var ck in cells) {
            var c = cells[ck];
            if (c && String(c.id) === bid && isBusStyle(cellStyleOf(model, c))) return c;
        }
    }
    return null;
}

function setResultPlaceholderValue(graph, placeholder, text) {
    if (!graph || !placeholder) return;
    var model = graph.model || (graph.getModel && graph.getModel());
    if (!model || !model.setValue) return;
    model.setValue(placeholder, text);
    if (graph.view && graph.view.invalidate) {
        try { graph.view.invalidate(placeholder); } catch (e) { /* ignore */ }
    }
}

/**
 * Write study values onto existing bus ResultBus/Result placeholders (resultBoxes.js).
 * Walks the diagram placeholders first so the boxes the user sees are updated.
 *
 * @param {mxGraph} graph
 * @param {Array<object>} rows - backend bus result rows ({id, name, ...})
 * @param {function(row, busCell): string} formatText
 * @returns {{updated:number, created:number}}
 */
function applyBusPlaceholderResults(graph, rows, formatText) {
    var empty = { updated: 0, created: 0 };
    if (!graph || typeof formatText !== 'function') return empty;
    var model = graph.model || (graph.getModel && graph.getModel());
    if (!model) return empty;
    runUpgradeOnce(graph);
    var index = indexStudyResultRows(rows);
    var updated = 0;
    var created = 0;
    var busesTouched = {};

    function visit(cell) {
        if (!cell) return;
        var style = cellStyleOf(model, cell);
        if (isResultPlaceholderStyle(style)) {
            var bus = busCellForPlaceholder(model, cell);
            var row = matchStudyRowToBus(bus, index);
            if (row && bus) {
                setResultPlaceholderValue(graph, cell, formatText(row, bus));
                busesTouched[String(bus.id)] = true;
                updated++;
            }
        }
        var n = model.getChildCount(cell);
        for (var i = 0; i < n; i++) visit(model.getChildAt(cell, i));
    }
    var root = model.getRoot ? model.getRoot() : null;
    if (root) visit(root);

    if (Array.isArray(rows)) {
        for (var r = 0; r < rows.length; r++) {
            var row = rows[r];
            if (!row) continue;
            var bus = null;
            if (row.id != null) bus = model.getCell(row.id) || model.getCell(String(row.id));
            if ((!bus || !isBusStyle(cellStyleOf(model, bus))) && model.cells) {
                var wantName = row.name != null ? String(row.name).replace(/#/g, '_') : '';
                for (var ck in model.cells) {
                    var c = model.cells[ck];
                    if (!c || !isBusStyle(cellStyleOf(model, c))) continue;
                    if (row.id != null && String(c.id) === String(row.id)) { bus = c; break; }
                    var mx = c.mxObjectId ? String(c.mxObjectId).replace(/#/g, '_') : '';
                    if (wantName && mx === wantName) { bus = c; break; }
                }
            }
            if (!bus || !isBusStyle(cellStyleOf(model, bus))) continue;
            if (busesTouched[String(bus.id)]) continue;
            var ph = findResultPlaceholder(graph, bus);
            if (!ph) {
                createBusResultPlaceholder(graph, bus);
                ph = findResultPlaceholder(graph, bus);
            }
            if (ph) {
                setResultPlaceholderValue(graph, ph, formatText(row, bus));
                created++;
            }
        }
    }

    if (graph.view) {
        try {
            if (graph.view.validate) graph.view.validate();
            if (graph.view.refresh) graph.view.refresh();
        } catch (e) { /* ignore */ }
    }
    return { updated: updated, created: created };
}

if (typeof window !== 'undefined') {
    window.RESULT_BOX_STYLE = RESULT_BOX_STYLE;
    window.insertResultBox = insertResultBox;
    window.findResultPlaceholder = findResultPlaceholder;
    window.findResultPlaceholderForComponent = findResultPlaceholderForComponent;
    window.findAllResultPlaceholdersForComponent = findAllResultPlaceholdersForComponent;
    window.updateOrCreateSinglePlaceholder = updateOrCreateSinglePlaceholder;
    window.applyBusPlaceholderResults = applyBusPlaceholderResults;
    window.setResultPlaceholderValue = setResultPlaceholderValue;
}

//=============================================================================
// COMPOSITE BLOCK SUPPORT
// Creates result placeholders for component-to-bus edges in composite blocks
// (e.g. BESS AC block) where edges are imported as a group and don't trigger addEdge
//=============================================================================

function createResultPlaceholdersForCompositeBlock(graph, cells) {
    if (!graph || !cells) return;
    for (var i = 0; i < cells.length; i++) {
        var edgeCell = cells[i];
        if (!edgeCell || !edgeCell.edge) continue;
        var src = edgeCell.source, tgt = edgeCell.target;
        if (!src || !tgt) continue;
        var srcStyle = src.style || '', tgtStyle = tgt.style || '';
        var srcIsBus = isBusStyle(srcStyle);
        var tgtIsBus = isBusStyle(tgtStyle);
        if (!(srcIsBus && !tgtIsBus) && !(tgtIsBus && !srcIsBus)) continue;

        var componentCell = srcIsBus ? tgt : src;
        var componentShape = getShapeElxxx(componentCell.style || '');
        if (!componentShape || componentShape === 'Line') continue;

        var hasPlaceholder = false;
        var childCount = graph.model.getChildCount(edgeCell);
        for (var j = 0; j < childCount; j++) {
            var child = graph.model.getChildAt(edgeCell, j);
            if (child && isResultPlaceholderStyle(child.style || '')) {
                hasPlaceholder = true;
                break;
            }
        }
        if (hasPlaceholder) continue;

        if (isTransformerShape(componentShape) && componentCell.edges) {
            for (var e = 0; e < componentCell.edges.length; e++) {
                var existingEdge = componentCell.edges[e];
                if (!existingEdge) continue;
                var ec = graph.model.getChildCount(existingEdge);
                for (var k = 0; k < ec; k++) {
                    var ech = graph.model.getChildAt(existingEdge, k);
                    if (ech && isResultPlaceholderStyle(ech.style || '')) {
                        hasPlaceholder = true;
                        break;
                    }
                }
                if (hasPlaceholder) break;
            }
            if (hasPlaceholder) continue;
        }

        var isExtGrid = (componentShape === 'External Grid' || componentShape === 'Source 1ph');
        var isBessTrafoOrStorage = (componentShape === 'Transformer' || componentShape === 'Transformer 1ph' || componentShape === 'Storage');
        createResultPlaceholder(graph, edgeCell, componentCell, {
            logicalShape: isExtGrid ? 'ResultExternalGrid' : 'Result',
            width: isExtGrid ? 95 : 70,
            height: isExtGrid ? 58 : 50,
            positionX: -0.3,
            offsetXDelta: isBessTrafoOrStorage ? 10 : 0,
            offsetYDelta: isBessTrafoOrStorage ? 10 : 0
        });
    }
}

if (typeof window !== 'undefined') {
    window.createResultPlaceholdersForCompositeBlock = createResultPlaceholdersForCompositeBlock;
}

//=============================================================================
// CLONING SUPPORT - Update placeholders when cells are cloned/duplicated
// Supports: Bus, Line, and all component result placeholders
// Compatible with: loadFlow.js, loadflowOpenDss.js, shortCircuit.js
//=============================================================================

/**
 * Helper to detect if a child cell is a result placeholder.
 * Handles all styles used by different analysis types:
 * - ResultBus: Created by resultBoxes.js for initial Bus placeholders
 * - Result: Used by loadFlow.js, loadflowOpenDss.js, and shortCircuit.js
 * - ResultExternalGrid: Used for External Grid components
 */
function isResultPlaceholderStyle(style) {
    if (!style) return false;
    return style.includes('shapeELXXX=ResultBus') ||
           style.includes('shapeELXXX=Result') ||
           style.includes('shapeELXXX=ResultExternalGrid');
}

/**
 * Upgrades result placeholders to dashed/transparent format (light grey dashed border, semi-transparent).
 * Converts solid-style placeholders to match the target format.
 */
function upgradeResultPlaceholderStyles(graph) {
    if (!graph || !graph.getModel) return;
    var model = graph.getModel();
    var upgraded = 0;
    function visit(cell) {
        if (!cell) return;
        var style = model.getStyle(cell) || '';
        if (isResultPlaceholderStyle(style) && (style.indexOf('fillColor=#FFFFFF') >= 0 || style.indexOf('dashed=0') >= 0)) {
            var newStyle = style
                .replace(/fillColor=#FFFFFF/g, 'fillColor=#F8F9FA')
                .replace(/strokeColor=#495057/g, 'strokeColor=#6C757D')
                .replace(/strokeWidth=1;/g, 'strokeWidth=1.5;')
                .replace(/dashed=0/g, 'dashed=1')
                .replace(/opacity=100/g, 'opacity=70');
            if (newStyle.indexOf('dashPattern=') < 0) newStyle = newStyle.replace('dashed=1', 'dashed=1;dashPattern=5 5');
            if (newStyle !== style) {
                model.setStyle(cell, newStyle);
                upgraded++;
            }
        }
        var childCount = model.getChildCount(cell);
        for (var i = 0; i < childCount; i++) visit(model.getChildAt(cell, i));
    }
    var root = model.getRoot();
    if (root) visit(root);
    if (upgraded > 0) console.log('ELXXX: Upgraded', upgraded, 'result placeholder(s) to dashed format');
}

/**
 * Helper to detect if a cell is a Line element
 */
function isLineStyle(style) {
    if (!style) return false;
    return style.includes('shapeELXXX=Line');
}

/**
 * Helper to detect if a shape is a Transformer (2-winding, 3-winding, or OpenDSS 1ph)
 * Transformers should only have ONE result placeholder, not one per edge
 */
function isTransformerShape(shape) {
    if (!shape) return false;
    return shape === 'Transformer' || shape === 'Three Winding Transformer' || shape === 'Transformer 1ph';
}

/**
 * Updates the result placeholder for a cloned Bus cell.
 * When a Bus is cloned, its placeholder child is also cloned but with wrong IDs.
 * This function updates the cloned placeholder to properly reference the new bus.
 * 
 * Handles both ResultBus (initial placeholders) and Result (OpenDSS/ShortCircuit) styles.
 */
function updateClonedBusPlaceholder(graph, clonedBusCell) {
    if (!graph || !clonedBusCell) return;

    var busStyle = clonedBusCell.style || '';
    if (!isBusStyle(busStyle)) return;

    graph.model.beginUpdate();
    try {
        // Find all result placeholder children (ResultBus, Result, etc.)
        var childCount = graph.model.getChildCount(clonedBusCell);
        var placeholderChildren = [];
        var faultMarkers = [];
        
        for (var i = 0; i < childCount; i++) {
            var child = graph.model.getChildAt(clonedBusCell, i);
            var childStyle = child.style || '';
            if (isResultPlaceholderStyle(childStyle)) {
                placeholderChildren.push(child);
            } else if (childStyle.indexOf('shapeELXXX=FaultMarker') >= 0) {
                faultMarkers.push(child);
            }
        }
        for (var fm = 0; fm < faultMarkers.length; fm++) {
            graph.model.remove(faultMarkers[fm]);
        }

        if (placeholderChildren.length > 0) {
            // Update all placeholder children
            for (var j = 0; j < placeholderChildren.length; j++) {
                var placeholderChild = placeholderChildren[j];
                
                // Get the new placeholder ID
                var newPlaceholderId = placeholderChild.id;
                if (!newPlaceholderId && placeholderChild.mxObjectId) {
                    newPlaceholderId = placeholderChild.mxObjectId.replace('#', '');
                }

                // Update the placeholder style with new connectedTo and placeholderId
                var oldStyle = placeholderChild.style || '';
                var newStyle = oldStyle
                    .replace(/connectedTo=[^;]+/, 'connectedTo=' + clonedBusCell.id)
                    .replace(/placeholderId=[^;]+/, 'placeholderId=' + newPlaceholderId);
                
                // If connectedTo wasn't in the style, add it
                if (!newStyle.includes('connectedTo=')) {
                    newStyle += ';connectedTo=' + clonedBusCell.id;
                }
                // If placeholderId wasn't in the style, add it
                if (!newStyle.includes('placeholderId=')) {
                    newStyle += ';placeholderId=' + newPlaceholderId;
                }
                
                graph.model.setStyle(placeholderChild, newStyle);

                // Reset placeholder content to default message
                graph.model.setValue(placeholderChild, 'Click Simulate to generate results');

                console.log('ELXXX: Updated cloned Bus result placeholder - Bus ID:', clonedBusCell.id, 'Placeholder ID:', newPlaceholderId, 'Style type:', oldStyle.includes('ResultBus') ? 'ResultBus' : 'Result');
            }
            
            // Update the Bus cell's placeholderId attribute to point to the first placeholder
            // (This is the primary one that loadFlow.js will use)
            var primaryPlaceholderId = placeholderChildren[0].id;
            if (!primaryPlaceholderId && placeholderChildren[0].mxObjectId) {
                primaryPlaceholderId = placeholderChildren[0].mxObjectId.replace('#', '');
            }
            
            if (clonedBusCell.value && typeof clonedBusCell.value.setAttribute === 'function') {
                clonedBusCell.value.setAttribute('placeholderId', primaryPlaceholderId);
                graph.model.setValue(clonedBusCell, clonedBusCell.value);
            } else {
                clonedBusCell.placeholderId = primaryPlaceholderId;
            }
        } else {
            // No placeholder child found - create a new one
            console.log('ELXXX: No placeholder found for cloned Bus, creating new one');
            // Clear any old placeholderId attribute first
            if (clonedBusCell.value && typeof clonedBusCell.value.setAttribute === 'function') {
                clonedBusCell.value.removeAttribute('placeholderId');
                graph.model.setValue(clonedBusCell, clonedBusCell.value);
            } else {
                delete clonedBusCell.placeholderId;
            }
            createBusResultPlaceholder(graph, clonedBusCell);
        }
    } catch (err) {
        console.error('ELXXX: Error updating cloned Bus placeholder:', err);
    } finally {
        graph.model.endUpdate();
    }
}

/**
 * Updates the result placeholder for a cloned Line cell.
 * When a Line is cloned, its placeholder child is also cloned but with wrong IDs.
 * This function updates the cloned placeholder to properly reference the new line.
 */
function updateClonedLinePlaceholder(graph, clonedLineCell) {
    if (!graph || !clonedLineCell) return;

    var lineStyle = clonedLineCell.style || '';
    if (!isLineStyle(lineStyle)) return;

    graph.model.beginUpdate();
    try {
        // Find all result placeholder children
        var childCount = graph.model.getChildCount(clonedLineCell);
        var placeholderChildren = [];
        
        for (var i = 0; i < childCount; i++) {
            var child = graph.model.getChildAt(clonedLineCell, i);
            var childStyle = child.style || '';
            if (isResultPlaceholderStyle(childStyle)) {
                placeholderChildren.push(child);
            }
        }

        if (placeholderChildren.length > 0) {
            // Update all placeholder children
            for (var j = 0; j < placeholderChildren.length; j++) {
                var placeholderChild = placeholderChildren[j];
                
                // Get the new placeholder ID
                var newPlaceholderId = placeholderChild.id;
                if (!newPlaceholderId && placeholderChild.mxObjectId) {
                    newPlaceholderId = placeholderChild.mxObjectId.replace('#', '');
                }

                // Update the placeholder style with new connectedTo and placeholderId
                var oldStyle = placeholderChild.style || '';
                var newStyle = oldStyle
                    .replace(/connectedTo=[^;]+/, 'connectedTo=' + clonedLineCell.id)
                    .replace(/placeholderId=[^;]+/, 'placeholderId=' + newPlaceholderId);
                
                // If connectedTo wasn't in the style, add it
                if (!newStyle.includes('connectedTo=')) {
                    newStyle += ';connectedTo=' + clonedLineCell.id;
                }
                // If placeholderId wasn't in the style, add it
                if (!newStyle.includes('placeholderId=')) {
                    newStyle += ';placeholderId=' + newPlaceholderId;
                }
                
                graph.model.setStyle(placeholderChild, newStyle);

                // Reset placeholder content to default message
                graph.model.setValue(placeholderChild, 'Click Simulate to generate results');

                console.log('ELXXX: Updated cloned Line result placeholder - Line ID:', clonedLineCell.id, 'Placeholder ID:', newPlaceholderId);
            }
            
            // Update the Line cell's placeholderId attribute
            var primaryPlaceholderId = placeholderChildren[0].id;
            if (!primaryPlaceholderId && placeholderChildren[0].mxObjectId) {
                primaryPlaceholderId = placeholderChildren[0].mxObjectId.replace('#', '');
            }
            
            if (clonedLineCell.value && typeof clonedLineCell.value.setAttribute === 'function') {
                clonedLineCell.value.setAttribute('placeholderId', primaryPlaceholderId);
                graph.model.setValue(clonedLineCell, clonedLineCell.value);
            } else {
                clonedLineCell.placeholderId = primaryPlaceholderId;
            }
        } else {
            // No placeholder child found - clear any stale placeholderId
            console.log('ELXXX: No placeholder found for cloned Line, clearing stale ID');
            if (clonedLineCell.value && typeof clonedLineCell.value.setAttribute === 'function') {
                clonedLineCell.value.removeAttribute('placeholderId');
                graph.model.setValue(clonedLineCell, clonedLineCell.value);
            } else {
                delete clonedLineCell.placeholderId;
            }
        }
    } catch (err) {
        console.error('ELXXX: Error updating cloned Line placeholder:', err);
    } finally {
        graph.model.endUpdate();
    }
}

/**
 * Updates the result placeholder for a cloned component cell (connected via edge).
 * Handles ALL components connected to buses via edges, including:
 * - External Grid, Generator, Static Generator, Asymmetric Static Generator
 * - Load, Asymmetric Load, Motor, Storage
 * - Transformer, Three Winding Transformer
 * - Shunt Reactor, Capacitor
 * - Impedance, Ward, Extended Ward
 * - SVC, TCSC, SSC, DC Line
 * 
 * Note: Each edge of a component gets its own placeholder. Components with multiple edges
 * (e.g., Transformers with HV and LV edges) will have multiple placeholders updated.
 */
function updateClonedComponentPlaceholder(graph, clonedCell) {
    if (!graph || !clonedCell) return;

    var cellStyle = clonedCell.style || '';
    // Skip if it's a Bus or Line (handled separately) or has no Electrisim shape
    if (isBusStyle(cellStyle) || isLineStyle(cellStyle)) return;
    if (!cellStyle.includes('shapeELXXX=')) return;
    
    // Check if cell has edges (components are connected to buses via edges)
    if (!clonedCell.edges || clonedCell.edges.length === 0) return;

    graph.model.beginUpdate();
    try {
        var firstPlaceholderId = null;
        
        // Find result placeholders in the connected edges
        for (var e = 0; e < clonedCell.edges.length; e++) {
            var edge = clonedCell.edges[e];
            if (!edge) continue;
            
            var childCount = graph.model.getChildCount(edge);
            for (var i = 0; i < childCount; i++) {
                var child = graph.model.getChildAt(edge, i);
                if (!child) continue;
                // Use model API for consistency
                var childStyle = graph.model.getStyle(child) || '';
                
                // Check if this is a result placeholder
                if (isResultPlaceholderStyle(childStyle)) {
                    // Get the new placeholder ID
                    var newPlaceholderId = child.id;
                    if (!newPlaceholderId && child.mxObjectId) {
                        newPlaceholderId = child.mxObjectId.replace('#', '');
                    }

                    // Update the placeholder style with new connectedTo and placeholderId
                    var oldStyle = childStyle;
                    var newStyle = oldStyle
                        .replace(/connectedTo=[^;]+/, 'connectedTo=' + clonedCell.id)
                        .replace(/placeholderId=[^;]+/, 'placeholderId=' + newPlaceholderId);
                    
                    // If connectedTo wasn't in the style, add it
                    if (!newStyle.includes('connectedTo=')) {
                        newStyle += ';connectedTo=' + clonedCell.id;
                    }
                    // If placeholderId wasn't in the style, add it
                    if (!newStyle.includes('placeholderId=')) {
                        newStyle += ';placeholderId=' + newPlaceholderId;
                    }
                    
                    graph.model.setStyle(child, newStyle);

                    // Reset placeholder content to default message
                    graph.model.setValue(child, 'Click Simulate to generate results');

                    // Store the first placeholder ID for the component cell (for backward compatibility)
                    // Note: Components can have multiple edges, each with its own placeholder
                    if (!firstPlaceholderId) {
                        firstPlaceholderId = newPlaceholderId;
                    }

                    console.log('ELXXX: Updated cloned component placeholder - Cell ID:', clonedCell.id, 'Edge:', edge.id, 'Placeholder ID:', newPlaceholderId);
                }
            }
        }
        
        // Update the component cell's placeholderId attribute with the first placeholder found
        // (for backward compatibility, though each edge has its own placeholder)
        if (firstPlaceholderId) {
            if (clonedCell.value && typeof clonedCell.value.setAttribute === 'function') {
                clonedCell.value.setAttribute('placeholderId', firstPlaceholderId);
                graph.model.setValue(clonedCell, clonedCell.value);
            } else {
                clonedCell.placeholderId = firstPlaceholderId;
            }
        } else {
            // No placeholder found on existing edges - clear any stale placeholderId
            // A new placeholder will be created when a new edge is drawn
            if (clonedCell.value && typeof clonedCell.value.setAttribute === 'function') {
                clonedCell.value.removeAttribute('placeholderId');
                graph.model.setValue(clonedCell, clonedCell.value);
            } else {
                delete clonedCell.placeholderId;
            }
        }
    } catch (err) {
        console.error('ELXXX: Error updating cloned component placeholder:', err);
    } finally {
        graph.model.endUpdate();
    }
}

/**
 * Process an array of cells and update placeholders for all element types.
 * Handles: Bus, Line, and all component cells with result placeholders.
 */
function processClonedCellsForPlaceholders(graph, cells) {
    if (!graph || !cells || cells.length === 0) return;

    for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];
        if (!cell) continue;
        
        var style = cell.style || '';
        
        if (isBusStyle(style)) {
            updateClonedBusPlaceholder(graph, cell);
        } else if (isLineStyle(style)) {
            updateClonedLinePlaceholder(graph, cell);
        } else if (style.includes('shapeELXXX=')) {
            // Other components (External Grid, Generator, Load, etc.)
            updateClonedComponentPlaceholder(graph, cell);
        }
    }
}

// Keep the old function name for backward compatibility
function processClonedCellsForBusPlaceholders(graph, cells) {
    processClonedCellsForPlaceholders(graph, cells);
}

// Make these functions globally available
if (typeof window !== 'undefined') {
    window.isResultPlaceholderStyle = isResultPlaceholderStyle;
    window.isLineStyle = isLineStyle;
    window.isTransformerShape = isTransformerShape;
    window.updateClonedBusPlaceholder = updateClonedBusPlaceholder;
    window.updateClonedLinePlaceholder = updateClonedLinePlaceholder;
    window.updateClonedComponentPlaceholder = updateClonedComponentPlaceholder;
    window.processClonedCellsForPlaceholders = processClonedCellsForPlaceholders;
    window.processClonedCellsForBusPlaceholders = processClonedCellsForBusPlaceholders; // backward compatibility
}

//=============================================================================
// OVERRIDE duplicateCells to handle placeholder updates for cloned cells
// Supports: Bus, Line, and all component result placeholders
//=============================================================================

// Store original duplicateCells (wait for Graph to be defined)
var _originalDuplicateCells = null;

function initDuplicateCellsOverride() {
    if (typeof Graph !== 'undefined' && Graph.prototype.duplicateCells && !_originalDuplicateCells) {
        _originalDuplicateCells = Graph.prototype.duplicateCells;
        
        Graph.prototype.duplicateCells = function(cells, append) {
            var result = _originalDuplicateCells.apply(this, arguments);
            
            // Process cloned cells for all placeholder types (Bus, Line, Components)
            if (result && result.length > 0) {
                try {
                    processClonedCellsForPlaceholders(this, result);
                } catch (err) {
                    console.error('ELXXX: Error processing cloned cells for placeholders:', err);
                }
            }
            
            return result;
        };
        
        console.log('ELXXX: duplicateCells override installed for placeholder support (Bus, Line, Components)');
    }
}

//=============================================================================
// OVERRIDE mxClipboard.paste to handle placeholder updates for pasted cells
// Supports: Bus, Line, and all component result placeholders
//=============================================================================

var _originalClipboardPaste = null;

function initClipboardPasteOverride() {
    if (typeof mxClipboard !== 'undefined' && mxClipboard.paste && !_originalClipboardPaste) {
        _originalClipboardPaste = mxClipboard.paste;
        
        mxClipboard.paste = function(graph) {
            var result = _originalClipboardPaste.apply(this, arguments);
            
            // Process pasted cells for all placeholder types (Bus, Line, Components)
            if (result && result.length > 0 && graph) {
                try {
                    processClonedCellsForPlaceholders(graph, result);
                } catch (err) {
                    console.error('ELXXX: Error processing pasted cells for placeholders:', err);
                }
            }
            
            return result;
        };
        
        console.log('ELXXX: mxClipboard.paste override installed for placeholder support (Bus, Line, Components)');
    }
}

// Initialize overrides when the page loads
if (typeof window !== 'undefined') {
    // Try to initialize immediately
    initDuplicateCellsOverride();
    initClipboardPasteOverride();
    
    // Also try after a delay (in case Graph/mxClipboard aren't defined yet)
    setTimeout(function() {
        initDuplicateCellsOverride();
        initClipboardPasteOverride();
    }, 1000);
    
    // Also try on DOMContentLoaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initDuplicateCellsOverride();
            initClipboardPasteOverride();
        });
    }
}

// Helper to create a professional placeholder box
function createResultPlaceholder(graph, parentEdge, componentCell, opts) {
    if (graph && graph._elxxxSkipPlaceholders) return;
    runUpgradeOnce(graph);
    var externalId = componentCell.id;

    var baseStyle = [
        'shape=rounded',
        'rounded=1',
        'arcSize=6',
        'fillColor=#F8F9FA',
        'strokeColor=#6C757D',
        'strokeWidth=1.5',
        'dashed=1',
        'dashPattern=5 5',
        'opacity=70',
        'whiteSpace=wrap',
        'html=1',
        'overflow=hidden',
        'align=center',
        'verticalAlign=middle',
        'fontSize=7',
        'fontColor=#6C757D',
        'fontStyle=0',
        'spacing=3',
        'connectedTo=' + externalId
    ].join(';');

    // Allow overriding the logical Electrisim result shape (for External Grid)
    var logicalShape = opts && opts.logicalShape
        ? 'shapeELXXX=' + opts.logicalShape
        : 'shapeELXXX=Result';

    var placeholderStyle = logicalShape + ';' + baseStyle;

    var boxWidth = (opts && opts.width) || 60;
    var boxHeight = (opts && opts.height) || 40;
    var positionX = (opts && typeof opts.positionX === 'number') ? opts.positionX : -0.3;
    // For all positions, ensure consistent relative positioning
    var positionY = (opts && typeof opts.positionY === 'number') ? opts.positionY : 0;
    var offsetXDelta = (opts && typeof opts.offsetXDelta === 'number') ? opts.offsetXDelta : 0;
    var offsetYDelta = (opts && typeof opts.offsetYDelta === 'number') ? opts.offsetYDelta : 0;
    // Offset to position box above the line - adjusted for better centering
    // positionX of 0.2 gives the middle of the line for Line/NotEditableLine elements
    var isLineMiddle = (positionX === 0.2 || positionX === 0.5);
    var offsetY = isLineMiddle ? -boxHeight / 2 - 10 : -boxHeight / 2 - 5;

    graph.model.beginUpdate();
    try {
        var placeholder = graph.insertVertex(
            parentEdge,
            null,
            'Click Simulate to generate results',
            positionX,
            positionY,
            boxWidth,
            boxHeight,
            placeholderStyle,
            true
        );

        if (placeholder) {
            var geo = graph.model.getGeometry(placeholder);
            if (geo) {
                geo.relative = true;
                geo.x = positionX;
                geo.y = positionY;
                if (typeof mxPoint !== 'undefined') {
                    geo.offset = new mxPoint(-boxWidth / 2 + offsetXDelta, offsetY + offsetYDelta);
                }
                graph.model.setGeometry(placeholder, geo);
            }

            // Get the placeholder ID - prefer the actual cell id, fallback to mxObjectId without '#' prefix
            var placeholderId = placeholder.id;
            if (!placeholderId && placeholder.mxObjectId) {
                // mxObjectId format is typically '#mxCell-123', we need to strip the '#' for getCell to work
                placeholderId = placeholder.mxObjectId.replace('#', '');
            }
            if (placeholderId) {
                // Make placeholder traceable
                graph.model.setStyle(
                    placeholder,
                    placeholderStyle + ';placeholderId=' + placeholderId
                );

                // Store reference on the component cell itself so results logic can find it
                if (componentCell) {
                    if (componentCell.value && typeof componentCell.value.setAttribute === 'function') {
                        componentCell.value.setAttribute('placeholderId', placeholderId);
                        graph.model.setValue(componentCell, componentCell.value);
                    } else {
                        componentCell.placeholderId = placeholderId;
                    }
                }
            }
        }
    } catch (err) {
        console.error('ELXXX: Error creating placeholder:', err);
    } finally {
        graph.model.endUpdate();
    }
}

function applyResultBoxesHook() {
    if (typeof mxGraph === 'undefined' || typeof mxConnectionHandler === 'undefined' || originalGraphAddEdge !== null) return;
    originalGraphAddEdge = mxGraph.prototype.addEdge;
    mxGraph.prototype.addEdge = function (edge, parent, source, target, index) {
        // Prevent recursive re-entry when our own placeholder creation triggers internal addEdge calls
        if (this._elxxxInAddEdge) {
            return originalGraphAddEdge.apply(this, arguments);
        }

        this._elxxxInAddEdge = true;
        try {
            var result = originalGraphAddEdge.apply(this, arguments);

        try {
            if (!result || !source || !target) {
                return result;
            }

            var sourceStyle = source.style || '';
            var targetStyle = target.style || '';
            var edgeStyle = result.style || '';

            var sourceShape = getShapeElxxx(sourceStyle);
            var targetShape = getShapeElxxx(targetStyle);
            var edgeShape = getShapeElxxx(edgeStyle);

            // 1) Placeholders for Line elements (Bus-to-Bus edges with shapeELXXX=Line)
            // Lines created via import use insertEdge, so they go through addEdge but not the connect handler.
            var sourceIsBus = isBusStyle(sourceStyle);
            var targetIsBus = isBusStyle(targetStyle);
            var edgeIsLine = (edgeShape === 'Line' || edgeShape === 'Line 1ph');

            if (sourceIsBus && targetIsBus && edgeIsLine) {
                var lineHasPlaceholder = false;
                if (result) {
                    var lineChildCount = this.model.getChildCount(result);
                    for (var li = 0; li < lineChildCount; li++) {
                        var lineChild = this.model.getChildAt(result, li);
                        if (!lineChild) continue;
                        var lineChildStyle = this.model.getStyle(lineChild) || '';
                        if (isResultPlaceholderStyle(lineChildStyle)) {
                            lineHasPlaceholder = true;
                            break;
                        }
                    }
                }
                if (!lineHasPlaceholder) {
                    createResultPlaceholder(this, result, result, {
                        logicalShape: 'Result',
                        width: 70,
                        height: 80,
                        positionX: 0
                    });
                }
            }
            // 2) Placeholders for ALL components connected to a Bus via edges
            // This includes: External Grid, Generator, Load, Motor, Transformer, Shunt Reactor,
            // Capacitor, Static Generator, Asymmetric Static Generator, Asymmetric Load,
            // Impedance, Ward, Extended Ward, Storage, SVC, TCSC, SSC, DC Line,
            // DC Bus, Load DC, Source DC, Switch, VSC, B2B VSC, etc.
            // Switch has results in net.res_switch (p_from_mw, q_from_mvar, i_ka, loading_percent)
            else if ((sourceIsBus && !targetIsBus && targetShape) ||
                (targetIsBus && !sourceIsBus && sourceShape)) {

                var componentCell = sourceIsBus ? target : source;
                var componentShape = sourceIsBus ? targetShape : sourceShape;

                // For edge-based placeholders, check if a placeholder already exists on THIS specific edge
                var edgeHasPlaceholder = false;
                if (result) {
                    // Use model API for consistency with rest of codebase
                    var childCount = this.model.getChildCount(result);
                    for (var i = 0; i < childCount; i++) {
                        var child = this.model.getChildAt(result, i);
                        if (!child) continue;
                        var childStyle = this.model.getStyle(child) || '';
                        if (childStyle && (childStyle.includes('shapeELXXX=Result') || 
                            childStyle.includes('shapeELXXX=ResultExternalGrid'))) {
                            edgeHasPlaceholder = true;
                            break;
                        }
                    }
                }

                // Transformers and Line vertices: only ONE placeholder total (not one per stub edge)
                var componentHasAnyPlaceholder = false;
                if ((isTransformerShape(componentShape) || isLineStyle(componentCell.style || '')) && componentCell.edges) {
                    for (var e = 0; e < componentCell.edges.length; e++) {
                        var existingEdge = componentCell.edges[e];
                        if (!existingEdge) continue;
                        var edgeChildCount = this.model.getChildCount(existingEdge);
                        for (var j = 0; j < edgeChildCount; j++) {
                            var edgeChild = this.model.getChildAt(existingEdge, j);
                            if (!edgeChild) continue;
                            var edgeChildStyle = this.model.getStyle(edgeChild) || '';
                            if (edgeChildStyle && (edgeChildStyle.includes('shapeELXXX=Result') ||
                                edgeChildStyle.includes('shapeELXXX=ResultExternalGrid'))) {
                                componentHasAnyPlaceholder = true;
                                break;
                            }
                        }
                        if (componentHasAnyPlaceholder) break;
                    }
                    if (!componentHasAnyPlaceholder) {
                        var directChildCount = this.model.getChildCount(componentCell);
                        for (var dc = 0; dc < directChildCount; dc++) {
                            var directChild = this.model.getChildAt(componentCell, dc);
                            if (directChild && isResultPlaceholderStyle(this.model.getStyle(directChild) || '')) {
                                componentHasAnyPlaceholder = true;
                                break;
                            }
                        }
                    }
                }

                var singlePlaceholderShape = isTransformerShape(componentShape) || isLineStyle(componentCell.style || '');
                var shouldCreatePlaceholder = !edgeHasPlaceholder &&
                    (!singlePlaceholderShape || !componentHasAnyPlaceholder);

                if (shouldCreatePlaceholder) {
                    // Use a dedicated logical shape for External Grid result boxes
                    // External Grid needs a larger box to fit load flow (P, Q, PF, Q/P) and short-circuit (ikss, ip, ith, rk, xk) results
                    var logicalShape = (componentShape === 'External Grid' || componentShape === 'Source 1ph')
                        ? 'ResultExternalGrid'
                        : 'Result';
                    var isExternalGrid = (componentShape === 'External Grid' || componentShape === 'Source 1ph');
                    createResultPlaceholder(this, result, componentCell, {
                        logicalShape: logicalShape,
                        width: isExternalGrid ? 95 : 70,
                        height: isExternalGrid ? 58 : 50,
                        positionX: -0.3
                    });
                }
            }           

            
        } catch (err) {
            console.error('ELXXX: Error in addEdge placeholder logic:', err);
        }

        return result;
    } finally {
        this._elxxxInAddEdge = false;
    }
};

    //=============================================================================
    // Connection Handler - Line Creation Logic
    //=============================================================================
    // This code extends mxConnectionHandler to set up Line parameters when
    // connecting two Bus objects together
    //=============================================================================

    //rysowanie linii łączącej obiekty
    //e - mxGraphModel 
    //g - mxCell - finalne połączenie z atrybutami source i target
    mxConnectionHandler.prototype.connect = function (a, b, c, d) {

    //console.log('connect tutaj')
    if (null != b || this.isCreateTarget(c) || this.graph.allowDanglingEdges) {
        var e = this.graph.getModel(),
            f = !1,
            g = null;
        console.log(e)
        e.beginUpdate();
        try {
            if (null != a && null == b && !this.graph.isIgnoreTerminalEvent(c) && this.isCreateTarget(c) && (b = this.createTargetVertex(c, a), null != b)) {
                d = this.graph.getDropTarget([b], c, d);
                f = !0;
                if (null != d && this.graph.getModel().isEdge(d)) d = this.graph.getDefaultParent();
                else {
                    var k = this.graph.getView().getState(d);
                    if (null != k) {
                        var l = e.getGeometry(b);
                        l.x -= k.origin.x;
                        l.y -= k.origin.y
                    }
                }
                this.graph.addCell(b, d)
            }
            var m = this.graph.getDefaultParent();
            null != a && null != b && e.getParent(a) == e.getParent(b) && e.getParent(e.getParent(a)) != e.getRoot() && (m = e.getParent(a), null != a.geometry && a.geometry.relative && null != b.geometry && b.geometry.relative && (m = e.getParent(m)));
            var n = k = null;
            null != this.edgeState && (k = this.edgeState.cell.value, n = this.edgeState.cell.style);
            g = this.insertEdge(m, null, k, a, b, n);
            if (null != g) {
                this.graph.setConnectionConstraint(g, a, !0, this.sourceConstraint);
                this.graph.setConnectionConstraint(g, b, !1, this.constraintHandler.currentConstraint);
                null != this.edgeState && e.setGeometry(g, this.edgeState.cell.geometry);
                m = e.getParent(a);
                if (this.isInsertBefore(g, a, b, c, d)) {
                    for (l = a; null != l.parent && null != l.geometry && l.geometry.relative && l.parent != g.parent;) l = this.graph.model.getParent(l);
                    null != l && null != l.parent && l.parent == g.parent && e.add(m, g, l.parent.getIndex(l))
                }
                var p = e.getGeometry(g);
                null == p && (p = new mxGeometry, p.relative = !0, e.setGeometry(g, p));
                if (null != this.waypoints &&
                    0 < this.waypoints.length) {
                    var q = this.graph.view.scale,
                        r = this.graph.view.translate;
                    p.points = [];
                    for (a = 0; a < this.waypoints.length; a++) {
                        var t = this.waypoints[a];
                        p.points.push(new mxPoint(t.x / q - r.x, t.y / q - r.y))
                    }
                }
                if (null == b) {
                    var u = this.graph.view.translate,
                        q = this.graph.view.scale,
                        t = null != this.originalPoint ? new mxPoint(this.originalPoint.x / q - u.x, this.originalPoint.y / q - u.y) : new mxPoint(this.currentPoint.x / q - u.x, this.currentPoint.y / q - u.y);
                    t.x -= this.graph.panDx / this.graph.view.scale;
                    t.y -= this.graph.panDy / this.graph.view.scale;
                    p.setTerminalPoint(t, !1)
                }
                this.fireEvent(new mxEventObject(mxEvent.CONNECT, "cell", g, "terminal", b, "event", c, "target", d, "terminalInserted", f))
            }
        } catch (x) {
            mxLog.show(), mxLog.debug(x.message)
        } finally {
            e.endUpdate()
        }

        //ELXXX

        //g - mxCell - linia
        //e - mxGraph

        //ustaw label        
        e.setValue(g, '');

        var parametry = e.getValue(g);

        //jesli linia łączy dwa bus wtedy umożliwij wprowadzanie parametrów linii   
        //do wyszukiwania fraza ELXXX Line
        // Two endpoint patterns become a fully parameterised Line element:
        //   • Bus ↔ Bus (classic pandapower line)
        //   • Switch ↔ Switch (Bus1 → Switch1 → Line → Switch2 → Bus2 — one breaker per cable end)
        // A Bus ↔ Switch edge is just a stub (NotEditableLine) — the Switch ↔ Bus connection
        // itself carries no electrical parameters.
        var isBusEndpoint = function (cell) {
            if (!cell || !cell.style) return false;
            return cell.style.includes('shapeELXXX=Bus') ||
                cell.style.includes('shape=mxgraph.electrical.transmission.busbar');
        };
        var isSwitchEndpoint = function (cell) {
            return !!(cell && cell.style && cell.style.includes('shapeELXXX=Switch'));
        };
        var isLineConnection =
            (isBusEndpoint(g.source) && isBusEndpoint(g.target)) ||
            (isSwitchEndpoint(g.source) && isSwitchEndpoint(g.target));
        if (isLineConnection) {

            //utworzenie parametrów linii
            var listaParametry = mxUtils.createXmlDocument().createElement("object");
            //listaParametry.setAttribute("label", parametry || "");
            listaParametry.setAttribute("from_bus", g.source.mxObjectId);
            listaParametry.setAttribute("to_bus", g.target.mxObjectId);

            //INPUT
            listaParametry.setAttribute("length_km", "0");

            listaParametry.setAttribute("parallel", "1");
            listaParametry.setAttribute("df", "1");

            //możliwość wyboru z biblioteki
            listaParametry.setAttribute("parameters", true);
            // listaParametry.setAttribute("standard_type", false);
            // listaParametry.setAttribute("line_type", true);
            listaParametry.setAttribute("name", "Line");            

            //Load_flow_parameters
            listaParametry.setAttribute("Load_flow_parameters", "");
            listaParametry.setAttribute("r_ohm_per_km", "0");
            listaParametry.setAttribute("x_ohm_per_km", "0");
            listaParametry.setAttribute("c_nf_per_km", "0");
            listaParametry.setAttribute("g_us_per_km", "0");
            listaParametry.setAttribute("max_i_ka", "0");
            listaParametry.setAttribute("type", "cs");

            //Short_circuit_parameters
            listaParametry.setAttribute("Short_circuit_parameters", "");
            listaParametry.setAttribute("r0_ohm_per_km", 0.0); //w specyfikacji PandaPower jako nan
            listaParametry.setAttribute("x0_ohm_per_km", "0"); //w specyfikacji PandaPower jako nan
            listaParametry.setAttribute("c0_nf_per_km", "0"); //w specyfikacji PandaPower jako nan
            listaParametry.setAttribute("endtemp_degree", "0");                   

           
            //listaParametry.setAttribute("max_loading_percent", "0"); //w specyfikacji PandaPower jako nan
            //listaParametry.setAttribute("endtemp_degree", "0"); //w specyfikacji PandaPower jako nan
            //listaParametry.setAttribute("in_service", "True"); //in_service nie działa

            e.setValue(g, listaParametry)

            g.setStyle(g.getStyle() + ";shapeELXXX=Line")

            // Create result placeholder for Line - as child of edge with relative positioning
            try {
                var lineExistingId = g.value &&
                    g.value.attributes &&
                    g.value.attributes.placeholderId &&
                    g.value.attributes.placeholderId.nodeValue;

                if (!lineExistingId) {
                    createResultPlaceholder(this.graph, g, g, {
                        logicalShape: 'Result',
                        width: 70,
                        height: 80,
                        positionX: 0.5 // middle of the line
                    });
                }
            } catch (err) {
                console.error('ELXXX: Error creating placeholder for Line:', err);
            }

        }else{
            g.setStyle(g.getStyle() + ";shapeELXXX=NotEditableLine")
        }

        this.select && this.selectCells(g, f ? b : null)
    }
};
}

// Apply hook when mxGraph is available
function waitForMxGraphAndApply() {
    if (typeof mxGraph !== 'undefined' && typeof mxConnectionHandler !== 'undefined') {
        applyResultBoxesHook();
        // Upgrade existing placeholders when diagram is loaded (e.g. from file)
        setTimeout(function tryUpgradeOnLoad() {
            var graph = null;
            if (typeof Editor !== 'undefined' && Editor.ui && Editor.ui.editor && Editor.ui.editor.graph) {
                graph = Editor.ui.editor.graph;
            } else if (typeof window !== 'undefined' && window.EditorUi && window.EditorUi.getCurrentFile) {
                var ui = window.EditorUi;
                if (ui.editor && ui.editor.graph) graph = ui.editor.graph;
            }
            if (graph && graph.getModel) runUpgradeOnce(graph);
        }, 2500);
        return;
    }
    setTimeout(waitForMxGraphAndApply, 50);
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', waitForMxGraphAndApply);
} else {
    waitForMxGraphAndApply();
}

if (typeof window !== 'undefined') {
    window.upgradeResultPlaceholderStyles = upgradeResultPlaceholderStyles;
}