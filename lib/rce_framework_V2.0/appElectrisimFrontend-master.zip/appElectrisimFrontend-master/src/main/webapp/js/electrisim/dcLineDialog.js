import { Dialog } from './Dialog.js';
import { createEconomicTabContent, buildCostPerUnitByCurrency } from './utils/economicTabHelper.js';
import { OPF_COST_CURRENCY_OPTIONS } from './utils/opfCostCurrency.js';

// Default values for DC line parameters (based on pandapower documentation)
export const defaultDCLineData = {
    name: "DC Line",
    p_mw: 0.0,
    loss_percent: 0.0,
    loss_mw: 0.0,
    vm_from_pu: 0.0,
    vm_to_pu: 0.0,
    in_service: true,
    cost_per_unit_by_currency: "0",
    max_p_mw: 10.0,
    min_q_from_mvar: '',
    max_q_from_mvar: '',
    min_q_to_mvar: '',
    max_q_to_mvar: '',
    opf_cost_currency: 'EUR',
    opf_marginal_cost_eur_per_mwh: '',
    opf_cp2_eur_per_mw2: '',
};

export class DCLineDialog extends Dialog {
    constructor(editorUi) {
        super('DC Line Parameters', 'Apply');
        
        this.ui = editorUi || window.App?.main?.editor?.editorUi;
        this.graph = this.ui?.editor?.graph;
        this.currentTab = 'power';
        this.data = { ...defaultDCLineData };
        this.inputs = new Map(); // Initialize inputs map for form elements
        
        // Power parameters (necessary for executing a power flow calculation)
        this.powerParameters = [
            {
                id: 'name',
                label: 'DC Line Name',
                description: 'Name identifier for the DC line',
                type: 'text',
                value: this.data.name
            },
            {
                id: 'p_mw',
                label: 'Active Power (MW)',
                description: 'Active power transmitted from from_bus to to_bus',
                type: 'number',
                value: this.data.p_mw.toString(),
                step: '0.1'
            }
        ];
        
        // Loss parameters
        this.lossParameters = [
            {
                id: 'loss_percent',
                label: 'Loss Percentage (%)',
                description: 'Relative transmission loss in percent of active power transmission',
                type: 'number',
                value: this.data.loss_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'loss_mw',
                label: 'Loss (MW)',
                description: 'Total transmission loss in MW',
                type: 'number',
                value: this.data.loss_mw.toString(),
                step: '0.1',
                min: '0'
            }
        ];
        
        // Voltage parameters
        this.voltageParameters = [
            {
                id: 'vm_from_pu',
                label: 'From Bus Voltage (p.u.)',
                description: 'Voltage setpoint at from bus',
                type: 'number',
                value: this.data.vm_from_pu.toString(),
                step: '0.01',
                min: '0'
            },
            {
                id: 'vm_to_pu',
                label: 'To Bus Voltage (p.u.)',
                description: 'Voltage setpoint at to bus',
                type: 'number',
                value: this.data.vm_to_pu.toString(),
                step: '0.01',
                min: '0'
            },
            {
                id: 'in_service',
                label: 'In Service',
                description: 'Specifies if the DC line is in service (True/False)',
                type: 'checkbox',
                value: this.data.in_service
            }
        ];

        this.opfParameters = [
            {
                id: 'max_p_mw',
                label: 'Maximum transfer (OPF)',
                description: 'Maximum active power from from-bus to to-bus for OPF (pandapower dcline).',
                type: 'number',
                value: String(this.data.max_p_mw),
                step: '0.1',
                min: '0',
            },
            {
                id: 'min_q_from_mvar',
                label: 'Min Q from bus (MVAr)',
                description: 'Reactive power limit at from bus for OPF (optional; backend widens if empty).',
                type: 'number',
                value: String(this.data.min_q_from_mvar),
                step: '0.1',
            },
            {
                id: 'max_q_from_mvar',
                label: 'Max Q from bus (MVAr)',
                type: 'number',
                value: String(this.data.max_q_from_mvar),
                step: '0.1',
            },
            {
                id: 'min_q_to_mvar',
                label: 'Min Q to bus (MVAr)',
                type: 'number',
                value: String(this.data.min_q_to_mvar),
                step: '0.1',
            },
            {
                id: 'max_q_to_mvar',
                label: 'Max Q to bus (MVAr)',
                type: 'number',
                value: String(this.data.max_q_to_mvar),
                step: '0.1',
            },
            {
                id: 'opf_cost_currency',
                label: 'Marginal cost currency (labels)',
                type: 'select',
                value: this.data.opf_cost_currency,
                options: OPF_COST_CURRENCY_OPTIONS.map((o) => ({ value: o.code, label: o.label })),
                description: 'Label for OPF marginal / quadratic cost coefficients.',
            },
            {
                id: 'opf_marginal_cost_eur_per_mwh',
                label: 'OPF marginal cost (∂C/∂P per MWh)',
                type: 'text',
                value: String(this.data.opf_marginal_cost_eur_per_mwh ?? ''),
                description:
                    'Polynomial cp1 or PWL slope on DC transfer P. Leave empty to omit this line from the OPF cost.',
            },
            {
                id: 'opf_cp2_eur_per_mw2',
                label: 'OPF quadratic coefficient',
                type: 'text',
                value: String(this.data.opf_cp2_eur_per_mw2 ?? ''),
                description: 'Polynomial OPF only. Leave empty if unused.',
            },
        ];

        // Economic parameters (for Economic Analysis)
        this.economicParameters = [
            { id: 'cost_per_unit_by_currency', label: 'Cost per unit', description: 'Cost per unit for Economic Analysis CAPEX calculation', type: 'text', value: '' }
        ];
    }

    _finalizeDclineOpfParametersFromPowerTab() {
        const d = defaultDCLineData;
        const opf = this.opfParameters || [];
        const opfBy = (id) => opf.find((p) => p.id === id);
        const pRow = this.powerParameters.find((p) => p.id === 'p_mw');
        const pMw = parseFloat(pRow && pRow.value);
        const pAbs = Number.isFinite(pMw) ? Math.abs(pMw) : 0;

        const isBlank = (v) =>
            v === '' || v === null || v === undefined || (typeof v === 'string' && v.trim() === '');

        const setNumIfBlank = (id, fallbackStr) => {
            const p = opfBy(id);
            if (!p || p.type !== 'number') return;
            if (isBlank(p.value)) p.value = fallbackStr;
        };

        const maxPStr =
            pAbs > 1e-9
                ? String(Math.max(pAbs, Number(d.max_p_mw) || 10))
                : String(d.max_p_mw);
        setNumIfBlank('max_p_mw', maxPStr);

        const maxPEl = opfBy('max_p_mw');
        if (maxPEl && maxPEl.type === 'number' && pAbs > 1e-9) {
            const cur = parseFloat(maxPEl.value);
            if (!Number.isFinite(cur) || cur <= 1e-9) {
                maxPEl.value = String(Math.max(pAbs, Number(d.max_p_mw) || 10));
            }
        }

        ['max_p_mw', 'opf_cost_currency', 'opf_marginal_cost_eur_per_mwh', 'opf_cp2_eur_per_mw2'].forEach((key) => {
            const p = opfBy(key);
            if (!p || !Object.prototype.hasOwnProperty.call(this.data, key)) return;
            if (p.type === 'select') this.data[key] = p.value;
            else if (p.type === 'text') {
                this.data[key] = p.value != null ? String(p.value).trim() : '';
            } else if (p.type === 'number') {
                const n = parseFloat(p.value);
                if (Number.isFinite(n)) this.data[key] = n;
            }
        });
    }
    
    getDescription() {
        return '<strong>Configure DC Line Parameters</strong><br>Set parameters for DC transmission line. See the <a href="https://electrisim.com/documentation.html#dc-line" target="_blank" rel="noopener noreferrer">Electrisim documentation</a>.';
    }
    
    show(callback) {
        // Store callback for later use
        this.callback = callback;
        
        // Create custom dialog content with tabs
        this.showTabDialog();
    }
    
    showTabDialog() {
        // Use global App if ui is not valid
        this.ui = this.ui || window.App?.main?.editor?.editorUi;
        
        // Create main container
        const container = document.createElement('div');
        Object.assign(container.style, {
            fontFamily: 'Arial, sans-serif',
            fontSize: '14px',
            lineHeight: '1.5',
            color: '#333',
            padding: '0',
            margin: '0',
            width: '100%',
            height: '100%',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column'
        });

        // Add description
        const description = document.createElement('div');
        Object.assign(description.style, {
            padding: '6px 10px',
            backgroundColor: '#e3f2fd',
            border: '1px solid #bbdefb',
            borderRadius: '4px',
            fontSize: '12px',
            color: '#1565c0',
            marginBottom: '12px'
        });
        description.innerHTML = this.getDescription();
        container.appendChild(description);

        // Create tab container
        const tabContainer = document.createElement('div');
        Object.assign(tabContainer.style, {
            display: 'flex',
            borderBottom: '2px solid #e9ecef',
            marginBottom: '16px'
        });

        // Create tabs
        const powerTab = this.createTab('Power', 'power', this.currentTab === 'power');
        const lossTab = this.createTab('Losses', 'loss', this.currentTab === 'loss');
        const voltageTab = this.createTab('Voltage', 'voltage', this.currentTab === 'voltage');
        const opfTab = this.createTab('OPF', 'opf', this.currentTab === 'opf');
        const economicTab = this.createTab('Economic', 'economic', this.currentTab === 'economic');
        
        tabContainer.appendChild(powerTab);
        tabContainer.appendChild(lossTab);
        tabContainer.appendChild(voltageTab);
        tabContainer.appendChild(opfTab);
        tabContainer.appendChild(economicTab);
        container.appendChild(tabContainer);

        // Create content area
        const contentArea = document.createElement('div');
        Object.assign(contentArea.style, {
            overflowY: 'auto',
            overflowX: 'hidden',
            flex: '1 1 auto',
            minHeight: '0',
            scrollbarWidth: 'thin',
            scrollbarColor: '#c1c1c1 #f1f1f1',
            paddingRight: '8px'
        });

        // Create tab content containers
        const powerContent = this.createTabContent('power', this.powerParameters);
        const lossContent = this.createTabContent('loss', this.lossParameters);
        const voltageContent = this.createTabContent('voltage', this.voltageParameters);
        const opfContent = this.createTabContent('opf', this.opfParameters);
        const economicContent = this.createTabContent('economic', this.economicParameters);
        
        contentArea.appendChild(powerContent);
        contentArea.appendChild(lossContent);
        contentArea.appendChild(voltageContent);
        contentArea.appendChild(opfContent);
        contentArea.appendChild(economicContent);
        container.appendChild(contentArea);

        // Add button container
        const buttonContainer = document.createElement('div');
        Object.assign(buttonContainer.style, {
            display: 'flex',
            gap: '8px',
            justifyContent: 'flex-end',
            marginTop: '16px',
            paddingTop: '16px',
            borderTop: '1px solid #e9ecef'
        });

        const cancelButton = this.createButton('Cancel', '#6c757d', '#5a6268');
        const applyButton = this.createButton('Apply', '#007bff', '#0056b3');
        
        cancelButton.onclick = (e) => {
            e.preventDefault();
            this.closeDialog();
        };

        applyButton.onclick = (e) => {
            e.preventDefault();
            const values = this.getFormValues();
            console.log('DC Line values:', values);
            
            if (this.callback) {
                this.callback(values);
            }
            
            this.closeDialog();
        };

        buttonContainer.appendChild(cancelButton);
        buttonContainer.appendChild(applyButton);
        container.appendChild(buttonContainer);

        this.container = container;
        
        // Tab click handlers
        powerTab.onclick = () => this.switchTab('power', powerTab, [lossTab, voltageTab, opfTab, economicTab], powerContent, [lossContent, voltageContent, opfContent, economicContent]);
        lossTab.onclick = () => this.switchTab('loss', lossTab, [powerTab, voltageTab, opfTab, economicTab], lossContent, [powerContent, voltageContent, opfContent, economicContent]);
        voltageTab.onclick = () => this.switchTab('voltage', voltageTab, [powerTab, lossTab, opfTab, economicTab], voltageContent, [powerContent, lossContent, opfContent, economicContent]);
        opfTab.onclick = () => this.switchTab('opf', opfTab, [powerTab, lossTab, voltageTab, economicTab], opfContent, [powerContent, lossContent, voltageContent, economicContent]);
        economicTab.onclick = () => this.switchTab('economic', economicTab, [powerTab, lossTab, voltageTab, opfTab], economicContent, [powerContent, lossContent, voltageContent, opfContent]);

        // Show dialog using DrawIO's dialog system
        if (this.ui && typeof this.ui.showDialog === 'function') {
            const screenHeight = window.innerHeight - 80;
            this.ui.showDialog(container, 1000, screenHeight, true, false);
        } else {
            this.showModalFallback(container);
        }
    }
    
    createTab(title, tabId, isActive) {
        const tab = document.createElement('div');
        Object.assign(tab.style, {
            padding: '12px 20px',
            cursor: 'pointer',
            borderBottom: isActive ? '2px solid #007bff' : '2px solid transparent',
            backgroundColor: isActive ? '#f8f9fa' : 'transparent',
            color: isActive ? '#007bff' : '#6c757d',
            fontWeight: isActive ? '600' : '400',
            transition: 'all 0.2s ease',
            userSelect: 'none'
        });
        tab.textContent = title;
        tab.dataset.tab = tabId;
        
        tab.addEventListener('mouseenter', () => {
            if (!tab.classList.contains('active')) {
                tab.style.backgroundColor = '#f8f9fa';
            }
        });
        
        tab.addEventListener('mouseleave', () => {
            if (!tab.classList.contains('active')) {
                tab.style.backgroundColor = 'transparent';
            }
        });
        
        if (isActive) {
            tab.classList.add('active');
        }
        
        return tab;
    }
    
    createTabContent(tabId, parameters) {
        if (tabId === 'economic' && parameters && parameters.length > 0 && parameters[0]?.id === 'cost_per_unit_by_currency') {
            const content = document.createElement('div');
            content.dataset.tab = tabId;
            content.style.display = tabId === this.currentTab ? 'block' : 'none';
            content.appendChild(createEconomicTabContent(buildCostPerUnitByCurrency(this.data), this.inputs, true));
            return content;
        }

        const content = document.createElement('div');
        content.dataset.tab = tabId;
        Object.assign(content.style, {
            display: tabId === this.currentTab ? 'block' : 'none'
        });

        const form = document.createElement('form');
        Object.assign(form.style, {
            display: 'flex',
            flexDirection: 'column',
            gap: '16px'
        });

        parameters.forEach(param => {
            const isNameField = param.id === 'name';
            const parameterRow = document.createElement('div');
            Object.assign(parameterRow.style, {
                display: 'grid',
                gridTemplateColumns: isNameField ? 'minmax(0, 1fr) minmax(300px, 1.2fr)' : '1fr 200px',
                gap: '20px',
                alignItems: 'start',
                padding: '16px',
                backgroundColor: '#f8f9fa',
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                minHeight: '80px'
            });

            // Left column: Label and description
            const leftColumn = document.createElement('div');
            Object.assign(leftColumn.style, {
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                minHeight: '60px'
            });

            const label = document.createElement('label');
            Object.assign(label.style, {
                fontWeight: '600',
                fontSize: '14px',
                color: '#495057',
                marginBottom: '6px',
                lineHeight: '1.2'
            });
            label.textContent = param.label;
            label.htmlFor = param.id;

            const description = document.createElement('div');
            Object.assign(description.style, {
                fontSize: '12px',
                color: '#6c757d',
                lineHeight: '1.4',
                fontStyle: 'italic',
                marginBottom: '4px'
            });
            description.textContent = param.description;

            leftColumn.appendChild(label);
            leftColumn.appendChild(description);

            // Right column: Input field with fixed width
            const rightColumn = document.createElement('div');
            Object.assign(rightColumn.style, {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end',
                minHeight: '60px',
                width: isNameField ? '100%' : '200px',
                ...(isNameField ? { minWidth: '0' } : {})
            });
            
            let input;
            
            // Handle different input types
            if (param.type === 'checkbox') {
                input = document.createElement('input');
                input.type = 'checkbox';
                input.checked = param.value;
                Object.assign(input.style, {
                    width: '24px',
                    height: '24px',
                    accentColor: '#007bff',
                    cursor: 'pointer',
                    margin: '0'
                });
            } else if (param.type === 'select') {
                input = document.createElement('select');
                (param.options || []).forEach((opt) => {
                    const optionElement = document.createElement('option');
                    if (typeof opt === 'object' && opt !== null && 'value' in opt) {
                        optionElement.value = String(opt.value);
                        optionElement.textContent =
                            opt.label != null ? String(opt.label) : String(opt.value);
                    } else {
                        const s = String(opt);
                        optionElement.value = s;
                        optionElement.textContent =
                            s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
                    }
                    if (String(param.value) === optionElement.value) {
                        optionElement.selected = true;
                    }
                    input.appendChild(optionElement);
                });
                Object.assign(input.style, {
                    width: isNameField ? '100%' : '180px',
                    ...(isNameField ? { minWidth: '0' } : {}),
                    padding: '10px 14px',
                    border: '2px solid #ced4da',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontFamily: 'inherit',
                    backgroundColor: '#ffffff',
                    boxSizing: 'border-box',
                    transition: 'all 0.2s ease',
                    outline: 'none',
                    cursor: 'pointer'
                });
                input.addEventListener('focus', () => {
                    input.style.borderColor = '#007bff';
                    input.style.boxShadow = '0 0 0 3px rgba(0, 123, 255, 0.15)';
                    input.style.transform = 'translateY(-1px)';
                });
                input.addEventListener('blur', () => {
                    input.style.borderColor = '#ced4da';
                    input.style.boxShadow = 'none';
                    input.style.transform = 'translateY(0)';
                });
                input.addEventListener('mouseenter', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#adb5bd';
                        input.style.backgroundColor = '#f8f9fa';
                    }
                });
                input.addEventListener('mouseleave', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#ced4da';
                        input.style.backgroundColor = '#ffffff';
                    }
                });
            } else {
                input = document.createElement('input');
                input.type = param.type;
                input.value = param.value;
                Object.assign(input.style, {
                    width: isNameField ? '100%' : '180px',
                    ...(isNameField ? { minWidth: '0' } : {}),
                    padding: '10px 14px',
                    border: '2px solid #ced4da',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontFamily: 'inherit',
                    backgroundColor: '#ffffff',
                    boxSizing: 'border-box',
                    transition: 'all 0.2s ease',
                    outline: 'none'
                });
                
                input.addEventListener('focus', () => {
                    input.style.borderColor = '#007bff';
                    input.style.boxShadow = '0 0 0 3px rgba(0, 123, 255, 0.15)';
                    input.style.transform = 'translateY(-1px)';
                });
                
                input.addEventListener('blur', () => {
                    input.style.borderColor = '#ced4da';
                    input.style.boxShadow = 'none';
                    input.style.transform = 'translateY(0)';
                });
                
                // Add hover effect
                input.addEventListener('mouseenter', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#adb5bd';
                        input.style.backgroundColor = '#f8f9fa';
                    }
                });
                
                input.addEventListener('mouseleave', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#ced4da';
                        input.style.backgroundColor = '#ffffff';
                    }
                });
            }
            
            // Set additional attributes for number inputs
            if (param.type === 'number') {
                if (param.step) input.step = param.step;
                if (param.min !== undefined) input.min = param.min;
                if (param.max !== undefined) input.max = param.max;
            }

            input.id = param.id;
            this.inputs.set(param.id, input);
            rightColumn.appendChild(input);

            parameterRow.appendChild(leftColumn);
            parameterRow.appendChild(rightColumn);
            form.appendChild(parameterRow);
        });

        content.appendChild(form);
        return content;
    }
    
    createButton(text, bgColor, hoverColor) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = text;
        Object.assign(button.style, {
            padding: '8px 16px',
            backgroundColor: bgColor,
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
            transition: 'background-color 0.2s'
        });
        
        button.addEventListener('mouseenter', () => {
            button.style.backgroundColor = hoverColor;
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.backgroundColor = bgColor;
        });
        
        return button;
    }
    
    switchTab(tabId, activeTab, inactiveTabs, activeContent, inactiveContents) {
        this.currentTab = tabId;
        
        // Update active tab styles
        Object.assign(activeTab.style, {
            borderBottom: '2px solid #007bff',
            backgroundColor: '#f8f9fa',
            color: '#007bff',
            fontWeight: '600'
        });
        activeTab.classList.add('active');
        
        // Update inactive tab styles
        inactiveTabs.forEach(inactiveTab => {
            Object.assign(inactiveTab.style, {
                borderBottom: '2px solid transparent',
                backgroundColor: 'transparent',
                color: '#6c757d',
                fontWeight: '400'
            });
            inactiveTab.classList.remove('active');
        });
        
        // Update content visibility
        activeContent.style.display = 'block';
        inactiveContents.forEach(inactiveContent => {
            inactiveContent.style.display = 'none';
        });
    }
    
    getFormValues() {
        const values = {};
        
        // Collect all parameter values from all tabs
        [...this.powerParameters, ...this.lossParameters, ...this.voltageParameters, ...(this.opfParameters || []), ...(this.economicParameters || [])].forEach(param => {
            const input = this.inputs.get(param.id);
            if (input) {
                if (param.id === 'cost_per_unit_by_currency') {
                    values[param.id] = input.value || '0';
                } else if (param.type === 'number') {
                    values[param.id] = parseFloat(input.value) || 0;
                } else if (param.type === 'checkbox') {
                    values[param.id] = input.checked;
                } else {
                    values[param.id] = input.value;
                }
            }
        });
        
        return values;
    }
    
    destroy() {
        // Call parent destroy method
        super.destroy();
        
        // Clear global dialog flags to allow future dialogs
        if (window._globalDialogShowing) {
            delete window._globalDialogShowing;
        }
        
        console.log('DC Line dialog destroyed and flags cleared');
    }
    
    populateDialog(cellData) {
        console.log('=== DCLineDialog.populateDialog called ===');
        console.log('Cell data:', cellData);
        
        // Log initial parameter values
        console.log('Initial parameter values:');
        [...this.powerParameters, ...this.lossParameters, ...this.voltageParameters].forEach(param => {
            console.log(`  ${param.id}: ${param.value} (${param.type})`);
        });
        
        // Update parameter values based on cell data
        if (cellData && cellData.attributes) {
            console.log(`Found ${cellData.attributes.length} attributes to process`);
            
            for (let i = 0; i < cellData.attributes.length; i++) {
                const attribute = cellData.attributes[i];
                const attributeName = attribute.name;
                const attributeValue = attribute.value;
                
                console.log(`Processing attribute: ${attributeName} = ${attributeValue}`);
                
                if (attributeName === 'cost_per_unit_by_currency') {
                    this.data[attributeName] = attributeValue;
                    const ep = this.economicParameters?.find(p => p.id === attributeName);
                    if (ep) ep.value = attributeValue.toString();
                }
                
                // Update the dialog's parameter values (not DOM inputs)
                const powerParam = this.powerParameters.find(p => p.id === attributeName);
                if (powerParam) {
                    const oldValue = powerParam.value;
                    if (powerParam.type === 'checkbox') {
                        powerParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        powerParam.value = attributeValue;
                    }
                    console.log(`  Updated power ${attributeName}: ${oldValue} → ${powerParam.value}`);
                }
                
                const lossParam = this.lossParameters.find(p => p.id === attributeName);
                if (lossParam) {
                    const oldValue = lossParam.value;
                    if (lossParam.type === 'checkbox') {
                        lossParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        lossParam.value = attributeValue;
                    }
                    console.log(`  Updated loss ${attributeName}: ${oldValue} → ${lossParam.value}`);
                }
                
                const voltageParam = this.voltageParameters.find(p => p.id === attributeName);
                if (voltageParam) {
                    const oldValue = voltageParam.value;
                    if (voltageParam.type === 'checkbox') {
                        voltageParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        voltageParam.value = attributeValue;
                    }
                    console.log(`  Updated voltage ${attributeName}: ${oldValue} → ${voltageParam.value}`);
                }

                const opfParam = this.opfParameters?.find(p => p.id === attributeName);
                if (opfParam) {
                    if (opfParam.type === 'checkbox') {
                        opfParam.value = attributeValue === 'true' || attributeValue === true;
                    } else if (opfParam.type === 'select') {
                        const t = attributeValue != null ? String(attributeValue).trim() : '';
                        if (t !== '') opfParam.value = t;
                    } else {
                        opfParam.value = attributeValue != null ? String(attributeValue) : '';
                    }
                }
                
                const economicParam = this.economicParameters?.find(p => p.id === attributeName);
                if (!powerParam && !lossParam && !voltageParam && !opfParam && !economicParam) {
                    console.log(`  WARNING: No parameter found for attribute ${attributeName}`);
                }
            }
        } else {
            console.log('No cell data or attributes found');
        }
        
        this._finalizeDclineOpfParametersFromPowerTab();

        // Log final parameter values
        console.log('Final parameter values:');
        [...this.powerParameters, ...this.lossParameters, ...this.voltageParameters].forEach(param => {
            console.log(`  ${param.id}: ${param.value} (${param.type})`);
        });
        
        console.log('=== DCLineDialog.populateDialog completed ===');
    }
}

// Note: Legacy AG-Grid exports have been removed to prevent conflicts with the new modern dialog system
// The DCLineDialog class is now the primary interface for editing DC line parameters
  
  
  
  