/**
 * Shared network data preparation utility
 * Extracts network components from the graph model for backend processing
 * Used by both loadFlow and bessSizing calculations
 */

import {
    getConnectedBusId,
    parseCellStyle,
    getAttributesAsObject,
    getTransformerConnections,
    getSwitchConnections,
    updateTransformerBusConnections,
    updateThreeWindingTransformerConnections,
    getThreeWindingConnections,
    getImpedanceConnections,
    getConnectedBuses,
    getLineBusEndpointsForPayload,
    validateLineBusTopology,
    validateBusConnections,
    COMPONENT_TYPES,
    isSwitchClosedForPowerFlow
} from '../loadFlow.js';
import { computeWindTurbinePMw, WIND_SC_DEFAULTS } from '../windTurbineDialog.js';
import { resolveStorageFixedPf } from '../storageDialog.js';
import { resolveStorageQSetpoint } from './storageQCapability.js';
import {
    collectWindTurbineControllers,
    collectWindTurbineControllersForPayload,
    applyWindTurbineControllerPrefs
} from './windTurbineControllerApply.js';
import { collectParkControllers } from './parkControllerCollect.js';
import { clearFaultLocationMarkers } from './faultLocationMarkers.js';

/**
 * Check if the model has load and/or generation elements (for Economic Analysis profile options).
 * @param {Object} graph - The mxGraph instance
 * @returns {{ hasLoads: boolean, hasGenerators: boolean }}
 */
export function getEconomicProfileRelevance(graph) {
    if (!graph || !graph.getModel) return { hasLoads: false, hasGenerators: false };
    const model = graph.getModel();
    const cells = model.getDescendants?.() || [];
    const loadTypes = new Set([COMPONENT_TYPES.LOAD, COMPONENT_TYPES.ASYMMETRIC_LOAD]);
    const genTypes = new Set([
        COMPONENT_TYPES.GENERATOR,
        COMPONENT_TYPES.STATIC_GENERATOR,
        COMPONENT_TYPES.WIND_TURBINE,
        COMPONENT_TYPES.ASYMMETRIC_STATIC_GENERATOR,
        'PV System',
        'PVSystem'
    ]);
    let foundLoads = false;
    let foundGens = false;
    for (let i = 0; i < cells.length && (!foundLoads || !foundGens); i++) {
        const cell = cells[i];
        const cellStyle = cell.getStyle?.();
        if (!cellStyle) continue;
        const style = parseCellStyle(cellStyle);
        const ct = style?.shapeELXXX;
        if (ct) {
            if (loadTypes.has(ct)) foundLoads = true;
            if (genTypes.has(ct)) foundGens = true;
        }
        if (!foundGens && cellStyle.includes('Static Generator')) foundGens = true;
        if (!foundGens && cellStyle.includes('Wind Turbine')) foundGens = true;
        if (!foundGens && (cellStyle.includes('PV System') || cellStyle.includes('PVSystem'))) foundGens = true;
    }
    return { hasLoads: foundLoads, hasGenerators: foundGens };
}

const GEN_STUB_SWITCH_ET = 'gen_stub';

function reconcileLineSwitchEnds(lines, switches) {
    const by = new Map();
    (lines || []).forEach((line) => {
        ['name', 'id', 'userFriendlyName'].forEach((key) => {
            if (line && line[key] != null && line[key] !== '') by.set(String(line[key]), line);
        });
    });
    (switches || []).forEach((sw) => {
        const et = String(sw.et || '').toLowerCase();
        if (et !== 'l' && et !== 'line') return;
        const line = by.get(String(sw.element || ''));
        if (!line) return;
        const a = line.busFrom ? String(line.busFrom) : '';
        const b = line.busTo ? String(line.busTo) : '';
        const bus = sw.bus ? String(sw.bus) : '';
        if (a && b && a !== b && (bus === a || bus === b)) return;
        if ((!b || a === b) && bus && bus !== a) {
            if (a) line.busTo = bus;
            else line.busFrom = bus;
            return;
        }
        if (a && bus !== a && bus !== b) sw.bus = a;
    });
}

/**
 * Bus–Switch–injecting element (generator, load, shunt, storage, …): pandapower has no switch type
 * that points at these elements; use ``et='b'``, ``z_ohm=0`` between the diagram bus and a synthetic
 * auxiliary bus, and place the element on the auxiliary bus.
 *
 * @see https://pandapower.readthedocs.io/en/latest/elements/switch.html
 */
function expandGenStubSwitches(componentArrays, counters) {
    const stubSwitches = componentArrays.switch.filter((sw) => sw.et === GEN_STUB_SWITCH_ET);
    if (stubSwitches.length === 0) {
        return;
    }
    const stubTargetArrays = [
        componentArrays.generator,
        componentArrays.staticGenerator,
        componentArrays.asymmetricGenerator,
        componentArrays.storage,
        componentArrays.load,
        componentArrays.asymmetricLoad,
        componentArrays.shuntReactor,
        componentArrays.capacitor,
        componentArrays.motor,
        componentArrays.SVC,
    ];
    const safeToken = (id) => String(id).replace(/[^a-zA-Z0-9_]/g, '_');
    const dropStubSwitchIds = new Set();

    for (const sw of stubSwitches) {
        const cellId = sw.elementCellId;
        if (cellId == null) {
            console.warn('expandGenStubSwitches: missing elementCellId on switch, skip', sw.id);
            continue;
        }
        let injectRec = null;
        for (let i = 0; i < stubTargetArrays.length; i++) {
            injectRec = stubTargetArrays[i].find((g) => g.id === cellId);
            if (injectRec) break;
        }
        if (!injectRec) {
            console.warn('expandGenStubSwitches: no matching bus element for switch, skip', sw.id, cellId);
            continue;
        }
        let mainBusRecord = componentArrays.busbar.find((b) => b.name === sw.bus);
        if (!mainBusRecord) {
            const labelMatches = componentArrays.busbar.filter((b) => b.userFriendlyName === sw.bus);
            if (labelMatches.length === 1) {
                mainBusRecord = labelMatches[0];
            } else if (labelMatches.length > 1) {
                console.error(
                    'expandGenStubSwitches: ambiguous bus reference for Bus–Switch–Element. ' +
                        `Switch "${sw.id}" references bus "${sw.bus}", which matches ${labelMatches.length} buses by label. ` +
                        'Skipping switch resolution; element will keep its current bus.'
                );
                dropStubSwitchIds.add(sw.id);
                delete sw.elementCellId;
                continue;
            }
        }
        if (!mainBusRecord) {
            console.warn('expandGenStubSwitches: main bus not found for switch bus ref', sw.bus, sw.id);
            dropStubSwitchIds.add(sw.id);
            delete sw.elementCellId;
            continue;
        }
        const mainBusKey = mainBusRecord.name;
        const vnKv = mainBusRecord.vn_kv != null ? String(mainBusRecord.vn_kv) : '20';

        if (!isSwitchClosedForPowerFlow(sw)) {
            injectRec.bus = mainBusKey;
            injectRec.in_service = 'false';
            dropStubSwitchIds.add(sw.id);
            delete sw.elementCellId;
            continue;
        }

        const tok = safeToken(sw.id);
        const auxName = `_electrisim_aux_${tok}`;
        componentArrays.busbar.push({
            typ: `Bus${counters.busbar++}`,
            name: auxName,
            id: auxName,
            vn_kv: vnKv,
            userFriendlyName: auxName,
        });
        injectRec.bus = auxName;
        sw.bus = mainBusKey;
        sw.element = auxName;
        sw.et = 'b';
        sw.z_ohm = sw.z_ohm != null && sw.z_ohm !== '' ? sw.z_ohm : '0';
        delete sw.elementCellId;
    }
    if (dropStubSwitchIds.size > 0) {
        componentArrays.switch = componentArrays.switch.filter((s) => !dropStubSwitchIds.has(s.id));
    }
}

// Cache for prepareNetworkData - speeds up repeated analyses when graph unchanged
const _networkDataCache = new WeakMap();

/**
 * Fingerprint of all user-object (parameter) XML on the graph so edits to q_mvar, ratings, etc.
 * invalidate the cache. Previously only cell count + first IDs were used, so RPC could keep
 * stale shunt/generator data while Load Flow (separate code path) showed fresh values.
 */
function _computeGraphContentFingerprint(model) {
    if (!model || !model.getRoot) return '0';
    const chunks = [];
    const walk = (cell) => {
        if (!cell) return;
        const v = model.getValue(cell);
        if (v != null && typeof v === 'object' && v.nodeType === 1) {
            try {
                chunks.push(new XMLSerializer().serializeToString(v));
            } catch (e) {
                chunks.push(String(v));
            }
        } else if (v != null && typeof v !== 'object') {
            chunks.push(String(v));
        }
        const n = model.getChildCount(cell);
        for (let i = 0; i < n; i++) {
            walk(model.getChildAt(cell, i));
        }
    };
    walk(model.getRoot());
    const s = chunks.join('\n');
    let h = 5381;
    for (let i = 0; i < s.length; i++) {
        h = ((h << 5) + h) ^ s.charCodeAt(i);
    }
    return `${chunks.length}_${h >>> 0}`;
}

/**
 * Get user email with robust fallback
 */
function getUserEmail() {
    try {
        const userStr = localStorage.getItem('user');
        if (userStr) {
            const user = JSON.parse(userStr);
            if (user && user.email) {
                return user.email;
            }
        }
        if (typeof getCurrentUser === 'function') {
            const currentUser = getCurrentUser();
            if (currentUser && currentUser.email) {
                return currentUser.email;
            }
        }
        if (window.getCurrentUser && typeof window.getCurrentUser === 'function') {
            const currentUser = window.getCurrentUser();
            if (currentUser && currentUser.email) {
                return currentUser.email;
            }
        }
        if (window.authHandler && window.authHandler.getCurrentUser) {
            const currentUser = window.authHandler.getCurrentUser();
            if (currentUser && currentUser.email) {
                return currentUser.email;
            }
        }
        return 'unknown@user.com';
    } catch (error) {
        console.warn('Error getting user email:', error);
        return 'unknown@user.com';
    }
}

/**
 * Prepare network data from graph model
 * @param {Object} graph - The mxGraph instance
 * @param {Object} simulationParameters - Simulation-specific parameters (loadFlow params or bessSizing params)
 * @param {Object} options - Optional configuration
 * @param {boolean} options.removeResultCells - Whether to remove previous result cells (default: true for loadFlow, false for bessSizing)
 * @returns {Object} Prepared network data object ready for backend
 */
export function prepareNetworkData(graph, simulationParameters, options = {}) {
    const {
        removeResultCells = false  // Default to false, loadFlow can override
    } = options;

    const model = graph.getModel();
    try {
        clearFaultLocationMarkers(graph);
    } catch (e) { /* markers must not block data collection */ }
    const cacheKey = _computeGraphContentFingerprint(model) + '_' + JSON.stringify(simulationParameters) + '_' + removeResultCells;
    let cache = _networkDataCache.get(graph);
    if (cache && cache.key === cacheKey) {
        return cache.result;
    }

    const startTime = performance.now();
    
    // Create counters object
    const counters = {
        externalGrid: 0,
        generator: 0,
        staticGenerator: 0,
        asymmetricGenerator: 0,
        busbar: 0,
        dcBus: 0,
        transformer: 0,
        threeWindingTransformer: 0,
        shuntReactor: 0,
        capacitor: 0,
        load: 0,
        loadDc: 0,
        asymmetricLoad: 0,
        sourceDc: 0,
        switch: 0,
        impedance: 0,
        ward: 0,
        extendedWard: 0,
        motor: 0,
        storage: 0,
        SVC: 0,
        TCSC: 0,
        SSC: 0,
        VSC: 0,
        B2BVSC: 0,
        dcLine: 0,
        line: 0
    };

    // Clear all caches at the start of each simulation to prevent memory accumulation
    const cellCache = new Map();
    const nameCache = new Map();
    const attributeCache = new Map();
    
    // Helper function to get cached cell
    const getCachedCell = (cellId, cellName = null) => {
        if (cellCache.has(cellId)) {
            return cellCache.get(cellId);
        }
        
        let cell = model.getCell(cellId);
        if (cell) {
            cellCache.set(cellId, cell);
            return cell;
        }
        
        if (cellName) {
            const mxObjectId = '#' + cellName.replace('_', '');
            cell = model.getCell(mxObjectId);
            if (cell) {
                cellCache.set(cellId, cell);
                return cell;
            }
        }
        
        const allCells = model.getDescendants();
        for (let i = 0; i < allCells.length; i++) {
            const candidate = allCells[i];
            if (candidate.id === cellId || 
                candidate.mxObjectId === cellId || 
                candidate.mxObjectId === ('#' + cellId.replace('_', '')) ||
                (cellName && candidate.mxObjectId === ('#' + cellName.replace('_', '')))) {
                cellCache.set(cellId, candidate);
                return candidate;
            }
            
            if (candidate.value && candidate.value.attributes) {
                const idAttr = candidate.value.attributes.getNamedItem('id');
                if (idAttr && idAttr.nodeValue === cellId) {
                    cellCache.set(cellId, candidate);
                    return candidate;
                }
                for (let j = 0; j < candidate.value.attributes.length; j++) {
                    const attr = candidate.value.attributes[j];
                    if (attr.nodeName === 'id' && attr.nodeValue === cellId) {
                        cellCache.set(cellId, candidate);
                        return candidate;
                    }
                }
            }
        }
        
        console.warn('Could not find cell for id:', cellId, 'name:', cellName);
        return null;
    };
    
    // Optimized userFriendlyName function with caching
    const getUserFriendlyName = (cell) => {
        const cellId = cell.id;
        if (nameCache.has(cellId)) {
            return nameCache.get(cellId);
        }
        
        let name = cell.mxObjectId.replace('#', '_');
        if (cell.value && cell.value.attributes) {
            for (let i = 0; i < cell.value.attributes.length; i++) {
                if (cell.value.attributes[i].nodeName === 'name') {
                    name = cell.value.attributes[i].nodeValue;
                    break;
                }
            }
        }
        
        nameCache.set(cellId, name);
        return name;
    };
    
    // Highly optimized cached version
    const getCachedAttributes = (cell, attributeMap) => {
        const cacheKey = `${cell.id}_${Object.keys(attributeMap).length}`;
        if (attributeCache.has(cacheKey)) {
            return attributeCache.get(cacheKey);
        }
        
        const result = getAttributesAsObject(cell, attributeMap);
        attributeCache.set(cacheKey, result);
        return result;
    };

    // Create arrays for different components
    const componentArrays = {
        simulationParameters: [],
        externalGrid: [],
        generator: [],
        staticGenerator: [],
        asymmetricGenerator: [],
        busbar: [],
        dcBus: [],
        transformer: [],
        threeWindingTransformer: [],
        shuntReactor: [],
        capacitor: [],
        load: [],
        loadDc: [],
        asymmetricLoad: [],
        sourceDc: [],
        switch: [],
        impedance: [],
        ward: [],
        extendedWard: [],
        motor: [],
        storage: [],
        SVC: [],
        TCSC: [],
        SSC: [],
        VSC: [],
        B2BVSC: [],
        dcLine: [],
        line: []
    };

    // Add simulation parameters
    const userEmail = getUserEmail();
    componentArrays.simulationParameters.push({
        ...simulationParameters,
        user_email: userEmail
    });

    // Get all cells
    let cellsArray = model.getDescendants();
    
    // Process cells
    const cellProcessingStart = performance.now();
    const validCells = [];
    const resultCellsToRemove = [];
    const faultMarkersToRemove = [];
    let resultCellsRemoved = 0;
    
    const styleCache = new Map();
    cellsArray.forEach(cell => {
        const cellStyle = cell.getStyle();
        const value = cell.getValue();
        
        // Skip initial placeholders
        if (value && typeof value === 'string' && value.includes('Click Simulate')) {
            return;
        }

        if (cellStyle?.includes('shapeELXXX=FaultMarker')) {
            faultMarkersToRemove.push(cell);
            return;
        }
        
        // Remove previous results if requested
        if (removeResultCells && cellStyle?.includes("Result") &&
            !cellStyle?.includes("ResultExternalGrid") &&
            !cellStyle?.includes("placeholderId=")) {
            resultCellsToRemove.push(cell);
            resultCellsRemoved++;
            return;
        }

        // Cache style parsing
        let style = styleCache.get(cellStyle);
        if (!style) {
            style = parseCellStyle(cellStyle);
            styleCache.set(cellStyle, style);
        }
        
        if (style?.shapeELXXX && style.shapeELXXX !== 'NotEditableLine') {
            validCells.push({ cell, style, componentType: style.shapeELXXX });
        }
    });
    
    const cellsToStrip = [
        ...faultMarkersToRemove,
        ...(removeResultCells ? resultCellsToRemove : [])
    ];
    if (cellsToStrip.length > 0) {
        try {
            model.beginUpdate();
            cellsToStrip.forEach(cell => {
                const cellToRemove = model.getCell(cell.id);
                if (cellToRemove) {
                    model.remove(cellToRemove);
                }
            });
        } finally {
            model.endUpdate();
        }
    }
    
    const cellProcessingTime = performance.now() - cellProcessingStart;

    // Ensure edges are populated for vertex cells (cell.edges can be null until view renders; model.getEdges works regardless)
    validCells.forEach(({ cell, componentType }) => {
        if (!cell.edges && componentType !== 'Line' && componentType !== 'DC Line') {
            const edges = model.getEdges(cell);
            if (edges && edges.length > 0) {
                cell.edges = edges;
            }
        }
    });

    // Process valid cells
    const componentProcessingStart = performance.now();
    let processedComponents = 0;
    
    // Pre-compute common data
    const preComputedData = new Map();
    validCells.forEach(({ cell, componentType }) => {
        const cellStyle = cell.getStyle();
        if(!cellStyle?.includes("ResultExternalGrid")){
            const cellId = cell.id;
            preComputedData.set(cellId, {
                name: cell.mxObjectId.replace('#', '_'),
                id: cellId,
                userFriendlyName: getUserFriendlyName(cell),
                bus: (componentType === 'Line' || componentType === 'DCLine') 
                    ? getConnectedBusId(cell, true) 
                    : getConnectedBusId(cell)
            });
        }
    });
    
    const componentTypeTimings = {};
    
    // Process components
    validCells.forEach(({ cell, style, componentType }, i) => {
        const componentStart = performance.now();
        processedComponents++;
        
        const baseData = preComputedData.get(cell.id);

        switch (componentType) {
            case COMPONENT_TYPES.EXTERNAL_GRID:
                const externalGrid = {
                    ...baseData,
                    typ: `External Grid${counters.externalGrid++}`,
                    ...getCachedAttributes(cell, {                                
                        vm_pu: 'vm_pu',
                        va_degree: 'va_degree',
                        s_sc_max_mva: 's_sc_max_mva',
                        s_sc_min_mva: 's_sc_min_mva',
                        rx_max: 'rx_max',
                        rx_min: 'rx_min',
                        r0x0_max: 'r0x0_max',
                        x0x_max: 'x0x_max',
                        r0x0_min: { name: 'r0x0_min', optional: true },
                        x0x_min: { name: 'x0x_min', optional: true },
                        spectrum: { name: 'spectrum', optional: true },
                        spectrum_csv: { name: 'spectrum_csv', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        max_p_mw: { name: 'max_p_mw', optional: true },
                        min_p_mw: { name: 'min_p_mw', optional: true },
                        max_q_mvar: { name: 'max_q_mvar', optional: true },
                        min_q_mvar: { name: 'min_q_mvar', optional: true },
                        controllable: { name: 'controllable', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                    })
                };
                if (externalGrid.r0x0_min == null || externalGrid.r0x0_min === '') {
                    externalGrid.r0x0_min = externalGrid.r0x0_max;
                }
                if (externalGrid.x0x_min == null || externalGrid.x0x_min === '') {
                    externalGrid.x0x_min = externalGrid.x0x_max;
                }
                componentArrays.externalGrid.push(externalGrid);
                break;

            case COMPONENT_TYPES.GENERATOR:
                const generator = {
                    ...baseData,
                    typ: "Generator",
                    ...getCachedAttributes(cell, {
                        p_mw: 'p_mw',
                        vm_pu: 'vm_pu',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        vn_kv: 'vn_kv',
                        xdss_pu: 'xdss_pu',
                        rdss_ohm: 'rdss_ohm',
                        cos_phi: 'cos_phi',
                        pg_percent: 'pg_percent',
                        power_station_trafo: 'power_station_trafo',
                        ansi_machine_type: { name: 'ansi_machine_type', optional: true },
                        spectrum: { name: 'spectrum', optional: true },
                        spectrum_csv: { name: 'spectrum_csv', optional: true },
                        Xdpp: { name: 'Xdpp', optional: true },
                        XRdp: { name: 'XRdp', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        slack: { name: 'slack', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                        dyn_machine_model: { name: 'dyn_machine_model', optional: true },
                        dyn_M: { name: 'dyn_M', optional: true },
                        dyn_H: { name: 'dyn_H', optional: true },
                        dyn_D: { name: 'dyn_D', optional: true },
                        dyn_ra: { name: 'dyn_ra', optional: true },
                        dyn_xl: { name: 'dyn_xl', optional: true },
                        dyn_xd: { name: 'dyn_xd', optional: true },
                        dyn_xq: { name: 'dyn_xq', optional: true },
                        dyn_xd1: { name: 'dyn_xd1', optional: true },
                        dyn_xq1: { name: 'dyn_xq1', optional: true },
                        dyn_xd2: { name: 'dyn_xd2', optional: true },
                        dyn_xq2: { name: 'dyn_xq2', optional: true },
                        dyn_Td10: { name: 'dyn_Td10', optional: true },
                        dyn_Td20: { name: 'dyn_Td20', optional: true },
                        dyn_Tq10: { name: 'dyn_Tq10', optional: true },
                        dyn_Tq20: { name: 'dyn_Tq20', optional: true },
                        dyn_exciter_model: { name: 'dyn_exciter_model', optional: true },
                        dyn_exc_KA: { name: 'dyn_exc_KA', optional: true },
                        dyn_exc_TR: { name: 'dyn_exc_TR', optional: true },
                        dyn_exc_TA: { name: 'dyn_exc_TA', optional: true },
                        dyn_exc_TE: { name: 'dyn_exc_TE', optional: true },
                        dyn_exc_K: { name: 'dyn_exc_K', optional: true },
                        dyn_governor_model: { name: 'dyn_governor_model', optional: true },
                        dyn_gov_R: { name: 'dyn_gov_R', optional: true },
                        dyn_gov_T1: { name: 'dyn_gov_T1', optional: true },
                        dyn_gov_T2: { name: 'dyn_gov_T2', optional: true },
                        dyn_gov_T3: { name: 'dyn_gov_T3', optional: true },
                        dyn_pss_model: { name: 'dyn_pss_model', optional: true },
                        dyn_pss_A1: { name: 'dyn_pss_A1', optional: true },
                        dyn_pss_A2: { name: 'dyn_pss_A2', optional: true },
                    })
                };
                componentArrays.generator.push(generator);
                counters.generator++;
                break;

            case COMPONENT_TYPES.STATIC_GENERATOR:
                const staticGenerator = {
                    ...baseData,
                    typ: "Static Generator",
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        q_mvar: 'q_mvar',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        type: 'type',
                        k: 'k',
                        rx: 'rx',
                        generator_type: 'generator_type',
                        lrc_pu: 'lrc_pu',
                        max_ik_ka: 'max_ik_ka',
                        kappa: 'kappa',
                        current_source: 'current_source',
                        reactive_capability_curve: 'reactive_capability_curve',
                        curve_style: 'curve_style',
                        q_capability_curve_json: 'q_capability_curve_json',
                        q_setpoint_mode: 'q_setpoint_mode',
                        spectrum: { name: 'spectrum', optional: true },
                        spectrum_csv: { name: 'spectrum_csv', optional: true },
                        Xdpp: { name: 'Xdpp', optional: true },
                        XRdp: { name: 'XRdp', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        controllable: { name: 'controllable', optional: true },
                        min_p_mw: { name: 'min_p_mw', optional: true },
                        max_p_mw: { name: 'max_p_mw', optional: true },
                        min_q_mvar: { name: 'min_q_mvar', optional: true },
                        max_q_mvar: { name: 'max_q_mvar', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                        dyn_plant_kind: { name: 'dyn_plant_kind', optional: true },
                        dyn_Sn: { name: 'dyn_Sn', optional: true },
                        dyn_reg_Tg: { name: 'dyn_reg_Tg', optional: true },
                        dyn_ree_Vref0: { name: 'dyn_ree_Vref0', optional: true },
                        dyn_repca_Kp: { name: 'dyn_repca_Kp', optional: true },
                        dyn_wt_H: { name: 'dyn_wt_H', optional: true },
                        dyn_wt_DAMP: { name: 'dyn_wt_DAMP', optional: true },
                        dyn_dg_Tg: { name: 'dyn_dg_Tg', optional: true },
                    })
                };
                componentArrays.staticGenerator.push(staticGenerator);
                counters.staticGenerator++;
                break;

            case COMPONENT_TYPES.WIND_TURBINE: {
                const windAttrs = getAttributesAsObject(cell, {
                    p_mw: 'p_mw',
                    q_mvar: 'q_mvar',
                    sn_mva: 'sn_mva',
                    scaling: 'scaling',
                    type: 'type',
                    k: 'k',
                    rx: 'rx',
                    generator_type: 'generator_type',
                    lrc_pu: 'lrc_pu',
                    max_ik_ka: 'max_ik_ka',
                    kappa: 'kappa',
                    current_source: 'current_source',
                    ikss_3ph_ka: { name: 'ikss_3ph_ka', optional: true },
                    ikss_2ph_ka: { name: 'ikss_2ph_ka', optional: true },
                    ikss_1ph_ka: { name: 'ikss_1ph_ka', optional: true },
                    sc_ref_vn_kv: { name: 'sc_ref_vn_kv', optional: true },
                    r2_pu: { name: 'r2_pu', optional: true },
                    x2_pu: { name: 'x2_pu', optional: true },
                    reactive_capability_curve: 'reactive_capability_curve',
                    curve_style: 'curve_style',
                    q_capability_curve_json: 'q_capability_curve_json',
                    q_setpoint_mode: 'q_setpoint_mode',
                    q_cap_voltage_dependent: { name: 'q_cap_voltage_dependent', optional: true },
                    q_cap_input_model: { name: 'q_cap_input_model', optional: true },
                    q_cap_scale_min_percent: { name: 'q_cap_scale_min_percent', optional: true },
                    q_cap_scale_max_percent: { name: 'q_cap_scale_max_percent', optional: true },
                    q_cap_u_json: { name: 'q_cap_u_json', optional: true },
                    q_cap_p_json: { name: 'q_cap_p_json', optional: true },
                    q_cap_qmax_json: { name: 'q_cap_qmax_json', optional: true },
                    q_cap_qmin_json: { name: 'q_cap_qmin_json', optional: true },
                    spectrum: { name: 'spectrum', optional: true },
                    spectrum_csv: { name: 'spectrum_csv', optional: true },
                    Xdpp: { name: 'Xdpp', optional: true },
                    XRdp: { name: 'XRdp', optional: true },
                    wind_speed_ms: { name: 'wind_speed_ms', optional: true },
                    wind_power_curve_json: { name: 'wind_power_curve_json', optional: true },
                    wind_curve_approx: { name: 'wind_curve_approx', optional: true },
                    in_service: { name: 'in_service', optional: true },
                    cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                    controllable: { name: 'controllable', optional: true },
                    min_p_mw: { name: 'min_p_mw', optional: true },
                    max_p_mw: { name: 'max_p_mw', optional: true },
                    min_q_mvar: { name: 'min_q_mvar', optional: true },
                    max_q_mvar: { name: 'max_q_mvar', optional: true },
                    opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                    opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                    opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                    dyn_plant_kind: { name: 'dyn_plant_kind', optional: true },
                    dyn_Sn: { name: 'dyn_Sn', optional: true },
                    dyn_reg_Tg: { name: 'dyn_reg_Tg', optional: true },
                    dyn_ree_Vref0: { name: 'dyn_ree_Vref0', optional: true },
                    dyn_repca_Kp: { name: 'dyn_repca_Kp', optional: true },
                    dyn_wt_H: { name: 'dyn_wt_H', optional: true },
                    dyn_wt_DAMP: { name: 'dyn_wt_DAMP', optional: true },
                    dyn_dg_Tg: { name: 'dyn_dg_Tg', optional: true },
                });
                // Same defaults the Wind Turbine dialog shows when these attributes
                // were never written (Components Data displays them too). Without this,
                // Ik" is ignored until the element dialog Apply stores them.
                for (const [scKey, scFallback] of Object.entries(WIND_SC_DEFAULTS)) {
                    const raw = windAttrs[scKey];
                    if (raw == null || String(raw).trim() === '') {
                        windAttrs[scKey] = scFallback;
                    }
                }
                if (windAttrs.generator_type == null || String(windAttrs.generator_type).trim() === '') {
                    windAttrs.generator_type = 'current_source';
                }
                windAttrs.p_mw = computeWindTurbinePMw(
                    windAttrs.wind_speed_ms,
                    windAttrs.wind_power_curve_json,
                    windAttrs.wind_curve_approx || 'linear'
                );
                const windTurbine = {
                    ...baseData,
                    typ: "Wind Turbine",
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...windAttrs
                };
                componentArrays.staticGenerator.push(windTurbine);
                counters.staticGenerator++;
                break;
            }

            case COMPONENT_TYPES.ASYMMETRIC_STATIC_GENERATOR:
                const asymmetricGenerator = {
                    ...baseData,
                    typ: `Asymmetric Static Generator${counters.asymmetricGenerator++}`,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...getAttributesAsObject(cell, {
                        p_a_mw: 'p_a_mw',
                        p_b_mw: 'p_b_mw',
                        p_c_mw: 'p_c_mw',
                        q_a_mvar: 'q_a_mvar',
                        q_b_mvar: 'q_b_mvar',
                        q_c_mvar: 'q_c_mvar',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        type: 'type',
                        in_service: { name: 'in_service', optional: true }
                    })
                };
                componentArrays.asymmetricGenerator.push(asymmetricGenerator);
                break;

            case COMPONENT_TYPES.BUS:
                const busbar = {
                    typ: `Bus${counters.busbar++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    vn_kv: cell.value.attributes[2].nodeValue,
                    userFriendlyName: baseData.userFriendlyName,
                    ...getAttributesAsObject(cell, {
                        min_vm_pu: { name: 'min_vm_pu', optional: true },
                        max_vm_pu: { name: 'max_vm_pu', optional: true },
                    }),
                };
                componentArrays.busbar.push(busbar);
                break;

            case COMPONENT_TYPES.TRANSFORMER:
                const { hv_bus, lv_bus } = getTransformerConnections(cell);
                const transformer = {
                    typ: `Transformer${counters.transformer++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    hv_bus,
                    lv_bus,
                    ...getAttributesAsObject(cell, {
                        sn_mva: 'sn_mva',
                        vn_hv_kv: 'vn_hv_kv',
                        vn_lv_kv: 'vn_lv_kv',
                        vkr_percent: 'vkr_percent',
                        vk_percent: 'vk_percent',
                        pfe_kw: 'pfe_kw',
                        i0_percent: 'i0_percent',
                        vector_group: { name: 'vector_group', optional: true },
                        vk0_percent: { name: 'vk0_percent', optional: true },
                        vkr0_percent: { name: 'vkr0_percent', optional: true },
                        mag0_percent: { name: 'mag0_percent', optional: true },
                        si0_hv_partial: { name: 'si0_hv_partial', optional: true },
                        rn_ohm: { name: 'rn_ohm', optional: true },
                        xn_ohm: { name: 'xn_ohm', optional: true },
                        parallel: { name: 'parallel', optional: true },
                        shift_degree: { name: 'shift_degree', optional: true },
                        tap_side: { name: 'tap_side', optional: true },
                        tap_pos: { name: 'tap_pos', optional: true },
                        tap_neutral: { name: 'tap_neutral', optional: true },
                        tap_max: { name: 'tap_max', optional: true },
                        tap_min: { name: 'tap_min', optional: true },
                        tap_step_percent: { name: 'tap_step_percent', optional: true },
                        tap_step_degree: { name: 'tap_step_degree', optional: true },
                        tap_phase_shifter: { name: 'tap_phase_shifter', optional: true },
                        tap_changer_type: { name: 'tap_changer_type', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        discrete_tap_control: { name: 'discrete_tap_control', optional: true },
                        control_side: { name: 'control_side', optional: true },
                        vm_lower_pu: { name: 'vm_lower_pu', optional: true },
                        vm_upper_pu: { name: 'vm_upper_pu', optional: true },
                        max_loading_percent: { name: 'max_loading_percent', optional: true },
                    })
                };
                componentArrays.transformer.push(transformer);
                break;

            case COMPONENT_TYPES.THREE_WINDING_TRANSFORMER:
                const connections = getThreeWindingConnections(cell);
                const threeWindingTransformer = {
                    typ: `Three Winding Transformer${counters.threeWindingTransformer++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...connections,
                    ...getAttributesAsObject(cell, {
                        sn_hv_mva: 'sn_hv_mva',
                        sn_mv_mva: 'sn_mv_mva',
                        sn_lv_mva: 'sn_lv_mva',
                        vn_hv_kv: 'vn_hv_kv',
                        vn_mv_kv: 'vn_mv_kv',
                        vn_lv_kv: 'vn_lv_kv',
                        vk_hv_percent: 'vk_hv_percent',
                        vk_mv_percent: 'vk_mv_percent',
                        vk_lv_percent: 'vk_lv_percent',
                        vkr_hv_percent: 'vkr_hv_percent',
                        vkr_mv_percent: 'vkr_mv_percent',
                        vkr_lv_percent: 'vkr_lv_percent',
                        pfe_kw: 'pfe_kw',
                        i0_percent: 'i0_percent',
                        vk0_hv_percent: 'vk0_hv_percent',
                        vk0_mv_percent: 'vk0_mv_percent',
                        vk0_lv_percent: 'vk0_lv_percent',
                        vkr0_hv_percent: 'vkr0_hv_percent',
                        vkr0_mv_percent: 'vkr0_mv_percent',
                        vkr0_lv_percent: 'vkr0_lv_percent',
                        vector_group: 'vector_group',
                        shift_mv_degree: { name: 'shift_mv_degree', optional: true },
                        shift_lv_degree: { name: 'shift_lv_degree', optional: true },
                        tap_step_percent: { name: 'tap_step_percent', optional: true },
                        tap_step_degree: { name: 'tap_step_degree', optional: true },
                        tap_side: { name: 'tap_side', optional: true },
                        tap_neutral: { name: 'tap_neutral', optional: true },
                        tap_min: { name: 'tap_min', optional: true },
                        tap_max: { name: 'tap_max', optional: true },
                        tap_pos: { name: 'tap_pos', optional: true },
                        tap_at_star_point: { name: 'tap_at_star_point', optional: true },
                        tap_changer_type: { name: 'tap_changer_type', optional: true },
                        tap_phase_shifter: { name: 'tap_phase_shifter', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        discrete_tap_control: { name: 'discrete_tap_control', optional: true },
                        control_side: { name: 'control_side', optional: true },
                        vm_lower_pu: { name: 'vm_lower_pu', optional: true },
                        vm_upper_pu: { name: 'vm_upper_pu', optional: true }
                    })
                };
                componentArrays.threeWindingTransformer.push(threeWindingTransformer);
                break;

            case COMPONENT_TYPES.SHUNT_REACTOR:
                const shuntReactor = {
                    typ: `Shunt Reactor${counters.shuntReactor++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        q_mvar: 'q_mvar',
                        vn_kv: 'vn_kv',
                        step: { name: 'step', optional: true },
                        max_step: { name: 'max_step', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        step_dependency_table: { name: 'step_dependency_table', optional: true },
                        shunt_characteristic_table_json: { name: 'shunt_characteristic_table_json', optional: true },
                        discrete_shunt_control: { name: 'discrete_shunt_control', optional: true },
                        vm_set_pu: { name: 'vm_set_pu', optional: true },
                        shunt_control_increment: { name: 'shunt_control_increment', optional: true },
                        shunt_control_tol: { name: 'shunt_control_tol', optional: true },
                        shunt_reset_at_init: { name: 'shunt_reset_at_init', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        line_flow_step_control: { name: 'line_flow_step_control', optional: true },
                        line_flow_reference_line_id: { name: 'line_flow_reference_line_id', optional: true },
                        line_flow_step_table_json: { name: 'line_flow_step_table_json', optional: true },
                        line_flow_p_use_abs: { name: 'line_flow_p_use_abs', optional: true },
                        line_flow_p_reference: { name: 'line_flow_p_reference', optional: true }
                    })
                };
                componentArrays.shuntReactor.push(shuntReactor);
                break;

            case COMPONENT_TYPES.CAPACITOR:
                const capacitor = {
                    typ: `Capacitor${counters.capacitor++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        q_mvar: 'q_mvar',
                        loss_factor: 'loss_factor',
                        vn_kv: 'vn_kv',
                        step: { name: 'step', optional: true },
                        max_step: { name: 'max_step', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.capacitor.push(capacitor);
                break;

            case COMPONENT_TYPES.LOAD:
                const load = {
                    typ: `Load${counters.load++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        q_mvar: 'q_mvar',
                        const_z_percent: 'const_z_percent',
                        const_i_percent: 'const_i_percent',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        type: 'type',
                        spectrum: { name: 'spectrum', optional: true },
                        spectrum_csv: { name: 'spectrum_csv', optional: true },
                        pctSeriesRL: { name: 'pctSeriesRL', optional: true },
                        conn: { name: 'conn', optional: true },
                        puXharm: { name: 'puXharm', optional: true },
                        XRharm: { name: 'XRharm', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        controllable: { name: 'controllable', optional: true },
                        min_p_mw: { name: 'min_p_mw', optional: true },
                        max_p_mw: { name: 'max_p_mw', optional: true },
                        min_q_mvar: { name: 'min_q_mvar', optional: true },
                        max_q_mvar: { name: 'max_q_mvar', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                        dc_computational_enabled: { name: 'dc_computational_enabled', optional: true },
                        dc_it_share_percent: { name: 'dc_it_share_percent', optional: true },
                        dc_ups_hold_s: { name: 'dc_ups_hold_s', optional: true },
                        dc_ride_through_csv: { name: 'dc_ride_through_csv', optional: true },
                    })
                };
                componentArrays.load.push(load);
                break;

            case COMPONENT_TYPES.ASYMMETRIC_LOAD:
                const asymmetricLoad = {
                    typ: `Asymmetric Load${counters.asymmetricLoad++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_a_mw: 'p_a_mw',
                        p_b_mw: 'p_b_mw',
                        p_c_mw: 'p_c_mw',
                        q_a_mvar: 'q_a_mvar',
                        q_b_mvar: 'q_b_mvar',
                        q_c_mvar: 'q_c_mvar',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        type: 'type',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.asymmetricLoad.push(asymmetricLoad);
                break;

            case COMPONENT_TYPES.IMPEDANCE:
                try {
                    const impedance = {
                        typ: `Impedance${counters.impedance++}`,
                        name: cell.mxObjectId.replace('#', '_'),
                        id: cell.id,
                        userFriendlyName: (() => {
                            if (cell.value && cell.value.attributes) {
                                for (let i = 0; i < cell.value.attributes.length; i++) {
                                    if (cell.value.attributes[i].nodeName === 'name') {
                                        return cell.value.attributes[i].nodeValue;
                                    }
                                }
                            }
                            return cell.mxObjectId.replace('#', '_');
                        })(),
                        ...getImpedanceConnections(cell),
                        ...getAttributesAsObject(cell, {
                            rft_pu: 'r_pu',   // cell stores r_pu, export as rft_pu
                            xft_pu: 'x_pu',   // cell stores x_pu, export as xft_pu
                            sn_mva: 'sn_mva',
                            in_service: { name: 'in_service', optional: true },
                            cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                        })
                    };
                    componentArrays.impedance.push(impedance);
                } catch (error) {
                    console.error('Error processing impedance:', error);
                }
                break;

            case COMPONENT_TYPES.WARD:
                const ward = {
                    typ: `Ward${counters.ward++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        ps_mw: 'ps_mw',
                        qs_mvar: 'qs_mvar',
                        pz_mw: 'pz_mw',
                        qz_mvar: 'qz_mvar',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.ward.push(ward);
                break;

            case COMPONENT_TYPES.EXTENDED_WARD:
                const extendedWard = {
                    typ: `Extended Ward${counters.extendedWard++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        ps_mw: 'ps_mw',
                        qs_mvar: 'qs_mvar',
                        pz_mw: 'pz_mw',
                        qz_mvar: 'qz_mvar',
                        r_ohm: 'r_ohm',
                        x_ohm: 'x_ohm',
                        vm_pu: 'vm_pu',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.extendedWard.push(extendedWard);
                break;

            case COMPONENT_TYPES.MOTOR:
                const motor = {
                    typ: `Motor${counters.motor++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        pn_mech_mw: 'pn_mech_mw',
                        cos_phi: 'cos_phi',
                        efficiency_percent: 'efficiency_percent',
                        loading_percent: 'loading_percent',
                        scaling: 'scaling',
                        cos_phi_n: 'cos_phi_n',
                        efficiency_n_percent: 'efficiency_n_percent',
                        lrc_pu: 'lrc_pu',
                        rx: 'rx',
                        vn_kv: 'vn_kv',
                        Hm: { name: 'Hm', optional: true },
                        tm_c1: { name: 'tm_c1', optional: true },
                        tm_c2: { name: 'tm_c2', optional: true },
                        tm_c3: { name: 'tm_c3', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.motor.push(motor);
                break;

            case COMPONENT_TYPES.STORAGE:
                const storage = {
                    typ: `Storage${counters.storage++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        // pandapower core
                        p_mw: 'p_mw',
                        q_mvar: 'q_mvar',
                        max_e_mwh: 'max_e_mwh',
                        min_e_mwh: 'min_e_mwh',
                        soc_percent: 'soc_percent',
                        sn_mva: 'sn_mva',
                        scaling: 'scaling',
                        type: 'type',
                        in_service: { name: 'in_service', optional: true },
                        // pandapower OPF
                        controllable: { name: 'controllable', optional: true },
                        max_p_mw: { name: 'max_p_mw', optional: true },
                        min_p_mw: { name: 'min_p_mw', optional: true },
                        max_q_mvar: { name: 'max_q_mvar', optional: true },
                        min_q_mvar: { name: 'min_q_mvar', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                        // OpenDSS connection
                        conn: { name: 'conn', optional: true },
                        phases: { name: 'phases', optional: true },
                        // OpenDSS harmonic analysis
                        spectrum: { name: 'spectrum', optional: true },
                        // OpenDSS dispatch & efficiency
                        state: { name: 'state', optional: true },
                        disp_mode: { name: 'disp_mode', optional: true },
                        pct_charge: { name: 'pct_charge', optional: true },
                        pct_discharge: { name: 'pct_discharge', optional: true },
                        pct_eff_charge: { name: 'pct_eff_charge', optional: true },
                        pct_eff_discharge: { name: 'pct_eff_discharge', optional: true },
                        pct_idling_kw: { name: 'pct_idling_kw', optional: true },
                        pct_idling_kvar: { name: 'pct_idling_kvar', optional: true },
                        discharge_trigger: { name: 'discharge_trigger', optional: true },
                        charge_trigger: { name: 'charge_trigger', optional: true },
                        time_charge_trig: { name: 'time_charge_trig', optional: true },
                        inv_control_mode: { name: 'inv_control_mode', optional: true },
                        pf: { name: 'pf', optional: true },
                        pf_q_mode: { name: 'pf_q_mode', optional: true },
                        pf_charge: { name: 'pf_charge', optional: true },
                        pf_charge_q_mode: { name: 'pf_charge_q_mode', optional: true },
                        watt_priority: { name: 'watt_priority', optional: true },
                        reactive_capability_curve: { name: 'reactive_capability_curve', optional: true },
                        q_cap_voltage_dependent: { name: 'q_cap_voltage_dependent', optional: true },
                        curve_style: { name: 'curve_style', optional: true },
                        q_capability_curve_json: { name: 'q_capability_curve_json', optional: true },
                        q_capability_preset: { name: 'q_capability_preset', optional: true },
                        battery_dc_pmax_mw: { name: 'battery_dc_pmax_mw', optional: true },
                        q_setpoint_mode: { name: 'q_setpoint_mode', optional: true },
                        vv_curve_preset: { name: 'vv_curve_preset', optional: true },
                        vv_xarray: { name: 'vv_xarray', optional: true },
                        vv_yarray: { name: 'vv_yarray', optional: true },
                        vw_curve_preset: { name: 'vw_curve_preset', optional: true },
                        vw_xarray: { name: 'vw_xarray', optional: true },
                        vw_yarray: { name: 'vw_yarray', optional: true },
                        wattpf_xarray: { name: 'wattpf_xarray', optional: true },
                        wattpf_yarray: { name: 'wattpf_yarray', optional: true },
                        wattvar_xarray: { name: 'wattvar_xarray', optional: true },
                        wattvar_yarray: { name: 'wattvar_yarray', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        max_ik_ka: { name: 'max_ik_ka', optional: true },
                        rx: { name: 'rx', optional: true },
                        current_source: { name: 'current_source', optional: true }
                    })
                };
                const storInv = String(storage.inv_control_mode || 'NONE').toUpperCase();
                if (storInv === 'FIXED_PF') {
                    storage.q_mvar = resolveStorageFixedPf(storage.p_mw, storage).q_mvar;
                } else {
                    const qCap = resolveStorageQSetpoint(storage.p_mw, storage);
                    if (qCap.fromCurve) {
                        storage.q_mvar = qCap.qEffective;
                    }
                }
                componentArrays.storage.push(storage);
                break;

            case COMPONENT_TYPES.SVC:
                const SVC = {
                    typ: `SVC${counters.SVC++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        x_l_ohm: 'x_l_ohm',
                        x_cvar_ohm: 'x_cvar_ohm',
                        set_vm_pu: 'set_vm_pu',
                        thyristor_firing_angle_degree: 'thyristor_firing_angle_degree',
                        controllable: 'controllable',
                        min_angle_degree: 'min_angle_degree',
                        max_angle_degree: 'max_angle_degree',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.SVC.push(SVC);
                break;

            case COMPONENT_TYPES.TCSC:
                const TCSC = {
                    typ: `TCSC${counters.TCSC++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        x_l_ohm: 'x_l_ohm',
                        x_cvar_ohm: 'x_cvar_ohm',
                        set_p_to_mw: 'set_p_to_mw',
                        thyristor_firing_angle_degree: 'thyristor_firing_angle_degree',
                        controllable: 'controllable',
                        min_angle_degree: 'min_angle_degree',
                        max_angle_degree: 'max_angle_degree',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.TCSC.push(TCSC);
                break;

            case COMPONENT_TYPES.SSC:
                const SSC = {
                    typ: `SSC${counters.SSC++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        r_ohm: 'r_ohm',
                        x_ohm: 'x_ohm',
                        set_vm_pu: 'set_vm_pu',
                        vm_internal_pu: 'vm_internal_pu',
                        va_internal_degree: 'va_internal_degree',
                        controllable: 'controllable',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.SSC.push(SSC);
                break;

            case COMPONENT_TYPES.DC_BUS:
                const dcBus = {
                    typ: `DC Bus${counters.dcBus++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    vn_kv: cell.value.attributes[2]?.nodeValue || "0",
                    userFriendlyName: baseData.userFriendlyName,
                    ...getAttributesAsObject(cell, {
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.dcBus.push(dcBus);
                break;

            case COMPONENT_TYPES.LOAD_DC:
                const loadDc = {
                    typ: `Load DC${counters.loadDc++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.loadDc.push(loadDc);
                break;

            case COMPONENT_TYPES.SOURCE_DC:
                const sourceDc = {
                    typ: `Source DC${counters.sourceDc++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        vm_pu: 'vm_pu',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.sourceDc.push(sourceDc);
                break;

            case COMPONENT_TYPES.SWITCH:
                if (!cell.edges || cell.edges.length < 2) {
                    const swE = model.getEdges(cell);
                    if (swE && swE.length) cell.edges = swE;
                }
                const switchConnections = getSwitchConnections(cell, model);
                const switchAttrs = getAttributesAsObject(cell, {
                    name: { name: 'name', optional: true },
                    et: { name: 'et', optional: true },
                    type: 'type',
                    closed: 'closed',
                    z_ohm: 'z_ohm',
                    in_ka: { name: 'in_ka', optional: true },
                    ikss_ka: { name: 'ikss_ka', optional: true },
                    ansi_device_class: { name: 'ansi_device_class', optional: true },
                    interrupting_rating_ka: { name: 'interrupting_rating_ka', optional: true },
                    momentary_rating_ka: { name: 'momentary_rating_ka', optional: true },
                    rated_voltage_kv: { name: 'rated_voltage_kv', optional: true },
                    contact_parting_cycles: { name: 'contact_parting_cycles', optional: true },
                    generator_cb: { name: 'generator_cb', optional: true }
                });
                const switchElement = {
                    typ: `Switch${counters.switch++}`,
                    id: cell.id,
                    userFriendlyName: switchAttrs.name || cell.mxObjectId.replace('#', '_'),
                    ...switchAttrs,
                    name: switchAttrs.name || cell.mxObjectId.replace('#', '_'),
                    bus: switchConnections.bus,
                    element: switchConnections.element,
                    et:
                        switchConnections.et === GEN_STUB_SWITCH_ET
                            ? GEN_STUB_SWITCH_ET
                            : switchConnections.et,
                    ...(switchConnections.elementCellId != null
                        ? { elementCellId: switchConnections.elementCellId }
                        : {}),
                };
                componentArrays.switch.push(switchElement);
                break;

            case COMPONENT_TYPES.VSC:
                const vsc = {
                    typ: `VSC${counters.VSC++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        vm_pu: 'vm_pu',
                        sn_mva: 'sn_mva',
                        rx: 'rx',
                        max_ik_ka: 'max_ik_ka',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.VSC.push(vsc);
                break;

            case COMPONENT_TYPES.B2B_VSC:
                const b2bVsc = {
                    typ: `B2B VSC${counters.B2BVSC++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...getAttributesAsObject(cell, {
                        bus1: 'bus1',
                        bus2: 'bus2',
                        p_mw: 'p_mw',
                        vm1_pu: 'vm1_pu',
                        vm2_pu: 'vm2_pu',
                        sn_mva: 'sn_mva',
                        rx: 'rx',
                        max_ik_ka: 'max_ik_ka',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true }
                    })
                };
                componentArrays.B2BVSC.push(b2bVsc);
                break;

            case COMPONENT_TYPES.DC_LINE:
                const dcLine = {
                    typ: `DC Line${counters.dcLine++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    bus: getConnectedBusId(cell),
                    ...getAttributesAsObject(cell, {
                        p_mw: 'p_mw',
                        loss_percent: 'loss_percent',
                        loss_mw: 'loss_mw',
                        vm_from_pu: 'vm_from_pu',
                        vm_to_pu: 'vm_to_pu',
                        in_service: { name: 'in_service', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        max_p_mw: { name: 'max_p_mw', optional: true },
                        min_q_from_mvar: { name: 'min_q_from_mvar', optional: true },
                        max_q_from_mvar: { name: 'max_q_from_mvar', optional: true },
                        min_q_to_mvar: { name: 'min_q_to_mvar', optional: true },
                        max_q_to_mvar: { name: 'max_q_to_mvar', optional: true },
                        opf_marginal_cost_eur_per_mwh: { name: 'opf_marginal_cost_eur_per_mwh', optional: true },
                        opf_cp2_eur_per_mw2: { name: 'opf_cp2_eur_per_mw2', optional: true },
                        opf_cost_currency: { name: 'opf_cost_currency', optional: true },
                    })
                };
                componentArrays.dcLine.push(dcLine);
                break;

            case COMPONENT_TYPES.LINE:
                if (!cell.edges || cell.edges.length === 0) {
                    const le = model.getEdges(cell);
                    if (le && le.length) cell.edges = le;
                }
                const lineEndpointBuses = getLineBusEndpointsForPayload(cell, model);
                const line = {
                    typ: `Line${counters.line++}`,
                    name: cell.mxObjectId.replace('#', '_'),
                    id: cell.id,
                    userFriendlyName: (() => {
                        if (cell.value && cell.value.attributes) {
                            for (let i = 0; i < cell.value.attributes.length; i++) {
                                if (cell.value.attributes[i].nodeName === 'name') {
                                    return cell.value.attributes[i].nodeValue;
                                }
                            }
                        }
                        return cell.mxObjectId.replace('#', '_');
                    })(),
                    ...lineEndpointBuses,
                    ...getAttributesAsObject(cell, {
                        length_km: 'length_km',
                        parallel: { name: 'parallel', optional: true },
                        df: { name: 'df', optional: true },
                        in_service: { name: 'in_service', optional: true },
                        r_ohm_per_km: 'r_ohm_per_km',
                        x_ohm_per_km: 'x_ohm_per_km',
                        c_nf_per_km: 'c_nf_per_km',
                        g_us_per_km: 'g_us_per_km',
                        max_i_ka: 'max_i_ka',
                        type: 'type',
                        r0_ohm_per_km: { name: 'r0_ohm_per_km', optional: true },
                        x0_ohm_per_km: { name: 'x0_ohm_per_km', optional: true },
                        c0_nf_per_km: { name: 'c0_nf_per_km', optional: true },
                        endtemp_degree: { name: 'endtemp_degree', optional: true },
                        cost_per_unit_by_currency: { name: 'cost_per_unit_by_currency', optional: true },
                        max_loading_percent: { name: 'max_loading_percent', optional: true },
                    })
                };

                try {
                    validateLineBusTopology(cell, model);
                    if (!lineEndpointBuses.busFrom || !lineEndpointBuses.busTo) {
                        throw new Error('Could not resolve line endpoints to electrical buses.');
                    }
                } catch (error) {
                    console.error(error.message);
                }

                componentArrays.line.push(line);
                break;
        }
        
        const componentTime = performance.now() - componentStart;
        if (!componentTypeTimings[componentType]) {
            componentTypeTimings[componentType] = { time: 0, count: 0 };
        }
        componentTypeTimings[componentType].time += componentTime;
        componentTypeTimings[componentType].count++;
    });

    // Update transformer connections
    if (componentArrays.transformer.length > 0) {
        componentArrays.transformer = updateTransformerBusConnections(componentArrays.transformer, componentArrays.busbar, graph);
    }
    if (componentArrays.threeWindingTransformer.length > 0) {
        componentArrays.threeWindingTransformer = updateThreeWindingTransformerConnections(componentArrays.threeWindingTransformer, componentArrays.busbar, graph);
    }

    reconcileLineSwitchEnds(componentArrays.line, componentArrays.switch);
    expandGenStubSwitches(componentArrays, counters);

    // Build final array
    const array = [];
    let arrayIndex = 0;
    
    const addComponents = (components) => {
        for (let i = 0; i < components.length; i++) {
            array[arrayIndex++] = components[i];
        }
    };
    
    addComponents(componentArrays.simulationParameters);
    // Apply Wind Turbine Controller Pref (P from curve) onto linked Wind Turbine payloads
    try {
        const wtc = collectWindTurbineControllers(graph);
        applyWindTurbineControllerPrefs(componentArrays.staticGenerator, wtc);
    } catch (e) {
        console.warn('Wind Turbine Controller apply skipped:', e);
    }
    try {
        addComponents(collectWindTurbineControllersForPayload(graph));
    } catch (e) {
        console.warn('Wind Turbine Controller payload collect skipped:', e);
    }
    try {
        const parks = collectParkControllers(graph);
        addComponents(parks);
    } catch (e) {
        console.warn('Park Controller collect skipped:', e);
    }
    addComponents(componentArrays.externalGrid);
    addComponents(componentArrays.generator);
    addComponents(componentArrays.staticGenerator);
    addComponents(componentArrays.asymmetricGenerator);
    addComponents(componentArrays.busbar);
    addComponents(componentArrays.transformer);
    addComponents(componentArrays.threeWindingTransformer);
    addComponents(componentArrays.shuntReactor);
    addComponents(componentArrays.capacitor);
    addComponents(componentArrays.load);
    addComponents(componentArrays.asymmetricLoad);
    addComponents(componentArrays.impedance);
    addComponents(componentArrays.ward);
    addComponents(componentArrays.extendedWard);
    addComponents(componentArrays.motor);
    addComponents(componentArrays.storage);
    addComponents(componentArrays.SSC);
    addComponents(componentArrays.SVC);
    addComponents(componentArrays.TCSC);
    addComponents(componentArrays.VSC);
    addComponents(componentArrays.B2BVSC);
    addComponents(componentArrays.dcBus);
    addComponents(componentArrays.loadDc);
    addComponents(componentArrays.sourceDc);
    addComponents(componentArrays.dcLine);
    addComponents(componentArrays.line);
    addComponents(componentArrays.switch);

    // Create final object
    const obj = Object.assign({}, array);
    
    const dataProcessingTime = performance.now() - startTime;
    console.log(`Network data preparation completed in ${dataProcessingTime.toFixed(2)}ms`);
    console.log(`Processed ${processedComponents} components`);
    
    // Clean up caches
    cellCache.clear();
    nameCache.clear();
    attributeCache.clear();
    
    _networkDataCache.set(graph, { key: cacheKey, result: obj });
    return obj;
}
