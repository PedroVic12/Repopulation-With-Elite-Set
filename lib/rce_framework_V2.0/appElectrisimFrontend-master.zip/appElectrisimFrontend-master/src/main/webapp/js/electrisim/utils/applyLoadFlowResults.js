/**
 * Apply pandapower load-flow JSON to diagram result boxes (shared by RPC PQ point clicks).
 */
import { buildGraphCellLookupMap, resolveGraphCellForResult, formatResultNameHeader } from './attributeUtils.js';

const COLOR_STATES = { DANGER: 'red', WARNING: 'orange', GOOD: 'green' };
const LARGE_LOAD_FLOW_BUS_COUNT = 200;
const SELECTION_PANEL_ID = 'electrisim-lf-selection-panel';

function formatNumber(num, decimals = 3) {
    if (num == null || num === '' || num === 'NaN' || (typeof num === 'number' && Number.isNaN(num))) {
        return 'N/A';
    }
    return parseFloat(num).toFixed(decimals);
}

function replaceUnderscores(name) {
    return String(name || '').replace('_', '#');
}

function vnKvFromGraphCell(graphCell) {
    if (!graphCell?.value?.getAttribute) return NaN;
    return Number(graphCell.value.getAttribute('vn_kv'));
}

function formatBusVmKvForCell(dataCell, graphCell, decimals = 3) {
    const kv = Number(dataCell?.vm_kv);
    if (Number.isFinite(kv)) return kv.toFixed(decimals);
    const pu = Number(dataCell?.vm_pu);
    const vn = vnKvFromGraphCell(graphCell);
    if (Number.isFinite(pu) && Number.isFinite(vn) && vn > 0) return (pu * vn).toFixed(decimals);
    return 'N/A';
}

function updateCellColor(grafka, cell, color) {
    if (!cell || !grafka?.getModel) return;
    const style = grafka.getModel().getStyle(cell) || '';
    let newStyle;
    if (typeof mxUtils !== 'undefined' && typeof mxConstants !== 'undefined') {
        newStyle = mxUtils.setStyle(style, mxConstants.STYLE_STROKECOLOR, color);
    } else {
        newStyle = `${style};strokeColor=${color}`;
    }
    grafka.setCellStyle(newStyle, [cell]);
}

function processVoltageColor(grafka, cell, vmPu) {
    const n = Number(vmPu);
    if (!Number.isFinite(n)) return;
    const voltage = parseFloat(n.toFixed(2));
    let color = null;
    if (voltage >= 1.1 || voltage <= 0.9) color = COLOR_STATES.DANGER;
    else if ((voltage > 1.05 && voltage <= 1.1) || (voltage > 0.9 && voltage <= 0.95)) color = COLOR_STATES.WARNING;
    else if ((voltage > 1 && voltage <= 1.05) || (voltage > 0.95 && voltage <= 1)) color = COLOR_STATES.GOOD;
    if (color) updateCellColor(grafka, cell, color);
}

function processLoadingColor(grafka, cell, loadingPercent) {
    const n = Number(loadingPercent);
    if (!Number.isFinite(n)) return;
    const loading = parseFloat(n.toFixed(1));
    let color = null;
    if (loading > 100) color = COLOR_STATES.DANGER;
    else if (loading > 80) color = COLOR_STATES.WARNING;
    else if (loading > 0) color = COLOR_STATES.GOOD;
    if (color) updateCellColor(grafka, cell, color);
}

function findPlaceholder(graph, parentCell) {
    const fn = typeof window !== 'undefined' && window.findResultPlaceholder;
    return fn ? fn(graph, parentCell) : null;
}

function findPlaceholderForComponent(graph, componentCell) {
    const fn = typeof window !== 'undefined' && window.findResultPlaceholderForComponent;
    return fn ? fn(graph, componentCell) : findPlaceholder(graph, componentCell);
}

function insertBox(graph, parentCell, text, opts) {
    const fn = typeof window !== 'undefined' && window.insertResultBox;
    if (fn) return fn(graph, parentCell, text, opts);
    return null;
}

function busDisplayPq(cell) {
    if (typeof window !== 'undefined' && window.busDisplayPq) {
        return window.busDisplayPq(cell);
    }
    return { p: cell.p_mw, q: cell.q_mvar, pf: cell.pf, qp: cell.q_p };
}

function mergeTapControlIntoTransformers(dataJson) {
    const rows = dataJson.tap_control_results;
    if (!Array.isArray(rows) || rows.length === 0) return;
    const byCellId = new Map();
    const byInternalName = new Map();
    for (const row of rows) {
        if (row?.cell_id) byCellId.set(String(row.cell_id), row);
        if (row?.id != null) byInternalName.set(String(row.id), row);
    }
    const attach = (tr, requireTrafo3w) => {
        let m = tr.id != null ? byCellId.get(String(tr.id)) : null;
        if (!m && tr.name != null) m = byInternalName.get(String(tr.name));
        if (!m) return;
        const is3w = m.element === 'trafo3w';
        if (requireTrafo3w && !is3w) return;
        if (!requireTrafo3w && is3w) return;
        tr.tap_control_result = m;
    };
    (dataJson.transformers || []).forEach((tr) => attach(tr, false));
    (dataJson.transformers3W || []).forEach((tr) => attach(tr, true));
}

function mergeShuntControlIntoShunts(dataJson) {
    const rows = dataJson.shunt_control_results;
    if (!Array.isArray(rows) || rows.length === 0 || !dataJson.shunts?.length) return;
    const byCellId = new Map();
    const byInternalName = new Map();
    for (const row of rows) {
        if (row?.element !== 'shunt') continue;
        if (row.cell_id) byCellId.set(String(row.cell_id), row);
        if (row.id != null) byInternalName.set(String(row.id), row);
        if (row.name != null) byInternalName.set(String(row.name), row);
    }
    for (const s of dataJson.shunts) {
        let m = s.id != null ? byCellId.get(String(s.id)) : null;
        if (!m && s.name != null) m = byInternalName.get(String(s.name));
        if (m) s.shunt_control_result = m;
    }
}

function formatTapControlOnTrafo(cell) {
    const tc = cell.tap_control_result;
    if (!tc) return '';
    const range = `[${formatNumber(tc.tap_min, 0)}…${formatNumber(tc.tap_max, 0)}]`;
    let line;
    if (tc.tap_pos_initial != null && Number(tc.tap_pos_initial) !== Number(tc.tap_pos)) {
        line = `\n            tap_pos: ${formatNumber(tc.tap_pos_initial, 0)} → ${formatNumber(tc.tap_pos, 0)} ${range}`;
    } else {
        line = `\n            tap_pos: ${formatNumber(tc.tap_pos, 0)} ${range}`;
    }
    if (tc.controlled_vm_pu != null && tc.vm_lower_pu != null && tc.vm_upper_pu != null) {
        const side = tc.control_side || 'ctrl';
        line += `\n            U_${side}[pu]: ${formatNumber(tc.controlled_vm_pu, 3)} [${formatNumber(tc.vm_lower_pu, 3)}…${formatNumber(tc.vm_upper_pu, 3)}]`;
        if (tc.in_limits === false) {
            line += tc.at_limit ? ' NOT held (tap at limit)' : ' NOT held';
        }
    }
    return line;
}

function formatShuntControlOnShunt(cell) {
    const sc = cell.shunt_control_result;
    if (!sc) {
        if (cell.step != null && !Number.isNaN(Number(cell.step))) {
            const mx = cell.max_step != null ? formatNumber(cell.max_step, 0) : '—';
            return `\n            step: ${formatNumber(cell.step, 0)} [0…${mx}]`;
        }
        return '';
    }
    const range = `[0…${formatNumber(sc.max_step, 0)}]`;
    if (sc.step_initial != null && Number(sc.step_initial) !== Number(sc.step)) {
        return `\n            step: ${formatNumber(sc.step_initial, 0)} → ${formatNumber(sc.step, 0)} ${range}`;
    }
    return `\n            step: ${formatNumber(sc.step, 0)} ${range}`;
}

function isResultPlaceholderStyle(style) {
    return style && (
        style.includes('shapeELXXX=ResultBus') ||
        style.includes('shapeELXXX=Result') ||
        style.includes('shapeELXXX=ResultExternalGrid')
    );
}

function findAllPlaceholdersForComponent(graph, componentCell) {
    const found = [];
    if (!graph?.getModel || !componentCell) return found;
    const model = graph.getModel();
    const compId = String(componentCell.id);
    const matches = (child, isDirectChild) => {
        const st = model.getStyle(child) || '';
        if (!isResultPlaceholderStyle(st)) return false;
        if (isDirectChild) return true;
        const m = st.match(/connectedTo=([^;]+)/);
        return m ? String(m[1]).trim() === compId : false;
    };
    const scan = (parent, isDirect) => {
        if (!parent) return;
        const n = model.getChildCount(parent);
        for (let i = 0; i < n; i++) {
            const child = model.getChildAt(parent, i);
            if (child && matches(child, isDirect)) found.push(child);
        }
    };
    scan(componentCell, true);
    const edges = (graph.getEdges && graph.getEdges(componentCell)) || componentCell.edges || [];
    for (let i = 0; i < edges.length; i++) scan(edges[i], false);
    return found;
}

function removeExtraPlaceholders(graph, keep, resultCell) {
    const model = graph.getModel();
    for (const ph of findAllPlaceholdersForComponent(graph, resultCell)) {
        if (ph !== keep) {
            try { model.remove(ph); } catch (_) { /* noop */ }
        }
    }
}

function repositionResultBox(graph, cell, opts) {
    if (!opts?.reposition || !cell || typeof mxPoint === 'undefined') return;
    const model = graph.getModel();
    const geo = model.getGeometry(cell);
    if (!geo) return;
    const ng = geo.clone();
    const w = opts.width || geo.width || 70;
    const h = opts.height || geo.height || 50;
    const px = typeof opts.positionX === 'number' ? opts.positionX : geo.x;
    const py = typeof opts.positionY === 'number' ? opts.positionY : (geo.y || 0);
    const isLine = !!opts.isLine || px === 0.5 || px === 0.2;
    const ox = opts.offsetXDelta || 0;
    const oy = opts.offsetYDelta || 0;
    ng.x = px;
    ng.y = py;
    ng.width = w;
    ng.height = h;
    ng.relative = true;
    ng.offset = new mxPoint(-w / 2 + ox, (isLine ? -h / 2 - 10 : -h / 2 - 5) + oy);
    model.setGeometry(cell, ng);
}

function updateOrCreatePlaceholder(graph, parent, text, opts) {
    const existing = findPlaceholder(graph, parent);
    if (existing) {
        if (typeof window !== 'undefined' && window.setResultPlaceholderValue) {
            window.setResultPlaceholderValue(graph, existing, text);
        } else {
            graph.getModel().setValue(existing, text);
        }
        repositionResultBox(graph, existing, opts);
        return existing;
    }
    return insertBox(graph, parent, text, opts);
}

/**
 * Update exactly one result box for a bus-connected component (trafo, shunt, ext grid, …).
 * Matches loadFlow.js: prefer edge-attached placeholder, drop vertex duplicates.
 */
function updateSingleComponentResult(graph, resultCell, text, opts = {}) {
    const model = graph.getModel();
    const edge = (graph.getEdges && graph.getEdges(resultCell))?.[0];
    const preferredParent = edge || resultCell;

    let keep = findPlaceholderForComponent(graph, resultCell);
    if (!keep) keep = findPlaceholder(graph, preferredParent);
    if (!keep) {
        const all = findAllPlaceholdersForComponent(graph, resultCell);
        if (all.length > 0) keep = all[0];
    }

    if (edge) {
        const orphanOnVertex = findPlaceholder(graph, resultCell);
        if (orphanOnVertex && orphanOnVertex !== keep) {
            try { model.remove(orphanOnVertex); } catch (_) { /* noop */ }
        }
    }

    if (keep) {
        model.setValue(keep, text);
        repositionResultBox(graph, keep, opts);
        removeExtraPlaceholders(graph, keep, resultCell);
        return keep;
    }

    const insertOpts = { ...opts };
    if (opts.tagComponent && insertOpts.connectedToId == null) {
        insertOpts.connectedToId = resultCell.id;
    }
    const created = insertBox(graph, preferredParent, text, insertOpts);
    if (created) removeExtraPlaceholders(graph, created, resultCell);
    return created;
}

/** Edge-attached injectors (External Grid, Generator, …): placeholder lives on the edge, not the vertex. */
function updateEdgeAttachedPlaceholder(graph, resultCell, text, opts) {
    return updateSingleComponentResult(graph, resultCell, text, opts);
}

function resultBoxesOverlap(a, b, pad) {
    return a.x < b.x + b.w + pad && a.x + a.w + pad > b.x
        && a.y < b.y + b.h + pad && a.y + a.h + pad > b.y;
}

/** Nudge result labels apart on large diagrams so they do not sit on the same spot. */
function spreadOverlappingResultBoxes(graph) {
    if (!graph?.getView || typeof mxPoint === 'undefined') return;
    const model = graph.getModel();
    const view = graph.getView();
    if (typeof view.validate === 'function') view.validate();
    const boxes = [];
    const visit = (cell) => {
        if (!cell) return;
        const style = model.getStyle(cell) || '';
        if (style.indexOf('shapeELXXX=Result') >= 0) {
            const state = view.getState(cell);
            if (state && state.width > 0 && state.height > 0) boxes.push(cell);
        }
        const n = model.getChildCount(cell);
        for (let i = 0; i < n; i++) visit(model.getChildAt(cell, i));
    };
    visit(graph.getDefaultParent());
    if (boxes.length < 25) return;
    boxes.sort((a, b) => {
        const sa = view.getState(a);
        const sb = view.getState(b);
        return (sa.y - sb.y) || (sa.x - sb.x);
    });
    const placed = [];
    model.beginUpdate();
    try {
        boxes.forEach((cell) => {
            const state = view.getState(cell);
            if (!state) return;
            let dx = 0;
            let dy = 0;
            for (let step = 0; step < 10; step++) {
                const rect = { x: state.x + dx, y: state.y + dy, w: state.width, h: state.height };
                if (!placed.some((other) => resultBoxesOverlap(rect, other, 8))) break;
                if (step % 2 === 0) dy += state.height + 12;
                else dx += 36;
            }
            if (dx !== 0 || dy !== 0) {
                const geo = model.getGeometry(cell);
                if (geo) {
                    const next = geo.clone();
                    const ox = geo.offset ? geo.offset.x : 0;
                    const oy = geo.offset ? geo.offset.y : 0;
                    next.offset = new mxPoint(ox + dx, oy + dy);
                    model.setGeometry(cell, next);
                }
            }
            placed.push({
                x: state.x + dx,
                y: state.y + dy,
                w: state.width,
                h: state.height
            });
        });
    } finally {
        model.endUpdate();
    }
}

function removeLeftoverResultCells(model) {
    const root = model.getRoot && model.getRoot();
    if (!root) return;
    const doomed = [];
    const stack = [root];
    while (stack.length) {
        const cell = stack.pop();
        const count = model.getChildCount(cell);
        for (let i = 0; i < count; i++) stack.push(model.getChildAt(cell, i));
        const style = String(model.getStyle(cell) || '');
        if (style.includes('shapeELXXX=Result')) doomed.push(cell);
    }
    doomed.forEach((cell) => {
        try { model.remove(cell); } catch (e) { /* parent already removed */ }
    });
}

function selectionPanelBlockedByDialog() {
    return !!(
        document.querySelector('.geDialog') ||
        document.querySelector('.modal-overlay') ||
        document.querySelector('.not-editable-message-dialog')
    );
}

/** The result card is fixed over the bottom-right, which is where dialog Apply sits. */
function syncSelectionPanelWithDialogs() {
    const panel = document.getElementById(SELECTION_PANEL_ID);
    if (!panel) return;
    const blocked = selectionPanelBlockedByDialog();
    panel.style.visibility = blocked ? 'hidden' : '';
    panel.style.pointerEvents = blocked ? 'none' : '';
}

function watchSelectionPanelAgainstDialogs() {
    if (typeof window === 'undefined' || window.__electrisimSelectionPanelDialogWatch) return;
    window.__electrisimSelectionPanelDialogWatch = true;
    const observer = new MutationObserver(() => syncSelectionPanelWithDialogs());
    observer.observe(document.body, { childList: true });
}

function ensureSelectionPanel() {
    watchSelectionPanelAgainstDialogs();
    let panel = document.getElementById(SELECTION_PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = SELECTION_PANEL_ID;
    panel.setAttribute('style', [
        'position:fixed', 'right:16px', 'bottom:16px', 'z-index:10050',
        'max-width:280px', 'max-height:40vh', 'overflow:auto',
        'padding:10px 12px', 'background:#fff', 'border:1px solid #b8dae9',
        'border-radius:6px', 'box-shadow:0 4px 16px rgba(0,0,0,.12)',
        'font:12px/1.45 Arial,sans-serif', 'color:#1a1a1a',
        'white-space:pre-wrap', 'display:none'
    ].join(';'));
    document.body.appendChild(panel);
    return panel;
}

function showSelectionPanel(text) {
    const panel = ensureSelectionPanel();
    if (!text) {
        panel.style.display = 'none';
        panel.textContent = '';
        return;
    }
    panel.textContent = text;
    panel.style.display = 'block';
    syncSelectionPanelWithDialogs();
}

function textForSelectedCell(graph, cell, texts) {
    if (!cell || !texts) return '';
    const seen = new Set();
    let current = cell;
    while (current && !seen.has(current)) {
        seen.add(current);
        const hit = texts.get(String(current.id));
        if (hit) return hit;
        current = graph.getModel().getParent(current);
    }
    return '';
}

function bindLoadFlowSelectionPanel(graph, texts) {
    graph.__electrisimLfSelectionTexts = texts;
    const cell = graph.getSelectionCell && graph.getSelectionCell();
    showSelectionPanel(textForSelectedCell(graph, cell, texts));
    if (graph.__electrisimLfSelectionBound) return;
    graph.__electrisimLfSelectionBound = true;
    const selection = graph.getSelectionModel && graph.getSelectionModel();
    if (!selection || !selection.addListener || typeof mxEvent === 'undefined') return;
    selection.addListener(mxEvent.CHANGE, () => {
        const map = graph.__electrisimLfSelectionTexts;
        if (!map) {
            showSelectionPanel('');
            return;
        }
        const selected = graph.getSelectionCell && graph.getSelectionCell();
        showSelectionPanel(textForSelectedCell(graph, selected, map));
    });
}

function clearLoadFlowSelectionPanel(graph) {
    if (graph) graph.__electrisimLfSelectionTexts = null;
    if (typeof document !== 'undefined' && document.getElementById(SELECTION_PANEL_ID)) {
        showSelectionPanel('');
    }
}

/**
 * @param {mxGraph} graph
 * @param {object} dataJson - pandapower load-flow result payload
 */
export function applyLoadFlowResultsToGraph(graph, dataJson) {
    if (!graph || !dataJson) return;

    mergeTapControlIntoTransformers(dataJson);
    mergeShuntControlIntoShunts(dataJson);

    const lookup = buildGraphCellLookupMap(graph);
    const resolveCell = (row) => resolveGraphCellForResult(lookup, row, graph);
    const colorOnly = (dataJson.busbars || []).length >= LARGE_LOAD_FLOW_BUS_COUNT;
    const selectionTexts = colorOnly ? new Map() : null;
    const noteLargeResult = (resultCell, text) => {
        if (!selectionTexts || !resultCell) return false;
        const trimmed = String(text || '').trim();
        selectionTexts.set(String(resultCell.id), trimmed);
        const edges = graph.getEdges && graph.getEdges(resultCell);
        if (edges) {
            for (const edge of edges) {
                if (edge && edge.id != null) selectionTexts.set(String(edge.id), trimmed);
            }
        }
        return true;
    };

    if (typeof window !== 'undefined' && typeof window.stopLoadFlowPowerAnimation === 'function') {
        window.stopLoadFlowPowerAnimation();
    }
    if (typeof window !== 'undefined' && typeof window.clearFlowArrows === 'function') {
        window.clearFlowArrows(graph);
    }

    const model = graph.getModel();
    const largeDiagram = (dataJson.busbars || []).length > 40;
    model.beginUpdate();
    try {
        if (colorOnly) removeLeftoverResultCells(model);
        (dataJson.busbars || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Bus');
            const d = busDisplayPq(cell);
            const qLine = (typeof window !== 'undefined' && window.formatBusNetReactiveQ)
                ? window.formatBusNetReactiveQ(d.q)
                : `Q[MVar]: ${formatNumber(d.q)}`;
            const text = `${label}
U[pu]: ${formatNumber(cell.vm_pu)}
U[kV]: ${formatBusVmKvForCell(cell, resultCell)}
U[deg]: ${formatNumber(cell.va_degree)}
P[MW]: ${formatNumber(d.p)}
${qLine}
PF: ${formatNumber(d.pf)}
Q/P: ${formatNumber(d.qp)}`;
            if (noteLargeResult(resultCell, text)) {
                processVoltageColor(graph, resultCell, cell.vm_pu);
                return;
            }
            updateOrCreatePlaceholder(graph, resultCell, text, largeDiagram
                ? { width: 80, height: 76, positionX: 0, positionY: 0, offsetXDelta: -96, offsetYDelta: -6, reposition: true }
                : { width: 80, height: 76, positionX: 0, positionY: 1.0, offsetXDelta: 40, offsetYDelta: 35 });
            processVoltageColor(graph, resultCell, cell.vm_pu);
        });

        (dataJson.lines || []).forEach((cell, lineIdx) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Line');
            const text = `${label}
            P_from[MW]: ${formatNumber(cell.p_from_mw)}
            Q_from[MVar]: ${formatNumber(cell.q_from_mvar)}
            i_from[kA]: ${formatNumber(cell.i_from_ka)}
            Loading[%]: ${formatNumber(cell.loading_percent, 1)}
            P_to[MW]: ${formatNumber(cell.p_to_mw)}
            Q_to[MVar]: ${formatNumber(cell.q_to_mvar)}
            i_to[kA]: ${formatNumber(cell.i_to_ka)}`;
            if (noteLargeResult(resultCell, text)) {
                processLoadingColor(graph, resultCell, cell.loading_percent);
                return;
            }
            const edge = (graph.getEdges && graph.getEdges(resultCell))?.[0];
            const parent = edge || resultCell;
            const lineLane = lineIdx % 5;
            updateOrCreatePlaceholder(graph, parent, text, largeDiagram
                ? {
                    width: 70, height: 70,
                    positionX: 0.18 + lineLane * 0.14,
                    positionY: 0,
                    isLine: true,
                    offsetYDelta: (lineLane % 2 === 0 ? -1 : 1) * (28 + lineLane * 22),
                    reposition: true
                }
                : { width: 70, height: 70, positionX: 0.5, positionY: 0, isLine: true });
            processLoadingColor(graph, resultCell, cell.loading_percent);
        });

        (dataJson.transformers || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Trafo');
            const tapBlock = formatTapControlOnTrafo(cell);
            const text = `${label}
            P_HV[MW]: ${formatNumber(cell.p_hv_mw)}
            P_LV[MW]: ${formatNumber(cell.p_lv_mw)}
            i_HV[kA]: ${formatNumber(cell.i_hv_ka)}
            i_LV[kA]: ${formatNumber(cell.i_lv_ka)}
            loading[%]: ${formatNumber(cell.loading_percent)}${tapBlock}`;
            if (noteLargeResult(resultCell, text)) {
                processLoadingColor(graph, resultCell, cell.loading_percent);
                return;
            }
            const boxW = tapBlock ? 90 : 68;
            const boxH = tapBlock ? 88 : 64;
            updateSingleComponentResult(graph, resultCell, text, {
                width: boxW, height: boxH, positionX: -0.3, tagComponent: true
            });
            processLoadingColor(graph, resultCell, cell.loading_percent);
        });

        (dataJson.transformers3W || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Trafo3W');
            const tapBlock = formatTapControlOnTrafo(cell);
            const text = `${label}
            i_HV[kA]: ${formatNumber(cell.i_hv_ka)}
            i_MV[kA]: ${formatNumber(cell.i_mv_ka)}
            i_LV[kA]: ${formatNumber(cell.i_lv_ka)}
            loading[%]: ${formatNumber(cell.loading_percent)}${tapBlock}`;
            if (noteLargeResult(resultCell, text)) {
                processLoadingColor(graph, resultCell, cell.loading_percent);
                return;
            }
            const boxW = tapBlock ? 90 : 60;
            const boxH = tapBlock ? 72 : 50;
            updateSingleComponentResult(graph, resultCell, text, {
                width: boxW, height: boxH, positionX: -0.3, tagComponent: true
            });
            processLoadingColor(graph, resultCell, cell.loading_percent);
        });

        (dataJson.externalgrids || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'External Grid');
            const qLine = (typeof window !== 'undefined' && window.formatExternalGridReactiveQ)
                ? window.formatExternalGridReactiveQ(cell.q_mvar)
                : `Q[MVar]: ${formatNumber(cell.q_mvar)}`;
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            ${qLine}
            PF: ${formatNumber(cell.pf)}
            Q/P: ${formatNumber(cell.q_p)}`;
            if (noteLargeResult(resultCell, text)) return;
            updateEdgeAttachedPlaceholder(graph, resultCell, text, { width: 95, height: 68, positionX: -0.3 });
        });

        (dataJson.staticgenerators || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const styleStr = resultCell.style || '';
            const typeLabel = styleStr.includes('shapeELXXX=Wind Turbine') ? 'Wind Turbine' : 'Static Generator';
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), typeLabel);
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}`;
            if (noteLargeResult(resultCell, text)) return;
            updateEdgeAttachedPlaceholder(graph, resultCell, text, { width: 60, height: 40, positionX: -0.3 });
        });

        (dataJson.generators || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Generator');
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}
            U[degree]: ${formatNumber(cell.va_degree)}
            Um[pu]: ${formatNumber(cell.vm_pu)}`;
            if (noteLargeResult(resultCell, text)) return;
            updateEdgeAttachedPlaceholder(graph, resultCell, text, largeDiagram
                ? { width: 60, height: 40, positionX: 0, offsetXDelta: -82, offsetYDelta: -28, reposition: true }
                : { width: 60, height: 40, positionX: -0.3 });
        });

        (dataJson.shunts || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Shunt');
            const shuntCtl = formatShuntControlOnShunt(cell);
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}
            Um[pu]: ${formatNumber(cell.vm_pu)}${shuntCtl}`;
            if (noteLargeResult(resultCell, text)) return;
            const boxW = shuntCtl ? 74 : 60;
            const boxH = shuntCtl ? 58 : 50;
            updateSingleComponentResult(graph, resultCell, text, {
                width: boxW, height: boxH, positionX: -0.3
            });
        });

        (dataJson.capacitors || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Capacitor');
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}
            Um[pu]: ${formatNumber(cell.vm_pu)}`;
            if (noteLargeResult(resultCell, text)) return;
            updateSingleComponentResult(graph, resultCell, text, { width: 60, height: 40, positionX: -0.3 });
        });

        (dataJson.loads || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Load');
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}`;
            if (noteLargeResult(resultCell, text)) return;
            updateEdgeAttachedPlaceholder(graph, resultCell, text, largeDiagram
                ? { width: 60, height: 40, positionX: 0, offsetXDelta: 78, offsetYDelta: 6, reposition: true }
                : { width: 60, height: 40, positionX: -0.3 });
        });

        (dataJson.storages || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Storage');
            const loadLine = cell.loading_percent != null
                ? `\n            Loading[%]: ${formatNumber(cell.loading_percent, 1)}` : '';
            const text = `${label}
            P[MW]: ${formatNumber(cell.p_mw)}
            Q[MVar]: ${formatNumber(cell.q_mvar)}${loadLine}`;
            if (noteLargeResult(resultCell, text)) {
                processLoadingColor(graph, resultCell, cell.loading_percent);
                return;
            }
            updateEdgeAttachedPlaceholder(graph, resultCell, text, { width: 70, height: 80, positionX: -0.3 });
            processLoadingColor(graph, resultCell, cell.loading_percent);
        });

        (dataJson.switches || []).forEach((cell) => {
            const resultCell = resolveCell(cell);
            if (!resultCell) return;
            const label = formatResultNameHeader(resultCell, replaceUnderscores(cell.name), 'Switch');
            const text = `${label}
closed: ${(cell.closed === false || cell.closed === 'false') ? 'false' : 'true'}
P_from[MW]: ${formatNumber(cell.p_from_mw)}
Q_from[MVar]: ${formatNumber(cell.q_from_mvar)}
P_to[MW]: ${formatNumber(cell.p_to_mw)}
Q_to[MVar]: ${formatNumber(cell.q_to_mvar)}
i[kA]: ${formatNumber(cell.i_ka)}
Loading[%]: ${formatNumber(cell.loading_percent, 1)}`;
            if (noteLargeResult(resultCell, text)) {
                processLoadingColor(graph, resultCell, cell.loading_percent);
                return;
            }
            updateOrCreatePlaceholder(graph, resultCell, text, {
                width: 78, height: 102, positionX: 0, positionY: 0, offsetXDelta: 90, connectedToId: resultCell.id
            });
            processLoadingColor(graph, resultCell, cell.loading_percent);
        });
    } finally {
        model.endUpdate();
        if (graph.getView?.().refresh) graph.getView().refresh();
        if (largeDiagram && !colorOnly) spreadOverlappingResultBoxes(graph);
    }

    if (colorOnly) bindLoadFlowSelectionPanel(graph, selectionTexts);
    else clearLoadFlowSelectionPanel(graph);

    try {
        window.__electrisimLastLoadFlowResultJson = dataJson;
    } catch (_) { /* non-browser */ }

    try {
        if (colorOnly) return;
        const wantAnim = typeof window.readSavedAnimatePowerFlow === 'function'
            ? window.readSavedAnimatePowerFlow()
            : false;
        if (wantAnim && typeof window.startLoadFlowPowerAnimation === 'function') {
            window.startLoadFlowPowerAnimation(graph, dataJson);
        } else if (typeof window.stopLoadFlowPowerAnimation === 'function') {
            window.stopLoadFlowPowerAnimation();
        }
    } catch (e) {
        console.warn('Load flow animation skipped:', e);
    }
}

if (typeof window !== 'undefined') {
    window.applyLoadFlowResultsToGraph = applyLoadFlowResultsToGraph;
}
