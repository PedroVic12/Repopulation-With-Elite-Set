/**
 * Normalize backend / graph object id for display (underscores → #).
 */
export function normalizeGraphObjectName(name) {
    if (name == null || name === '') return '';
    return String(name).trim().replace(/_/g, '#');
}

/**
 * True for draw.io internal object names (e.g. mxCell_702, mxCell#702) — hide in result UI.
 */
export function looksLikeInternalGraphObjectId(str) {
    if (str == null || str === '') return false;
    const s = String(str).trim().replace(/#/g, '_');
    return /^mxCell_\d+$/i.test(s);
}

/**
 * User-editable name from component dialog (XML attribute `name`), shared by bus/line/trafo/etc. dialogs.
 */
export function getDialogNameFromCell(cell) {
    if (!cell?.value?.attributes?.getNamedItem) return '';
    const n = cell.value.attributes.getNamedItem('name')?.nodeValue;
    return n != null && String(n).trim() ? String(n).trim() : '';
}

/**
 * Get display name for result boxes: prefers dialog name (from cell attributes), then backend name.
 * @param {mxCell} resultCell - The graph cell (has value.attributes with 'name')
 * @param {string} backendName - Name from backend (e.g. mxCell_260)
 * @param {string} defaultName - Fallback (e.g. 'Line', 'Trafo', 'Generator')
 * @returns {string} Display name for result box
 */
export function getDisplayName(resultCell, backendName, defaultName) {
    const n = getDialogNameFromCell(resultCell);
    if (n) return n;
    const bn = backendName ? String(backendName).replace(/_/g, '#') : null;
    if (bn && !looksLikeInternalGraphObjectId(bn)) return bn;
    return defaultName || 'Unknown';
}

/**
 * Heading for on-canvas result boxes: dialog name on first line, (object id) on second when both differ.
 */
export function formatResultNameHeader(resultCell, backendName, defaultType) {
    const dialog = getDialogNameFromCell(resultCell);
    const fromBackend = backendName ? normalizeGraphObjectName(String(backendName)) : '';
    const rawMx = resultCell?.mxObjectId;
    const fromCell = rawMx
        ? normalizeGraphObjectName(String(rawMx).replace(/#/g, '_'))
        : '';
    const objectId = fromBackend || fromCell;
    const objectIdDisplay =
        objectId && !looksLikeInternalGraphObjectId(objectId) ? objectId : '';
    if (dialog) {
        if (objectIdDisplay && dialog !== objectIdDisplay) {
            return `${dialog}\n(${objectIdDisplay})`;
        }
        return dialog;
    }
    if (objectIdDisplay) return objectIdDisplay;
    return defaultType || 'Unknown';
}

function addMxLookupKeys(set, mxObjectId) {
    if (mxObjectId == null || mxObjectId === '') return;
    const raw = String(mxObjectId);
    const under = raw.replace(/#/g, '_');
    set.add(raw);
    set.add(under);
    if (under.startsWith('mxCell_')) {
        set.add('mxCell#' + under.slice('mxCell_'.length));
    }
    set.add(raw.toLowerCase());
    set.add(under.toLowerCase());
}

/**
 * All string keys to try when matching a backend result row to a graph cell.
 * Covers JSON number/string drift (e.g. 720 vs "720"), mxCell_ / mxCell#, etc.
 */
export function collectBackendResultLookupKeys(backendRow) {
    if (!backendRow) return [];
    const keys = new Set();
    const add = (v) => {
        if (v === null || v === undefined) return;
        if (v === '') return;
        keys.add(String(v));
        if (typeof v === 'number' && Number.isFinite(v)) {
            keys.add(v);
            if (Number.isInteger(v)) keys.add(String(v));
        }
        const s = String(v).trim();
        if (!s) return;
        keys.add(s);
        keys.add(s.toLowerCase());
        if (/^-?\d+\.\d+$/.test(s)) {
            const n = Number(s);
            if (Number.isFinite(n)) {
                keys.add(String(n));
                if (Number.isInteger(n)) keys.add(n);
            }
        }
    };
    add(backendRow.id);
    add(backendRow.technical_name);
    if (backendRow.dialogName != null) {
        const dn = String(backendRow.dialogName).trim();
        if (dn) {
            add(dn);
            add(dn.toLowerCase());
        }
    }
    if (backendRow.name != null) {
        const n = String(backendRow.name);
        add(n);
        add(n.replace(/#/g, '_'));
        add(n.replace(/_/g, '#'));
        const set = new Set();
        addMxLookupKeys(set, n);
        addMxLookupKeys(set, n.replace(/#/g, '_'));
        set.forEach((k) => add(k));
    }
    return [...keys].filter((k) => k !== '' && k != null);
}

/**
 * Last-resort: walk all cells (vertices and edges) and match id, mxObjectId, or dialog name.
 */
function resolveGraphCellByScanningVertices(graph, backendRow) {
    if (!graph?.getModel || !backendRow) return null;
    const model = graph.getModel();
    const cells = model.cells;
    if (!cells) return null;
    const wantNameU = backendRow.name != null ? String(backendRow.name).replace(/#/g, '_') : '';
    const wantNameRaw = backendRow.name != null ? String(backendRow.name) : '';
    const wantIdStr = backendRow.id != null ? String(backendRow.id) : '';
    const wantIdNum = wantIdStr !== '' && !Number.isNaN(Number(wantIdStr)) ? Number(wantIdStr) : null;
    const wantDn = backendRow.dialogName != null ? String(backendRow.dialogName).trim().toLowerCase() : '';
    for (const cid in cells) {
        const c = cells[cid];
        if (!c) continue;
        if (wantDn) {
            const dn = getDialogNameFromCell(c);
            if (dn && dn.trim().toLowerCase() === wantDn) return c;
        }
        if (wantIdStr !== '' && (String(c.id) === wantIdStr || (wantIdNum !== null && c.id === wantIdNum))) {
            return c;
        }
        const mx = c.mxObjectId ? String(c.mxObjectId) : '';
        const mxU = mx.replace(/#/g, '_');
        if (wantNameU && (mxU === wantNameU || mx === wantNameRaw || mx.replace(/_/g, '#') === wantNameRaw)) {
            return c;
        }
    }
    return null;
}

/**
 * Map backend result row { id, name } → graph cell (same idea as OpenDSS cellIdMap).
 */
export function buildGraphCellLookupMap(graph) {
    const map = new Map();
    if (!graph?.getModel) return map;
    const cells = graph.getModel().cells;
    if (!cells || typeof cells !== 'object') return map;
    const register = (key, cell) => {
        if (key != null && key !== '') map.set(String(key), cell);
    };
    for (const cid in cells) {
        const c = cells[cid];
        if (!c) continue;
        register(c.id, c);
        if (typeof c.id === 'number') register(String(c.id), c);
        else if (c.id != null && String(c.id).trim() !== '') {
            const idStr = String(c.id);
            const asNum = Number(idStr);
            if (Number.isFinite(asNum)) register(asNum, c);
        }
        if (c.mxObjectId) {
            const keys = new Set();
            addMxLookupKeys(keys, c.mxObjectId);
            keys.forEach(k => register(k, c));
        }
        try {
            const dn = getDialogNameFromCell(c);
            if (dn) {
                const norm = dn.trim().toLowerCase();
                register(norm, c);
                register('dn:' + norm, c);
            }
        } catch (e) { /* ignore */ }
    }
    return map;
}

/**
 * @param {Map} map - from buildGraphCellLookupMap(graph)
 * @param {object} backendRow - result row with id / name
 * @param {object} [graph] - optional mxGraph; if set, scan vertices when map misses
 */
export function resolveGraphCellForResult(map, backendRow, graph) {
    if (!map || !backendRow) return null;
    const tryKeys = collectBackendResultLookupKeys(backendRow);
    for (const k of tryKeys) {
        if (k === '' || k == null) continue;
        let cell = map.get(String(k));
        if (cell) return cell;
        cell = map.get(String(k).toLowerCase());
        if (cell) return cell;
    }
    if (graph) {
        const scanned = resolveGraphCellByScanningVertices(graph, backendRow);
        if (scanned) return scanned;
    }
    return null;
}

/** Result JSON array keys that carry per-element load-flow rows. */
const RESULT_JSON_ARRAY_KEYS = [
    'busbars',
    'lines',
    'transformers',
    'transformers3W',
    'transformers3w',
    'generators',
    'staticgenerators',
    'asymmetricstaticgenerators',
    'externalgrids',
    'pvsystems',
    'storages',
    'loads',
    'asymmetricloads',
    'motors',
    'shunts',
    'capacitors',
    'impedances',
    'dclines',
    'arc_flash',
    'device_duties',
    'lines_sc',
    'trafos_sc',
    'trafos3w_sc',
];

/**
 * Stamp each result row with `dialogName` from the live graph so snapshots and
 * Scenario Compare can match elements across sheets (different mxCell ids).
 * Mutates and returns `dataJson`.
 */
export function enrichResultJsonWithDialogNames(dataJson, graph) {
    if (!dataJson || !graph?.getModel) return dataJson;
    let map;
    try { map = buildGraphCellLookupMap(graph); } catch (e) { return dataJson; }
    const resolveDialog = (row) => {
        if (!row) return '';
        if (row.dialogName && !looksLikeInternalGraphObjectId(row.dialogName)) {
            return String(row.dialogName).trim();
        }
        try {
            const cell = resolveGraphCellForResult(map, row, graph);
            const dn = cell ? getDialogNameFromCell(cell) : '';
            return dn && !looksLikeInternalGraphObjectId(dn) ? dn : '';
        } catch (e) { return ''; }
    };
    for (const key of RESULT_JSON_ARRAY_KEYS) {
        const arr = dataJson[key];
        if (!Array.isArray(arr)) continue;
        for (const row of arr) {
            const dn = resolveDialog(row);
            if (dn) row.dialogName = dn;
        }
    }
    return dataJson;
}

/**
 * Returns (row) => dialog name string for exported tables; empty if graph missing or cell not found.
 */
export function createDialogNameResolver(graph) {
    if (!graph?.getModel) {
        return () => '';
    }
    const map = buildGraphCellLookupMap(graph);
    return (row) => {
        const cell = resolveGraphCellForResult(map, row, graph);
        return cell ? (getDialogNameFromCell(cell) || '') : '';
    };
}

// Helper function to get attributes as object
export const getAttributesAsObject = (cell, attributeMap) => {
    const result = {};

    if (!cell || !cell.value || !cell.value.attributes) {
        return result;
    }

    const attributes = cell.value.attributes;

    for (const [key, config] of Object.entries(attributeMap)) {
        const isOptional = typeof config === 'object' && config.optional;
        const attributeName = typeof config === 'object' ? config.name : config;

        let found = false;
        for (let i = 0; i < attributes.length; i++) {
            if (attributes[i].nodeName === attributeName) {
                const value = attributes[i].nodeValue;
                if (!(isOptional && value === '')) {
                    result[key] = value;
                    found = true;
                }
                break;
            }
        }

        if (!found && !isOptional) {
            result[key] = null;
        } else if (!found && isOptional) {
            if (key === 'parallel') {
                result[key] = '1';
            } else if (key === 'df') {
                result[key] = '1.0';
            } else if (key === 'vector_group') {
                result[key] = 'Dyn11';
            } else if (key === 'vk0_percent') {
                result[key] = '0.0';
            } else if (key === 'vkr0_percent') {
                result[key] = '0.0';
            } else if (key === 'mag0_percent') {
                result[key] = '0.0';
            } else if (key === 'si0_hv_partial') {
                result[key] = '0.0';
            } else if (
                key === 'vk0_hv_percent' || key === 'vk0_mv_percent' || key === 'vk0_lv_percent' ||
                key === 'vkr0_hv_percent' || key === 'vkr0_mv_percent' || key === 'vkr0_lv_percent'
            ) {
                result[key] = '0';
            }
        }
    }

    return result;
};

// Make it available globally for legacy code
window.getAttributesAsObject = getAttributesAsObject;
window.getDisplayName = getDisplayName;
window.formatResultNameHeader = formatResultNameHeader;
window.getDialogNameFromCell = getDialogNameFromCell;
window.createDialogNameResolver = createDialogNameResolver;
// Exposed so non-module scripts (e.g. results/networkHealthDashboard.js) can
// resolve backend result rows back to graph cells with the same robustness
// loadFlow.js uses internally.
window.buildGraphCellLookupMap = buildGraphCellLookupMap;
window.resolveGraphCellForResult = resolveGraphCellForResult;
window.enrichResultJsonWithDialogNames = enrichResultJsonWithDialogNames;