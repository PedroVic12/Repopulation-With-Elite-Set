import { Dialog } from './Dialog.js';
import { createEconomicTabContent, buildCostPerUnitByCurrency } from './utils/economicTabHelper.js';
import { createDialogBracketGroup } from './utils/dialogBracketGroup.js';
import { rowDefsThreeWindingTransformerLibrary, gridOptionsThreeWindingTransformerLibrary, columnDefsThreeWindingTransformerLibrary } from './threeWindingTransformerLibraryDialog.js';
import { LibraryDialogManager } from './LibraryDialogManager.js';

// Default values for three-winding transformer parameters (based on pandapower documentation)
// vk_*_percent, vkr_*_percent, pfe_kw, i0_percent are in Load Flow tab (necessary for power flow per pandapower trafo3w)
export const defaultThreeWindingTransformerData = {
    name: "Three Winding Transformer",
    term_label_0: "HV",
    term_label_1: "MV",
    term_label_2: "LV",
    sn_hv_mva: 0.0,
    sn_mv_mva: 0.0,
    sn_lv_mva: 0.0,
    vn_hv_kv: 0.0,
    vn_mv_kv: 0.0,
    vn_lv_kv: 0.0,
    vk_hv_percent: 0.0,
    vk_mv_percent: 0.0,
    vk_lv_percent: 0.0,
    vkr_hv_percent: 0.0,
    vkr_mv_percent: 0.0,
    vkr_lv_percent: 0.0,
    pfe_kw: 0.0,
    i0_percent: 0.0,
    shift_mv_degree: 0.0,
    shift_lv_degree: 0.0,
    tap_side: "hv",
    tap_neutral: 0.0,
    tap_min: -10.0,
    tap_max: 10.0,
    tap_step_percent: 1.0,
    tap_step_degree: 0.0,
    tap_pos: 0.0,
    tap_phase_shifter: false,
    tap_changer_type: "Ratio",  // New in pandapower 3.0+: "Ratio" or "Symmetrical"
    in_service: true,
    discrete_tap_control: false,
    // Which winding's bus voltage DiscreteTapControl monitors (pandapower: hv | mv | lv for trafo3w)
    control_side: "lv",
    vm_lower_pu: 0.99,
    vm_upper_pu: 1.01,
    // Zero sequence parameters (optional)
    vk0_hv_percent: 0.0,
    vk0_mv_percent: 0.0,
    vk0_lv_percent: 0.0,
    vkr0_hv_percent: 0.0,
    vkr0_mv_percent: 0.0,
    vkr0_lv_percent: 0.0,
    vector_group: 'YNynd',
    /** pandapower trafo3w max_loading_percent — OPF branch thermal limit (%), 0 = unset */
    max_loading_percent: 0.0,
};

export class ThreeWindingTransformerDialog extends Dialog {
    constructor(editorUi) {
        super('Three Winding Transformer Parameters', 'Apply');
        
        this.ui = editorUi || window.App?.main?.editor?.editorUi;
        this.graph = this.ui?.editor?.graph;
        this.currentTab = 'loadflow';
        this.data = { ...defaultThreeWindingTransformerData };
        this.inputs = new Map(); // Initialize inputs map for form elements
        
        // Schematic parameters (terminal labels shown on the canvas symbol)
        this.schematicParameters = [
            {
                id: 'term_label_0',
                label: 'Schematic label — port 0 (HV bus / first connection)',
                description: 'Display only. Matches edge order for export (hv_bus). Does not change ratings or solver data.',
                type: 'text',
                value: this.data.term_label_0 || 'HV'
            },
            {
                id: 'term_label_1',
                label: 'Schematic label — port 1 (MV bus / second connection)',
                description: 'Display only. Matches edge order for export (mv_bus). Does not change ratings or solver data.',
                type: 'text',
                value: this.data.term_label_1 || 'MV'
            },
            {
                id: 'term_label_2',
                label: 'Schematic label — port 2 (LV bus / third connection)',
                description: 'Display only. Matches edge order for export (lv_bus). Does not change ratings or solver data.',
                type: 'text',
                value: this.data.term_label_2 || 'LV'
            }
        ];

        // Load Flow parameters (necessary for executing a power flow calculation)
        this.loadFlowParameters = [
            {
                id: 'name',
                label: 'Name',
                description: 'Name identifier for the three-winding transformer',
                type: 'text',
                value: this.data.name
            },
            {
                id: 'sn_hv_mva',
                label: 'HV Rated Power (sn_hv_mva)',
                description: 'Rated apparent power in MVA of high voltage side (>0)',
                type: 'number',
                value: this.data.sn_hv_mva.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'sn_mv_mva',
                label: 'MV Rated Power (sn_mv_mva)',
                description: 'Rated apparent power in MVA of medium voltage side (>0)',
                type: 'number',
                value: this.data.sn_mv_mva.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'sn_lv_mva',
                label: 'LV Rated Power (sn_lv_mva)',
                description: 'Rated apparent power in MVA of low voltage side (>0)',
                type: 'number',
                value: this.data.sn_lv_mva.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vn_hv_kv',
                label: 'HV Rated Voltage (vn_hv_kv)',
                description: 'Rated voltage in kV of high voltage side (>0)',
                type: 'number',
                value: this.data.vn_hv_kv.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vn_mv_kv',
                label: 'MV Rated Voltage (vn_mv_kv)',
                description: 'Rated voltage in kV of medium voltage side (>0)',
                type: 'number',
                value: this.data.vn_mv_kv.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vn_lv_kv',
                label: 'LV Rated Voltage (vn_lv_kv)',
                description: 'Rated voltage in kV of low voltage side (>0)',
                type: 'number',
                value: this.data.vn_lv_kv.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vk_hv_percent',
                label: 'HV Short Circuit Voltage (vk_hv_percent)',
                description: 'Short circuit voltage in percent from HV to MV (>0). Necessary for load flow.',
                type: 'number',
                value: this.data.vk_hv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vk_mv_percent',
                label: 'MV Short Circuit Voltage (vk_mv_percent)',
                description: 'Short circuit voltage in percent from MV to LV (>0). Necessary for load flow.',
                type: 'number',
                value: this.data.vk_mv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vk_lv_percent',
                label: 'LV Short Circuit Voltage (vk_lv_percent)',
                description: 'Short circuit voltage in percent from HV to LV (>0). Necessary for load flow.',
                type: 'number',
                value: this.data.vk_lv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr_hv_percent',
                label: 'HV Real Part SC Voltage (vkr_hv_percent)',
                description: 'Real part of short circuit voltage HV-MV in percent (>=0). Necessary for load flow.',
                type: 'number',
                value: this.data.vkr_hv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr_mv_percent',
                label: 'MV Real Part SC Voltage (vkr_mv_percent)',
                description: 'Real part of short circuit voltage MV-LV in percent (>=0). Necessary for load flow.',
                type: 'number',
                value: this.data.vkr_mv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr_lv_percent',
                label: 'LV Real Part SC Voltage (vkr_lv_percent)',
                description: 'Real part of short circuit voltage HV-LV in percent (>=0). Necessary for load flow.',
                type: 'number',
                value: this.data.vkr_lv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'pfe_kw',
                label: 'Iron Losses (pfe_kw)',
                description: 'Iron losses in kW (>=0). Necessary for load flow.',
                type: 'number',
                value: this.data.pfe_kw.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'i0_percent',
                label: 'Open Loop Losses (i0_percent)',
                description: 'Open loop losses in percent (>=0). Necessary for load flow.',
                type: 'number',
                value: this.data.i0_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'in_service',
                label: 'In Service',
                description: 'Specifies if the transformer is in service (True/False)',
                type: 'checkbox',
                value: this.data.in_service
            },
            {
                id: 'vector_group',
                label: 'Vector Group',
                symbol: 'vector_group',
                description: 'Vector group of the transformer (e.g., YNynd, YNdyn, YNdd)',
                type: 'select',
                value: this.data.vector_group,
                options: ['YNynd', 'YNdyn', 'YNdd']
            },
            {
                id: 'tap_side',
                label: 'Tap Side (tap_side)',
                description: 'Where the tap changer is located (hv, mv, lv)',
                type: 'select',
                value: this.data.tap_side,
                options: ['hv', 'mv', 'lv']
            },
            {
                id: 'tap_neutral',
                label: 'Tap Neutral Position (tap_neutral)',
                description: 'Tap position where no voltage shift is present',
                type: 'number',
                value: this.data.tap_neutral.toString(),
                step: '1'
            },
            {
                id: 'tap_min',
                label: 'Minimum Tap Position (tap_min)',
                description: 'Minimum tap position',
                type: 'number',
                value: this.data.tap_min.toString(),
                step: '1'
            },
            {
                id: 'tap_max',
                label: 'Maximum Tap Position (tap_max)',
                description: 'Maximum tap position',
                type: 'number',
                value: this.data.tap_max.toString(),
                step: '1'
            },
            {
                id: 'tap_step_percent',
                label: 'Tap Step Size (tap_step_percent)',
                description: 'Tap step size in percent (>0)',
                type: 'number',
                value: this.data.tap_step_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'tap_step_degree',
                label: 'Tap Step Angle (tap_step_degree)',
                description: 'Tap step for voltage angle in degrees; used when calculate_voltage_angles is True (pandapower trafo3w)',
                type: 'number',
                value: this.data.tap_step_degree.toString(),
                step: '0.1'
            },
            {
                id: 'tap_pos',
                label: 'Current Tap Position (tap_pos)',
                description: 'Current tap position of the transformer. Defaults to tap_neutral if not set',
                type: 'number',
                value: this.data.tap_pos.toString(),
                step: '1'
            },
            {
                id: 'tap_phase_shifter',
                label: 'Phase Shifter (tap_phase_shifter)',
                description: 'Whether the transformer is an ideal phase shifter (True/False)',
                type: 'checkbox',
                value: this.data.tap_phase_shifter
            },
            {
                id: 'tap_changer_type',
                label: 'Tap Changer Type (tap_changer_type)',
                description: 'Type of tap changer: "Ratio" (default) adjusts voltage magnitude only, "Symmetrical" distributes tap change to both windings',
                type: 'select',
                value: this.data.tap_changer_type,
                options: ['Ratio', 'Symmetrical']
            },
            {
                id: 'discrete_tap_control',
                label: 'Discrete Tap Control (discrete_tap_control)',
                description: 'Enable pandapower DiscreteTapControl on this three-winding transformer (requires Include controller in Load Flow dialog)',
                type: 'checkbox',
                value: this.data.discrete_tap_control,
                bracketGroup: 'discreteTapControl',
                bracketGroupTitle: 'Discrete tap control (DiscreteTapControl)'
            },
            {
                id: 'control_side',
                label: 'Control Side (control_side)',
                description: 'Winding whose bus voltage is kept within the deadband: hv, mv, or lv (pandapower trafo3w DiscreteTapControl)',
                type: 'select',
                value: this.data.control_side,
                options: ['hv', 'mv', 'lv'],
                bracketGroup: 'discreteTapControl'
            },
            {
                id: 'vm_lower_pu',
                label: 'Voltage Lower Limit (vm_lower_pu) [pu]',
                description: 'Lower bound of permissible voltage band for discrete tap control (e.g. 0.99)',
                type: 'number',
                value: this.data.vm_lower_pu.toString(),
                step: '0.01',
                min: '0.9',
                bracketGroup: 'discreteTapControl'
            },
            {
                id: 'vm_upper_pu',
                label: 'Voltage Upper Limit (vm_upper_pu) [pu]',
                description: 'Upper bound of permissible voltage band for discrete tap control (e.g. 1.01)',
                type: 'number',
                value: this.data.vm_upper_pu.toString(),
                step: '0.01',
                min: '0.9',
                bracketGroup: 'discreteTapControl'
            }
        ];
        
        // Short Circuit parameters (zero sequence and short-circuit specific)
        this.shortCircuitParameters = [
            {
                id: 'shift_mv_degree',
                label: 'MV Angle Shift (shift_mv_degree)',
                description: 'Angle shift to medium voltage side in degrees',
                type: 'number',
                value: this.data.shift_mv_degree.toString(),
                step: '0.1'
            },
            {
                id: 'shift_lv_degree',
                label: 'LV Angle Shift (shift_lv_degree)',
                description: 'Angle shift to low voltage side in degrees',
                type: 'number',
                value: this.data.shift_lv_degree.toString(),
                step: '0.1'
            },
            {
                id: 'vk0_hv_percent',
                label: 'HV Zero Sequence SC Voltage (vk0_hv_percent)',
                description: 'Zero sequence short circuit voltage in percent of high voltage side (optional)',
                type: 'number',
                value: this.data.vk0_hv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vk0_mv_percent',
                label: 'MV Zero Sequence SC Voltage (vk0_mv_percent)',
                description: 'Zero sequence short circuit voltage in percent of medium voltage side (optional)',
                type: 'number',
                value: this.data.vk0_mv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vk0_lv_percent',
                label: 'LV Zero Sequence SC Voltage (vk0_lv_percent)',
                description: 'Zero sequence short circuit voltage in percent of low voltage side (optional)',
                type: 'number',
                value: this.data.vk0_lv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr0_hv_percent',
                label: 'HV Zero Sequence Real SC Voltage (vkr0_hv_percent)',
                description: 'Zero sequence real part of short circuit voltage in percent of high voltage side (optional)',
                type: 'number',
                value: this.data.vkr0_hv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr0_mv_percent',
                label: 'MV Zero Sequence Real SC Voltage (vkr0_mv_percent)',
                description: 'Zero sequence real part of short circuit voltage in percent of medium voltage side (optional)',
                type: 'number',
                value: this.data.vkr0_mv_percent.toString(),
                step: '0.1',
                min: '0'
            },
            {
                id: 'vkr0_lv_percent',
                label: 'LV Zero Sequence Real SC Voltage (vkr0_lv_percent)',
                description: 'Zero sequence real part of short circuit voltage in percent of low voltage side (optional)',
                type: 'number',
                value: this.data.vkr0_lv_percent.toString(),
                step: '0.1',
                min: '0'
            }
        ];

        // OPF (pandapower trafo3w — https://pandapower.readthedocs.io/en/latest/elements/trafo3w.html)
        this.opfParameters = [
            {
                id: 'max_loading_percent',
                label: 'Maximum loading (max_loading_percent) [%]',
                description: 'Optional AC optimal power flow constraint: maximum loading in percent of transformer rating (pandapower trafo3w max_loading_percent). Use 0 for no limit. https://pandapower.readthedocs.io/en/latest/elements/trafo3w.html',
                type: 'number',
                value: this.data.max_loading_percent.toString(),
                step: '0.1',
                min: '0',
            },
        ];
        
        // Economic parameters (for Economic Analysis)
        this.economicParameters = [
            { id: 'cost_per_unit_by_currency', label: 'Cost per unit', description: 'Cost per unit for Economic Analysis CAPEX calculation', type: 'text', value: '' }
        ];
    }
    
    getDescription() {
        return '<strong>Configure Three Winding Transformer Parameters</strong><br>Set parameters for three-winding transformer with HV, MV, and LV sides. See the <a href="https://electrisim.com/documentation.html#three-winding-transformer" target="_blank" rel="noopener noreferrer">Electrisim documentation</a>.';
    }
    
    show(callback) {
        // Store callback for later use
        this.callback = callback;
        
        // Create custom dialog content with tabs
        this.showTabDialog();
    }
    
    showTabDialog() {
        // Use global App if ui is not valid
        this.ui = this.ui || window.App?.main?.editor?.editorUi;
        
        // Create main container
        const container = document.createElement('div');
        Object.assign(container.style, {
            fontFamily: 'Arial, sans-serif',
            fontSize: '14px',
            lineHeight: '1.5',
            color: '#333',
            padding: '0',
            margin: '0',
            width: '100%',
            height: '100%',
            boxSizing: 'border-box',
            display: 'flex',
            flexDirection: 'column'
        });

        // Add description
        const description = document.createElement('div');
        Object.assign(description.style, {
            padding: '6px 10px',
            backgroundColor: '#e3f2fd',
            border: '1px solid #bbdefb',
            borderRadius: '4px',
            fontSize: '12px',
            color: '#1565c0',
            marginBottom: '12px'
        });
        description.innerHTML = this.getDescription();
        container.appendChild(description);

        // Create tab container
        const tabContainer = document.createElement('div');
        Object.assign(tabContainer.style, {
            display: 'flex',
            borderBottom: '2px solid #e9ecef',
            marginBottom: '16px'
        });

        // Create tabs
        const loadFlowTab = this.createTab('Load Flow', 'loadflow', this.currentTab === 'loadflow');
        const shortCircuitTab = this.createTab('Short Circuit', 'shortcircuit', this.currentTab === 'shortcircuit');
        const opfTab = this.createTab('OPF', 'opf', this.currentTab === 'opf');
        const schematicTab = this.createTab('Schematic', 'schematic', this.currentTab === 'schematic');
        const economicTab = this.createTab('Economic', 'economic', this.currentTab === 'economic');
        
        tabContainer.appendChild(loadFlowTab);
        tabContainer.appendChild(shortCircuitTab);
        tabContainer.appendChild(opfTab);
        tabContainer.appendChild(schematicTab);
        tabContainer.appendChild(economicTab);
        container.appendChild(tabContainer);

        // Create content area
        const contentArea = document.createElement('div');
        Object.assign(contentArea.style, {
            overflowY: 'auto',
            overflowX: 'hidden',
            flex: '1 1 auto',
            minHeight: '0',
            scrollbarWidth: 'thin',
            scrollbarColor: '#c1c1c1 #f1f1f1',
            paddingRight: '8px'
        });

        // Create tab content containers
        const loadFlowContent = this.createTabContent('loadflow', this.loadFlowParameters);
        const shortCircuitContent = this.createTabContent('shortcircuit', this.shortCircuitParameters);
        const opfContent = this.createTabContent('opf', this.opfParameters);
        const schematicContent = this.createTabContent('schematic', this.schematicParameters);
        const economicContent = this.createTabContent('economic', this.economicParameters);
        
        contentArea.appendChild(loadFlowContent);
        contentArea.appendChild(shortCircuitContent);
        contentArea.appendChild(opfContent);
        contentArea.appendChild(schematicContent);
        contentArea.appendChild(economicContent);
        container.appendChild(contentArea);

        // Add button container
        const buttonContainer = document.createElement('div');
        Object.assign(buttonContainer.style, {
            display: 'flex',
            gap: '8px',
            justifyContent: 'space-between',
            marginTop: '16px',
            paddingTop: '16px',
            borderTop: '1px solid #e9ecef'
        });

        // Left side buttons
        const leftButtons = document.createElement('div');
        Object.assign(leftButtons.style, {
            display: 'flex',
            gap: '8px'
        });

        const libraryButton = this.createButton('Library', '#28a745', '#218838');
        libraryButton.onclick = (e) => {
            e.preventDefault();
            this.showLibrary();
        };
        leftButtons.appendChild(libraryButton);

        // Right side buttons  
        const rightButtons = document.createElement('div');
        Object.assign(rightButtons.style, {
            display: 'flex',
            gap: '8px'
        });

        const cancelButton = this.createButton('Cancel', '#6c757d', '#5a6268');
        const applyButton = this.createButton('Apply', '#007bff', '#0056b3');
        
        cancelButton.onclick = (e) => {
            e.preventDefault();
            this.closeDialog();
        };

        applyButton.onclick = (e) => {
            e.preventDefault();
            const values = this.getFormValues();
            console.log('Three Winding Transformer values:', values);
            
            if (this.callback) {
                this.callback(values);
            }
            
            this.closeDialog();
        };

        rightButtons.appendChild(cancelButton);
        rightButtons.appendChild(applyButton);
        
        buttonContainer.appendChild(leftButtons);
        buttonContainer.appendChild(rightButtons);
        container.appendChild(buttonContainer);

        this.container = container;
        
        // Tab click handlers
        const allTabs = [loadFlowTab, shortCircuitTab, opfTab, schematicTab, economicTab];
        const allContents = [loadFlowContent, shortCircuitContent, opfContent, schematicContent, economicContent];
        loadFlowTab.onclick = () => this.switchTab('loadflow', loadFlowTab, allTabs.filter(t => t !== loadFlowTab), loadFlowContent, allContents.filter(c => c !== loadFlowContent));
        shortCircuitTab.onclick = () => this.switchTab('shortcircuit', shortCircuitTab, allTabs.filter(t => t !== shortCircuitTab), shortCircuitContent, allContents.filter(c => c !== shortCircuitContent));
        opfTab.onclick = () => this.switchTab('opf', opfTab, allTabs.filter(t => t !== opfTab), opfContent, allContents.filter(c => c !== opfContent));
        schematicTab.onclick = () => this.switchTab('schematic', schematicTab, allTabs.filter(t => t !== schematicTab), schematicContent, allContents.filter(c => c !== schematicContent));
        economicTab.onclick = () => this.switchTab('economic', economicTab, allTabs.filter(t => t !== economicTab), economicContent, allContents.filter(c => c !== economicContent));

        // Show dialog using DrawIO's dialog system
        if (this.ui && typeof this.ui.showDialog === 'function') {
            const screenHeight = window.innerHeight - 80;
            this.ui.showDialog(container, 1000, screenHeight, true, false);
        } else {
            this.showModalFallback(container);
        }
    }
    
    createTab(title, tabId, isActive) {
        const tab = document.createElement('div');
        Object.assign(tab.style, {
            padding: '12px 20px',
            cursor: 'pointer',
            borderBottom: isActive ? '2px solid #007bff' : '2px solid transparent',
            backgroundColor: isActive ? '#f8f9fa' : 'transparent',
            color: isActive ? '#007bff' : '#333',
            fontWeight: isActive ? '600' : '400',
            transition: 'all 0.2s ease'
        });
        tab.textContent = title;
        tab.setAttribute('data-tab', tabId);
        
        // Add hover effect
        tab.addEventListener('mouseenter', () => {
            if (!isActive) {
                tab.style.backgroundColor = '#f8f9fa';
                tab.style.color = '#007bff';
            }
        });
        
        tab.addEventListener('mouseleave', () => {
            if (!isActive) {
                tab.style.backgroundColor = 'transparent';
                tab.style.color = '#333';
            }
        });
        
        return tab;
    }
    
    createTabContent(tabId, parameters) {
        if (tabId === 'economic' && parameters && parameters.length > 0 && parameters[0]?.id === 'cost_per_unit_by_currency') {
            const content = document.createElement('div');
            content.dataset.tab = tabId;
            content.style.display = tabId === this.currentTab ? 'block' : 'none';
            content.appendChild(createEconomicTabContent(buildCostPerUnitByCurrency(this.data), this.inputs, true));
            return content;
        }

        const content = document.createElement('div');
        content.dataset.tab = tabId;
        Object.assign(content.style, {
            display: tabId === this.currentTab ? 'block' : 'none'
        });

        if (!parameters || parameters.length === 0) {
            const emptyMessage = document.createElement('div');
            Object.assign(emptyMessage.style, {
                padding: '20px',
                textAlign: 'center',
                color: '#666',
                fontStyle: 'italic'
            });
            emptyMessage.textContent = 'No parameters available for this category.';
            content.appendChild(emptyMessage);
            return content;
        }

        const form = document.createElement('form');
        Object.assign(form.style, {
            display: 'flex',
            flexDirection: 'column',
            gap: '16px'
        });

        let bracketWrap = null;

        parameters.forEach((param, paramIndex) => {
            const prev = paramIndex > 0 ? parameters[paramIndex - 1] : null;
            if (param.bracketGroup && (!prev || prev.bracketGroup !== param.bracketGroup)) {
                bracketWrap = createDialogBracketGroup(param.bracketGroupTitle || '');
                form.appendChild(bracketWrap);
            }
            if (!param.bracketGroup) {
                bracketWrap = null;
            }

            const isNameField = param.id === 'name';
            const parameterRow = document.createElement('div');
            Object.assign(parameterRow.style, {
                display: 'grid',
                gridTemplateColumns: isNameField ? 'minmax(0, 1fr) minmax(300px, 1.2fr)' : '1fr 200px',
                gap: '20px',
                alignItems: 'start',
                padding: '16px',
                backgroundColor: '#f8f9fa',
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                minHeight: '80px'
            });
            if (param.bracketGroup) {
                Object.assign(parameterRow.style, { marginBottom: '0' });
            }

            // Left column: Label and description
            const leftColumn = document.createElement('div');
            Object.assign(leftColumn.style, {
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
                minWidth: '0'
            });

            const label = document.createElement('label');
            Object.assign(label.style, {
                fontWeight: '600',
                fontSize: '14px',
                color: '#495057',
                marginBottom: '6px',
                lineHeight: '1.2'
            });
            label.textContent = param.label;
            label.htmlFor = param.id;

            const description = document.createElement('div');
            Object.assign(description.style, {
                fontSize: '12px',
                color: '#6c757d',
                lineHeight: '1.4',
                fontStyle: 'italic',
                marginBottom: '4px'
            });
            description.textContent = param.description;

            leftColumn.appendChild(label);
            leftColumn.appendChild(description);

            // Right column: Input field with fixed width
            const rightColumn = document.createElement('div');
            Object.assign(rightColumn.style, {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end',
                minHeight: '60px',
                width: isNameField ? '100%' : '200px',
                ...(isNameField ? { minWidth: '0' } : {})
            });
            
            let input;
            
            // Handle different input types
            if (param.type === 'checkbox') {
                input = document.createElement('input');
                input.type = 'checkbox';
                input.checked = param.value;
                Object.assign(input.style, {
                    width: '24px',
                    height: '24px',
                    accentColor: '#007bff',
                    cursor: 'pointer',
                    margin: '0'
                });
            } else if (param.type === 'select') {
                input = document.createElement('select');
                param.options.forEach(option => {
                    const opt = document.createElement('option');
                    opt.value = option;
                    opt.textContent = option;
                    if (option === param.value) {
                        opt.selected = true;
                    }
                    input.appendChild(opt);
                });
                Object.assign(input.style, {
                    width: isNameField ? '100%' : '180px',
                    ...(isNameField ? { minWidth: '0' } : {}),
                    padding: '10px 14px',
                    border: '2px solid #ced4da',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontFamily: 'inherit',
                    backgroundColor: '#ffffff',
                    boxSizing: 'border-box',
                    transition: 'all 0.2s ease',
                    outline: 'none'
                });
            } else {
                input = document.createElement('input');
                input.type = param.type;
                input.value = param.value;
                Object.assign(input.style, {
                    width: isNameField ? '100%' : '180px',
                    ...(isNameField ? { minWidth: '0' } : {}),
                    padding: '10px 14px',
                    border: '2px solid #ced4da',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontFamily: 'inherit',
                    backgroundColor: '#ffffff',
                    boxSizing: 'border-box',
                    transition: 'all 0.2s ease',
                    outline: 'none'
                });
                
                input.addEventListener('focus', () => {
                    input.style.borderColor = '#007bff';
                    input.style.boxShadow = '0 0 0 3px rgba(0, 123, 255, 0.15)';
                    input.style.transform = 'translateY(-1px)';
                });
                
                input.addEventListener('blur', () => {
                    input.style.borderColor = '#ced4da';
                    input.style.boxShadow = 'none';
                    input.style.transform = 'translateY(0)';
                });
                
                // Add hover effect
                input.addEventListener('mouseenter', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#adb5bd';
                        input.style.backgroundColor = '#f8f9fa';
                    }
                });
                
                input.addEventListener('mouseleave', () => {
                    if (input !== document.activeElement) {
                        input.style.borderColor = '#ced4da';
                        input.style.backgroundColor = '#ffffff';
                    }
                });
            }
            
            input.id = param.id;
            
            // Set additional attributes
            if (param.step) input.step = param.step;
            if (param.min !== undefined) input.min = param.min;
            if (param.max !== undefined) input.max = param.max;

            this.inputs.set(param.id, input);
            rightColumn.appendChild(input);

            parameterRow.appendChild(leftColumn);
            parameterRow.appendChild(rightColumn);

            const appendTarget = param.bracketGroup && bracketWrap ? bracketWrap : form;
            appendTarget.appendChild(parameterRow);

            const next = parameters[paramIndex + 1];
            if (param.bracketGroup && (!next || next.bracketGroup !== param.bracketGroup)) {
                bracketWrap = null;
            }
        });

        content.appendChild(form);
        return content;
    }
    
    switchTab(tabId, activeTab, inactiveTabs, activeContent, inactiveContents) {
        // Update current tab
        this.currentTab = tabId;
        
        // Update tab appearance
        activeTab.style.borderBottom = '2px solid #007bff';
        activeTab.style.backgroundColor = '#f8f9fa';
        activeTab.style.color = '#007bff';
        activeTab.style.fontWeight = '600';
        activeTab.classList.add('active');
        
        inactiveTabs.forEach(inactiveTab => {
            inactiveTab.style.borderBottom = '2px solid transparent';
            inactiveTab.style.backgroundColor = 'transparent';
            inactiveTab.style.color = '#333';
            inactiveTab.style.fontWeight = '400';
            Object.assign(inactiveTab.style, {
                color: '#6c757d',
                fontWeight: '400'
            });
            inactiveTab.classList.remove('active');
        });
        
        // Update content visibility
        activeContent.style.display = 'block';
        inactiveContents.forEach(inactiveContent => {
            inactiveContent.style.display = 'none';
        });
    }
    
    getFormValues() {
        const values = {};
        
        // Collect all parameter values from all tabs
        [...this.schematicParameters, ...this.loadFlowParameters, ...this.shortCircuitParameters, ...this.opfParameters, ...(this.economicParameters || [])].forEach(param => {
            const input = this.inputs.get(param.id);
            if (input) {
                if (param.id === 'cost_per_unit_by_currency') {
                    values[param.id] = input.value || '0';
                } else if (param.type === 'number') {
                    const raw = input.value.trim();
                    const numValue = parseFloat(raw);
                    values[param.id] = Number.isFinite(numValue) ? numValue : 0;
                } else if (param.type === 'checkbox') {
                    values[param.id] = input.checked;
                } else {
                    // For text inputs, convert empty strings to null for optional parameters
                    const optionalTextParams = ['vector_group'];
                    if (optionalTextParams.includes(param.id)) {
                        values[param.id] = input.value.trim() === '' ? null : input.value;
                    } else {
                        values[param.id] = input.value;
                    }
                }
            }
        });
        
        return values;
    }
    
    createButton(text, bgColor, hoverColor) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = text;
        Object.assign(button.style, {
            padding: '8px 16px',
            backgroundColor: bgColor,
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
            transition: 'background-color 0.2s'
        });
        
        button.addEventListener('mouseenter', () => {
            button.style.backgroundColor = hoverColor;
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.backgroundColor = bgColor;
        });
        
        return button;
    }
    
    destroy() {
        // Call parent destroy method
        super.destroy();
        
        // Clear global dialog flags to allow future dialogs
        if (window._globalDialogShowing) {
            delete window._globalDialogShowing;
        }
        
        console.log('Three Winding Transformer dialog destroyed and flags cleared');
    }
    
    showLibrary() {
        const libraryManager = new LibraryDialogManager();
        
        const libraryContainer = libraryManager.createLibraryDialog(
            'Three Winding Transformer Library',
            rowDefsThreeWindingTransformerLibrary,
            columnDefsThreeWindingTransformerLibrary,
            gridOptionsThreeWindingTransformerLibrary,
            (selectedItem) => {
                // Handle selection
                this.loadThreeWindingTransformerData(selectedItem);
                if (this.ui && typeof this.ui.hideDialog === 'function') {
                    this.ui.hideDialog();
                }
            },
            () => {
                // Handle cancel
                if (this.ui && typeof this.ui.hideDialog === 'function') {
                    this.ui.hideDialog();
                }
            }
        );

        // Show library dialog
        if (this.ui && typeof this.ui.showDialog === 'function') {
            const screenHeight = window.innerHeight - 80;
            this.ui.showDialog(libraryContainer, 1800, screenHeight, true, false);
        }
    }


    
    loadThreeWindingTransformerData(transformerData) {
        // Map library data to dialog inputs
        const mappings = {
            'name': transformerData.name || 'Three Winding Transformer',
            'term_label_0': transformerData.term_label_0 != null ? transformerData.term_label_0 : 'HV',
            'term_label_1': transformerData.term_label_1 != null ? transformerData.term_label_1 : 'MV',
            'term_label_2': transformerData.term_label_2 != null ? transformerData.term_label_2 : 'LV',
            'sn_hv_mva': transformerData.sn_hv_mva || 0,
            'sn_mv_mva': transformerData.sn_mv_mva || 0,
            'sn_lv_mva': transformerData.sn_lv_mva || 0,
            'vn_hv_kv': transformerData.vn_hv_kv || 0,
            'vn_mv_kv': transformerData.vn_mv_kv || 0,
            'vn_lv_kv': transformerData.vn_lv_kv || 0,
            'vk_hv_percent': transformerData.vk_hv_percent || 0,
            'vk_mv_percent': transformerData.vk_mv_percent || 0,
            'vk_lv_percent': transformerData.vk_lv_percent || 0,
            'vkr_hv_percent': transformerData.vkr_hv_percent || 0,
            'vkr_mv_percent': transformerData.vkr_mv_percent || 0,
            'vkr_lv_percent': transformerData.vkr_lv_percent || 0,
            'pfe_kw': transformerData.pfe_kw || 0,
            'i0_percent': transformerData.i0_percent || 0,
            'shift_mv_degree': transformerData.shift_mv_degree || 0,
            'shift_lv_degree': transformerData.shift_lv_degree || 0,
            'tap_side': transformerData.tap_side || 'hv',
            'tap_neutral': transformerData.tap_neutral || 0,
            'tap_min': transformerData.tap_min || -10,
            'tap_max': transformerData.tap_max || 10,
            'tap_step_percent': transformerData.tap_step_percent || 1,
            'tap_step_degree': transformerData.tap_step_degree != null ? parseFloat(transformerData.tap_step_degree) : 0,
            'tap_pos': transformerData.tap_pos || 0,
            'tap_phase_shifter': transformerData.tap_phase_shifter === 'True' || transformerData.tap_phase_shifter === true,
            'tap_changer_type': transformerData.tap_changer_type || 'Ratio',
            'in_service': true,
            'discrete_tap_control': transformerData.discrete_tap_control === 'True' || transformerData.discrete_tap_control === true,
            'control_side': transformerData.control_side || 'lv',
            'vm_lower_pu': transformerData.vm_lower_pu != null ? parseFloat(transformerData.vm_lower_pu) : 0.99,
            'vm_upper_pu': transformerData.vm_upper_pu != null ? parseFloat(transformerData.vm_upper_pu) : 1.01,
            // Optional zero sequence parameters
            'vk0_hv_percent': transformerData.vk0_hv_percent || 0,
            'vk0_mv_percent': transformerData.vk0_mv_percent || 0,
            'vk0_lv_percent': transformerData.vk0_lv_percent || 0,
            'vkr0_hv_percent': transformerData.vkr0_hv_percent || 0,
            'vkr0_mv_percent': transformerData.vkr0_mv_percent || 0,
            'vkr0_lv_percent': transformerData.vkr0_lv_percent || 0,
            'vector_group': transformerData.vector_group || ''
        };

        // Update input values
        Object.keys(mappings).forEach(key => {
            if (this.inputs.has(key)) {
                const input = this.inputs.get(key);
                const value = mappings[key];
                
                if (input.type === 'checkbox') {
                    input.checked = Boolean(value);
                } else if (input.tagName === 'SELECT') {
                    input.value = value;
                } else {
                    // Handle values for optional parameters
                    if (value === null || value === undefined) {
                        input.value = '';
                    } else {
                        input.value = value.toString();
                    }
                }
            }
        });

        console.log('Loaded three winding transformer data:', mappings);
    }
    
    populateDialog(cellData) {
        // Update parameter values based on cell data
        if (cellData && cellData.attributes) {
            for (let i = 0; i < cellData.attributes.length; i++) {
                const attribute = cellData.attributes[i];
                const attributeName = attribute.name;
                const attributeValue = attribute.value;
                
                // Update the dialog's parameter values (not DOM inputs)
                const schematicParam = this.schematicParameters.find(p => p.id === attributeName);
                if (schematicParam) {
                    schematicParam.value = attributeValue;
                }

                const loadFlowParam = this.loadFlowParameters.find(p => p.id === attributeName);
                if (loadFlowParam) {
                    if (loadFlowParam.type === 'checkbox') {
                        loadFlowParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        loadFlowParam.value = attributeValue;
                    }
                }
                
                const shortCircuitParam = this.shortCircuitParameters.find(p => p.id === attributeName);
                if (shortCircuitParam) {
                    if (shortCircuitParam.type === 'checkbox') {
                        shortCircuitParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        shortCircuitParam.value = attributeValue;
                    }
                }

                const opfParam = this.opfParameters.find(p => p.id === attributeName);
                if (opfParam) {
                    if (opfParam.type === 'checkbox') {
                        opfParam.value = attributeValue === 'true' || attributeValue === true;
                    } else {
                        opfParam.value = attributeValue;
                    }
                }
                
                const economicParam = (this.economicParameters || []).find(p => p.id === attributeName);
                if (economicParam) {
                    economicParam.value = attributeValue;
                    this.data[attributeName] = attributeValue;
                }
            }
        }
        
        console.log('Populated Three Winding Transformer dialog parameters with cell data');
    }
}

// Legacy exports for backward compatibility (maintaining AG-Grid structure for existing code)
export const rowDefsThreeWindingTransformerBase = [
    { name: "Three Winding Transformer", sn_hv_mva:0.0, sn_mv_mva:0.0, sn_lv_mva:0.0, vn_hv_kv:0.0, vn_mv_kv:0.0, vn_lv_kv:0.0, vk_hv_percent:0.0, vk_mv_percent:0.0, vk_lv_percent:0.0, vkr_hv_percent:0.0, vkr_mv_percent:0.0, vkr_lv_percent:0.0, pfe_kw:0.0, i0_percent:0.0, shift_mv_degree:0.0, shift_lv_degree:0.0, tap_side:"hv", tap_neutral:0.0, tap_min:-10.0, tap_max:10.0, tap_step_percent:1.0, tap_pos:0.0, tap_phase_shifter:false, tap_changer_type:"Ratio", max_loading_percent: 0.0 },
];
    
export const columnDefsThreeWindingTransformerBase = [  
    {
      field: "name",
    },
    {
      field: "sn_hv_mva",
      headerTooltip: "rated apparent power in MVA of high voltage side",
      maxWidth: 100,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "sn_mv_mva",
      headerTooltip: "rated apparent power in MVA of medium voltage side",
      maxWidth: 100,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "sn_lv_mva",
      headerTooltip: "rated apparent power in MVA of low voltage side",
      maxWidth: 100,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vn_hv_kv",
      headerTooltip: "rated voltage in kV of high voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vn_mv_kv",
      headerTooltip: "rated voltage in kV of medium voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vn_lv_kv",
      headerTooltip: "rated voltage in kV of low voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vk_hv_percent",
      headerTooltip: "short circuit voltage in percent of high voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vk_mv_percent",
      headerTooltip: "short circuit voltage in percent of medium voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vk_lv_percent",
      headerTooltip: "short circuit voltage in percent of low voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vkr_hv_percent",
      headerTooltip: "real part of short circuit voltage in percent of high voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vkr_mv_percent",
      headerTooltip: "real part of short circuit voltage in percent of medium voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "vkr_lv_percent",
      headerTooltip: "real part of short circuit voltage in percent of low voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "pfe_kw",
      headerTooltip: "iron losses in kW",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "i0_percent",
      headerTooltip: "open loop losses in percent",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "shift_mv_degree",
      headerTooltip: "angle shift to medium voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "shift_lv_degree",
      headerTooltip: "angle shift to low voltage side",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_side",
      headerTooltip: "where the tap changer is located (hv, mv, lv)",
      maxWidth: 120,
    },
    {
      field: "tap_neutral",
      headerTooltip: "tap position where no voltage shift is present",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_min",
      headerTooltip: "minimum tap position",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_max",
      headerTooltip: "maximum tap position",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_step_percent",
      headerTooltip: "tap step size in percent",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_pos",
      headerTooltip: "current tap position of the transformer. Defaults to tap_neutral if not set",
      maxWidth: 120,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    },
    {
      field: "tap_phase_shifter",
      headerTooltip: "whether the transformer is an ideal phase shifter",
      maxWidth: 120,
    },
    {
      field: "tap_changer_type",
      headerTooltip: "tap changer type: 'Ratio' (default) or 'Symmetrical' - new in pandapower 3.0+",
      maxWidth: 150,
    },
    {
      field: "max_loading_percent",
      headerTooltip: "OPF max loading % of rating (pandapower trafo3w); 0 = no limit",
      maxWidth: 160,
      valueParser: (params) => parseFloat(params.newValue) || 0,
    }
  ];
  
export const gridOptionsThreeWindingTransformerBase = {
    columnDefs: columnDefsThreeWindingTransformerBase,
    defaultColDef: {  
        minWidth: 100,
        editable: true,
    },
    rowData: rowDefsThreeWindingTransformerBase,
    singleClickEdit: true,
    stopEditingWhenCellsLoseFocus: true, //musi być żeby przy naciśnięciu Apply zapisywała się wartość 
  };     

// Make them globally available
globalThis.rowDefsThreeWindingTransformerBase = rowDefsThreeWindingTransformerBase;
globalThis.columnDefsThreeWindingTransformerBase = columnDefsThreeWindingTransformerBase;
globalThis.gridOptionsThreeWindingTransformerBase = gridOptionsThreeWindingTransformerBase;
globalThis.ThreeWindingTransformerDialog = ThreeWindingTransformerDialog;
  